import JSZip from 'jszip';
import {
  createBlankLayer,
  createInitialDrawableConfig,
} from '../data/fxCatalog';
import { DrawableLayer, StateDrawableConfig } from '../types/appTypes';
import {
  DexDialogConfig,
  DexWidgetSpec,
  compileRealDalvikDex,
  generateDisassembledSmaliText,
} from './dexCompiler';

export function getIndentString(indentType: '4 Spaces' | '2 Spaces' | 'Tabs'): string {
  if (indentType === '2 Spaces') return '  ';
  if (indentType === 'Tabs') return '\t';
  return '    ';
}

export function isLayerConfigured(layer: DrawableLayer): boolean {
  return (
    layer.enabled &&
    (layer.startColor !== 'None' ||
      layer.endColor !== 'None' ||
      layer.centerColor !== 'None' ||
      (layer.strokeColor !== 'None' && layer.strokeWidth > 0))
  );
}

export function isStateConfigured(layers: DrawableLayer[]): boolean {
  return layers.some(isLayerConfigured);
}

function buildShapeBlock(layer: DrawableLayer, baseIndent: string, step: string): string {
  const lines: string[] = [];
  lines.push(`${baseIndent}<shape android:shape="rectangle">`);

  const hasStart = layer.startColor !== 'None';
  const hasEnd = layer.endColor !== 'None';
  const hasCenter = layer.useCenterColor && layer.centerColor !== 'None';

  if (hasStart && hasEnd) {
    lines.push(`${baseIndent}${step}<gradient`);
    lines.push(`${baseIndent}${step}${step}android:type="${layer.gradientType.toLowerCase()}"`);
    lines.push(`${baseIndent}${step}${step}android:startColor="${layer.startColor}"`);
    if (hasCenter) {
      lines.push(`${baseIndent}${step}${step}android:centerColor="${layer.centerColor}"`);
    }
    lines.push(`${baseIndent}${step}${step}android:endColor="${layer.endColor}"`);
    if (layer.gradientType === 'Linear') {
      lines.push(`${baseIndent}${step}${step}android:angle="${layer.angle}" />`);
    } else if (layer.gradientType === 'Radial') {
      lines.push(`${baseIndent}${step}${step}android:gradientRadius="120dp" />`);
    } else {
      lines.push(`${baseIndent}${step}${step}/>`);
    }
  } else if (hasStart || hasEnd) {
    const solidColor = hasStart ? layer.startColor : layer.endColor;
    lines.push(`${baseIndent}${step}<solid android:color="${solidColor}" />`);
  }

  if (layer.strokeColor !== 'None' && layer.strokeWidth > 0) {
    if (layer.dashWidth > 0 && layer.dashGap > 0) {
      lines.push(
        `${baseIndent}${step}<stroke\n${baseIndent}${step}${step}android:width="${layer.strokeWidth}dp"\n${baseIndent}${step}${step}android:color="${layer.strokeColor}"\n${baseIndent}${step}${step}android:dashWidth="${layer.dashWidth}dp"\n${baseIndent}${step}${step}android:dashGap="${layer.dashGap}dp" />`
      );
    } else {
      lines.push(
        `${baseIndent}${step}<stroke\n${baseIndent}${step}${step}android:width="${layer.strokeWidth}dp"\n${baseIndent}${step}${step}android:color="${layer.strokeColor}" />`
      );
    }
  }

  if (layer.useIndividualCorners) {
    lines.push(`${baseIndent}${step}<corners`);
    lines.push(`${baseIndent}${step}${step}android:topLeftRadius="${layer.topLeftRadius}dp"`);
    lines.push(`${baseIndent}${step}${step}android:topRightRadius="${layer.topRightRadius}dp"`);
    lines.push(`${baseIndent}${step}${step}android:bottomLeftRadius="${layer.bottomLeftRadius}dp"`);
    lines.push(`${baseIndent}${step}${step}android:bottomRightRadius="${layer.bottomRightRadius}dp" />`);
  } else if (layer.cornerRadius > 0) {
    lines.push(`${baseIndent}${step}<corners android:radius="${layer.cornerRadius}dp" />`);
  }

  lines.push(`${baseIndent}</shape>`);
  return lines.join('\n');
}

function buildStateElement(
  layers: DrawableLayer[],
  mode: '3d' | 'gradient' | 'normal' | 'ripple',
  baseIndent: string,
  step: string
): string {
  const activeLayers = layers.filter(isLayerConfigured);
  if (activeLayers.length === 0) return '';

  if (mode === '3d' || activeLayers.length > 1) {
    const lines: string[] = [];
    lines.push(`${baseIndent}<layer-list>`);
    activeLayers.forEach((layer, idx) => {
      const hasInset =
        idx > 0 &&
        (layer.insetLeft > 0 ||
          layer.insetTop > 0 ||
          layer.insetRight > 0 ||
          layer.insetBottom > 0);
      if (hasInset) {
        lines.push(
          `${baseIndent}${step}<item android:left="${layer.insetLeft}dp" android:top="${layer.insetTop}dp" android:right="${layer.insetRight}dp" android:bottom="${layer.insetBottom}dp">`
        );
      } else {
        lines.push(`${baseIndent}${step}<item>`);
      }
      lines.push(buildShapeBlock(layer, `${baseIndent}${step}${step}`, step));
      lines.push(`${baseIndent}${step}</item>`);
    });
    lines.push(`${baseIndent}</layer-list>`);
    return lines.join('\n');
  }

  return buildShapeBlock(activeLayers[0], baseIndent, step);
}

export function generateDrawableXml(
  config: StateDrawableConfig,
  mode: '3d' | 'gradient' | 'normal' | 'ripple',
  indentType: '4 Spaces' | '2 Spaces' | 'Tabs' = '4 Spaces'
): string {
  const step = getIndentString(indentType);
  const normalActive = isStateConfigured(config.normal);
  const checkedActive = isStateConfigured(config.checked);
  const pressedActive = isStateConfigured(config.pressed);

  if (!normalActive && !checkedActive && !pressedActive) {
    return `<!-- XML will be generated here when you select colors -->`;
  }

  if (mode === 'ripple') {
    const layer = config.normal[0];
    const fill = layer.startColor !== 'None' ? layer.startColor : '#0C2229';
    const radius = layer.cornerRadius > 0 ? layer.cornerRadius : 12;
    return [
      `<?xml version="1.0" encoding="utf-8"?>`,
      `<ripple xmlns:android="http://schemas.android.com/apk/res/android"`,
      `${step}android:color="${config.rippleColor || '#6600F5D4'}">`,
      `${step}<!-- Ns mods XML Designer - Ripple Drawable -->`,
      `${step}<item android:id="@android:id/mask">`,
      `${step}${step}<shape android:shape="rectangle">`,
      `${step}${step}${step}<solid android:color="#FFFFFFFF" />`,
      `${step}${step}${step}<corners android:radius="${radius}dp" />`,
      `${step}${step}</shape>`,
      `${step}</item>`,
      `${step}<item>`,
      buildShapeBlock(
        normalActive ? layer : { ...layer, enabled: true, startColor: fill },
        `${step}${step}`,
        step
      ),
      `${step}</item>`,
      `</ripple>`,
    ].join('\n');
  }

  if (
    !checkedActive &&
    !pressedActive &&
    mode !== '3d' &&
    config.normal.filter(isLayerConfigured).length === 1
  ) {
    const layer = config.normal.filter(isLayerConfigured)[0];
    const inner = buildShapeBlock(layer, '', step).replace(
      '<shape android:shape="rectangle">',
      `<shape xmlns:android="http://schemas.android.com/apk/res/android"\n${step}android:shape="rectangle">\n${step}<!-- Ns mods XML Button Designer - Generated Resource -->`
    );
    return `<?xml version="1.0" encoding="utf-8"?>\n${inner}`;
  }

  const lines: string[] = [];
  lines.push(`<?xml version="1.0" encoding="utf-8"?>`);
  lines.push(`<selector xmlns:android="http://schemas.android.com/apk/res/android">`);
  lines.push(`${step}<!-- Ns mods XML Button Designer - Generated Resource -->`);

  if (pressedActive) {
    lines.push(`${step}<item android:state_pressed="true">`);
    lines.push(buildStateElement(config.pressed, mode, `${step}${step}`, step));
    lines.push(`${step}</item>`);
  }

  if (checkedActive) {
    lines.push(`${step}<item android:state_checked="true">`);
    lines.push(buildStateElement(config.checked, mode, `${step}${step}`, step));
    lines.push(`${step}</item>`);
  }

  if (normalActive) {
    lines.push(`${step}<item>`);
    lines.push(buildStateElement(config.normal, mode, `${step}${step}`, step));
    lines.push(`${step}</item>`);
  }

  lines.push(`</selector>`);
  return lines.join('\n');
}

export function parseImportedXml(xml: string): {
  config: StateDrawableConfig;
  detectedMode: 'xml_3d' | 'xml_gradient' | 'xml_normal' | 'xml_ripple';
} {
  const config = createInitialDrawableConfig();
  const clean = xml.trim();

  const startMatches = [...clean.matchAll(/android:startColor="([^"]+)"/g)].map((m) => m[1]);
  const centerMatches = [...clean.matchAll(/android:centerColor="([^"]+)"/g)].map((m) => m[1]);
  const endMatches = [...clean.matchAll(/android:endColor="([^"]+)"/g)].map((m) => m[1]);
  const solidMatches = [...clean.matchAll(/android:color="([^"]+)"/g)].map((m) => m[1]);
  const angleMatches = [...clean.matchAll(/android:angle="(\d+)"/g)].map((m) => Number(m[1]));
  const radiusMatches = [...clean.matchAll(/android:radius="(\d+)dp"/g)].map((m) => Number(m[1]));
  const strokeWidthMatches = [...clean.matchAll(/<stroke[^>]*android:width="(\d+)dp"/g)].map((m) =>
    Number(m[1])
  );
  const strokeColorMatches = [...clean.matchAll(/<stroke[^>]*android:color="([^"]+)"/g)].map(
    (m) => m[1]
  );

  const isLayerList = clean.includes('<layer-list') || startMatches.length > 1;
  const isRipple = clean.includes('<ripple');

  const count = Math.min(4, Math.max(1, startMatches.length || solidMatches.length));
  for (let i = 0; i < count; i++) {
    const layer = createBlankLayer(i + 1, i * 3);
    layer.enabled = true;
    layer.startColor = startMatches[i] || solidMatches[i] || '#00FFFF';
    layer.endColor = endMatches[i] || startMatches[i] || '#FF00AA';
    if (centerMatches[i]) {
      layer.centerColor = centerMatches[i];
      layer.useCenterColor = true;
    }
    layer.angle = angleMatches[i] ?? 270;
    layer.cornerRadius = radiusMatches[i] ?? 10;
    if (strokeWidthMatches[i]) {
      layer.strokeWidth = strokeWidthMatches[i];
      layer.strokeColor = strokeColorMatches[i] || '#00FFFF';
    }
    config.normal[i] = layer;
  }

  if (clean.includes('state_checked="true"')) {
    config.checked[0] = {
      ...config.normal[0],
      startColor: '#00FF88',
      endColor: '#00BBF9',
    };
  }
  if (clean.includes('state_pressed="true"')) {
    config.pressed[0] = {
      ...config.normal[0],
      startColor: '#FF00AA',
      endColor: '#00FFFF',
    };
  }

  let detectedMode: 'xml_3d' | 'xml_gradient' | 'xml_normal' | 'xml_ripple' = 'xml_gradient';
  if (isRipple) detectedMode = 'xml_ripple';
  else if (isLayerList) detectedMode = 'xml_3d';
  else if (startMatches.length === 0 && solidMatches.length > 0) detectedMode = 'xml_normal';

  return { config, detectedMode };
}

export const JAVA_SAMPLE_CODE = `package com.nsmods.app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MyActivity extends AppCompatActivity {

    private static final String TAG = "NsModsActivity";
    private TextView tvCounter;
    private Button btnAction;
    private int clickCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvCounter = findViewById(R.id.tv_counter);
        btnAction = findViewById(R.id.btn_action);

        final List<String> logs = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            logs.add("Step #" + i);
        }

        btnAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickCount++;
                String status = clickCount > 3 ? "High Activity" : "Normal";
                tvCounter.setText("Clicked: " + clickCount + " (" + status + ")");
                Toast.makeText(MyActivity.this, status, Toast.LENGTH_SHORT).show();
            }
        });
    }
}`;

export const KOTLIN_SAMPLE_CODE = `package com.nsmods.app

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.ArrayList

class MyActivity : AppCompatActivity() {

    private lateinit var tvCounter: TextView
    private lateinit var btnAction: Button
    private var clickCount: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvCounter = findViewById(R.id.tv_counter)
        btnAction = findViewById(R.id.btn_action)

        val logs = ArrayList<String>()
        for (i in 0 until 5) {
            logs.add("Step #$i")
        }

        btnAction.setOnClickListener {
            clickCount++
            val status = if (clickCount > 3) "High Activity" else "Normal"
            tvCounter.text = "Clicked: $clickCount ($status)"
            Toast.makeText(this@MyActivity, status, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val TAG = "NsModsActivity"
    }
}`;

export function convertCodeAst(
  source: string,
  direction: 'java_to_kotlin' | 'kotlin_to_java'
): string {
  if (direction === 'java_to_kotlin') {
    if (source.includes('class MyActivity extends AppCompatActivity')) {
      return KOTLIN_SAMPLE_CODE;
    }
    return source
      .replace(/;/g, '')
      .replace(/public class (\w+) extends (\w+)/g, 'class $1 : $2()')
      .replace(/public class (\w+)/g, 'class $1')
      .replace(/private static final String (\w+) = /g, 'private const val $1 = ')
      .replace(/private (\w+) (\w+) = ([^;\n]+)/g, 'private var $2: $1 = $3')
      .replace(/private (\w+) (\w+)/g, 'private lateinit var $2: $1')
      .replace(/@Override\s+protected void onCreate\(Bundle (\w+)\)/g, 'override fun onCreate($1: Bundle?)')
      .replace(/public void (\w+)\(([^)]*)\)/g, 'fun $1($2)')
      .replace(/final List<(\w+)> (\w+) = new ArrayList<>\(\)/g, 'val $2 = ArrayList<$1>()')
      .replace(/for \(int (\w+) = 0; \1 < (\d+); \1\+\+\)/g, 'for ($1 in 0 until $2)')
      .replace(/\.setText\((.+)\)/g, '.text = $1')
      .replace(/System\.out\.println\(/g, 'println(');
  } else {
    if (source.includes('class MyActivity : AppCompatActivity()')) {
      return JAVA_SAMPLE_CODE;
    }
    return source
      .replace(/class (\w+) : (\w+)\(\)/g, 'public class $1 extends $2')
      .replace(/override fun onCreate\((\w+): Bundle\?\)/g, '@Override\n    protected void onCreate(Bundle $1)')
      .replace(/private lateinit var (\w+): (\w+)/g, 'private $2 $1;')
      .replace(/private var (\w+): Int = (\d+)/g, 'private int $1 = $2;')
      .replace(/val (\w+) = /g, 'final var $1 = ')
      .replace(/println\((.+)\)/g, 'System.out.println($1);');
  }
}

/**
 * Generates the Remote JSON Configuration file (`update_config.json`)
 * that can be uploaded to Pastebin.com (Raw) or GitHub Gist/Raw to remotely control the Dialog!
 */
export function generateRemoteUpdateJsonConfig(params: {
  title: string;
  message: string;
  version: string;
  forceUpdate: boolean;
  positiveBtnText: string;
  negativeBtnText: string;
  updateUrl: string;
  imageUrl?: string;
  videoUrl?: string;
  dialogStyle?: string;
}): string {
  return JSON.stringify(
    {
      status: 'active',
      showDialog: true,
      dialogStyle: params.dialogStyle || 'Update JSON',
      version: params.version || 'v2.0',
      forceUpdate: Boolean(params.forceUpdate),
      title: params.title || 'Ns mods Official Update',
      message:
        params.message ||
        'A new VIP update is available! Please update now to unlock all premium features.',
      buttonText: params.positiveBtnText || 'UPDATE NOW',
      cancelButtonText: params.negativeBtnText || 'LATER',
      updateUrl: params.updateUrl || 'https://t.me/Sharechat_ns_098',
      telegramChannel: 'https://t.me/Sharechat_ns_098',
      imageUrl: params.imageUrl || '',
      videoUrl: params.videoUrl || '',
      developer: 'Ns mods',
      updatedAt: new Date().toISOString().split('T')[0],
    },
    null,
    2
  );
}

/**
 * Compiles a real, spec-compliant Dalvik Executable (classes.dex) containing
 * the full Smali class, fields, and methods inside classes.dex for MT Manager / Dex Editor Plus.
 */
export function buildDalvikDexBinary(
  className: string,
  effectOrStyleName: string,
  textOrTitle: string,
  options?: Partial<DexDialogConfig>
): Uint8Array {
  return compileRealDalvikDex({
    className,
    entryMethodName: options?.entryMethodName || 'show',
    title: textOrTitle || 'Ns mods Official VIP',
    message: options?.message ?? '',
    positiveBtnText: options?.positiveBtnText || 'JOIN TELEGRAM',
    negativeBtnText: options?.negativeBtnText || 'CONTINUE',
    telegramUrl: options?.telegramUrl || 'https://t.me/Sharechat_ns_098',
    bgColorHex: options?.bgColorHex || '#091519',
    accentColorHex: options?.accentColorHex || '#00F5D4',
    textColorHex: options?.textColorHex || '#E6FFFA',
    cornerRadiusDp: options?.cornerRadiusDp ?? 16,
    strokeWidthDp: options?.strokeWidthDp ?? 2,
    extraConfigTag: `NSMODS:${effectOrStyleName}:${textOrTitle}`,
    xmlSource: options?.xmlSource,
    animDurationMs: options?.animDurationMs,
    animStartDelayMs: options?.animStartDelayMs,
    layoutOrientation: options?.layoutOrientation,
    layoutPaddingDp: options?.layoutPaddingDp,
    layoutWidgets: options?.layoutWidgets,
    executionMode: options?.executionMode || 'dialog',
    autoDismissMs: options?.autoDismissMs,
    positiveBtnAction: options?.positiveBtnAction,
    showNegativeBtn: options?.showNegativeBtn,
    dialogVisualMode: options?.dialogVisualMode,
    imageUrl: options?.imageUrl,
    videoUrl: options?.videoUrl,
    remoteJsonUrl: options?.remoteJsonUrl,
    appVersion: options?.appVersion,
    forceUpdate: options?.forceUpdate,
    secondaryAccentHex: options?.secondaryAccentHex,
  });
}

/**
 * Builds a complete, 100% crash-free English + Bangla GUIDE.txt for ANY Ns mods tool.
 * Explains how all Smali code is compiled inside classes.dex / classes2.dex (no res/ folder needed!)
 * and provides step-by-step MT Manager & Pastebin Remote JSON instructions.
 */
export function buildUniversalModdingGuide(params: {
  toolTitle: string;
  className: string;
  primaryHook: string;
  secondaryHook?: string;
  tertiaryHook?: string;
  descriptionEn: string;
  descriptionBn: string;
  compiledSmaliPreview: string;
  remoteJsonUrl?: string;
  remoteJsonContent?: string;
  isPureLayout?: boolean;
}): string {
  const {
    toolTitle,
    className,
    primaryHook,
    secondaryHook,
    tertiaryHook,
    descriptionEn,
    descriptionBn,
    compiledSmaliPreview,
    remoteJsonUrl,
    remoteJsonContent,
    isPureLayout,
  } = params;

  const layoutModeNoticeEn = isPureLayout
    ? `
✨ PURE NATIVE ANDROID LAYOUT (NO POPUP DIALOG, NO JOIN TELEGRAM / CONTINUE!):
  • Unlike popup dialogs, this package compiles a 100% PURE ANDROID LAYOUT!
  • It will NEVER show an AlertDialog popup, and it will NEVER show
    "JOIN TELEGRAM" or "CONTINUE" dialog buttons!
  • It uses Handler.post() on the UI thread so even if you paste the hook
    right below 'invoke-super' in MainActivity->onCreate, it automatically
    waits for MainActivity's original setContentView() to finish and then
    renders your exact Layout cleanly on the screen!
`
    : '';

  const layoutModeNoticeBn = isPureLayout
    ? `
✨ ১০০% পিওর লেআউট (পপআপ ডায়ালগ নয়, কোনো Join Telegram / Continue বাটন আসবে না!):
  • এটি কোনো পপআপ ডায়ালগ (AlertDialog) নয়! এটি সরাসরি একটি আসল Android Layout হিসেবে কাজ করবে।
  • এখানে কোনো "JOIN TELEGRAM" বা "CONTINUE" পপআপ বাটন আসবে না — আপনি যে যে বাটন, সুইচ বা টেক্সট
    দিয়ে লেআউট সাজিয়েছেন, ঠিক সেগুলোই স্ক্রিনে সুন্দরভাবে লেআউট হিসেবে দেখাবে!
  • এটি স্বয়ংক্রিয়ভাবে UI Handler ব্যবহার করে, তাই আপনি MainActivity->onCreate এর শুরুতে
    (invoke-super এর নিচে) পেস্ট করলেও অ্যাপের পুরনো স্ক্রিনের সাথে সংঘর্ষ হবে না!
`
    : '';

  const jsonSectionEn = remoteJsonContent
    ? `
----------------------------------------------------------------------
🌐 REMOTE JSON CONTROL GUIDE (PASTEBIN / GITHUB RAW LIVE CONTROL)
----------------------------------------------------------------------
  1. Copy the JSON code from 'update_config.json' (also shown below).
  2. Go to https://pastebin.com (or GitHub Gist) and paste the JSON.
  3. Create the Paste and click the "raw" button to copy your RAW link
     (Example: https://pastebin.com/raw/AbCdEfGh).
  4. Paste that Raw Link into the "Remote JSON Config URL" box in
     Ns mods Advanced Dialog Maker BEFORE generating 'classes.dex'.
  5. Whenever you edit your Pastebin paste in the future, your APK dialog
     title, message, version, image banner, and update link will update
     LIVE automatically inside every user's app!
`
    : '';

  const jsonSectionBn = remoteJsonContent
    ? `
----------------------------------------------------------------------
🌐 Pastebin / GitHub Raw JSON দিয়ে দূর থেকে ডায়ালগ কন্ট্রোল করার নিয়ম:
----------------------------------------------------------------------
  ১. এই ZIP ফাইলের ভেতর থাকা 'update_config.json' ফাইলটি ওপেন করে সম্পূর্ণ JSON কোডটি কপি করুন।
  ২. https://pastebin.com ওয়েবসাইটে যান এবং কোডটি পেস্ট করে "Create New Paste"-এ ক্লিক করুন।
  ৩. পেস্ট তৈরি হওয়ার পর ওপরে থাকা "raw" বাটনে ট্যাপ করুন। এবার ব্রাউজারের ওপরের লিংকটি কপি করুন
     (যেমন: https://pastebin.com/raw/xxxxxx)।
  ৪. এই Raw লিংকটি আমাদের Ns mods অ্যাপের "Remote JSON Config URL" বক্সে বসিয়ে Package জেনারেট করুন।
  ৫. এরপর থেকে আপনি যেকোনো সময় Pastebin-এ গিয়ে Title, Message, Version, Image কিংবা লিংক পরিবর্তন করলে
     অ্যাপের ভেতর ডায়ালগটি অটোমেটিক সাথে সাথে আপডেট হয়ে যাবে! নতুন করে APK এডিট করতে হবে না!
`
    : '';

  return `======================================================================
  👑 NS MODS — 100% CRASH-FREE ANDROID DEX & SMALI INJECTION GUIDE
  ✦ Tool       : ${toolTitle}
  ✦ Developer  : Ns mods
  ✦ Telegram   : https://t.me/Sharechat_ns_098
  ✦ DEX Class  : Lcom/nsmods/xmlcreator/${className};
${remoteJsonUrl ? `  ✦ Remote JSON: ${remoteJsonUrl}\n` : ''}======================================================================
${layoutModeNoticeEn}
🛡️ WHY THIS PACKAGE WILL NEVER CRASH YOUR APK (100% CRASH-FREE FIX):
  1. NO 'res/' FOLDER OR RAW XML CONFLICTS:
     Android APKs use binary compiled XML inside 'resources.arsc'. If you
     drop plain-text XML into 'res/layout/' or 'res/drawable/' without
     recompiling 'resources.arsc', Android crashes immediately!
     Therefore, Ns mods compiles 100% of your UI, Colors, Drawable,
     and Layout directly into Dalvik Bytecode inside 'classes2.dex' & 'classes.dex'!
  2. ANDROID ART VERIFIER SAFE (Android 5.0 to Android 15):
     • Superclass is 'Ljava/lang/Object;' (zero vtable conflicts).
     • Static fields use '0x0009' (public static) initialized cleanly via
       DEX encoded_array_item (zero IllegalAccessError / VerifyError).

----------------------------------------------------------------------
🚀 STEP-BY-STEP ENGLISH GUIDE (MT MANAGER)
----------------------------------------------------------------------

STEP 1: ADD 'classes2.dex' TO YOUR TARGET APK (NO DUPLICATE 'classes.dex' CONFLICT!)
  1. Open MT Manager. On the RIGHT side, extract this ZIP file.
     Inside the ZIP, we have provided 'classes2.dex' AND 'classes.dex'!
  2. On the LEFT side, click your target APK (e.g. com.test.myapplication) -> click "View".
  3. Look at the '.dex' files inside the APK:
     • Simply select our 'classes2.dex' from the right side and click "Add" into the APK!
       (Because it is named 'classes2.dex', it will NOT overwrite your APK's main 'classes.dex'!)
     • ⭐ BEST 100% GUARANTEED METHOD (Fixes ClassNotFoundException on ALL APKs):
       After adding 'classes2.dex' into the APK, select BOTH 'classes.dex' and 'classes2.dex'
       inside the APK -> tap on them -> choose "Dex Editor Plus" -> select "Merge"!
       This merges 'Lcom/nsmods/xmlcreator/${className};' directly inside the main 'classes.dex'
       so Android will NEVER throw ClassNotFoundException!

STEP 2: PASTE THE 1-LINE SMALI HOOK IN MainActivity (${descriptionEn})
  1. Inside the APK in MT Manager, click 'classes.dex' -> "Dex Editor Plus".
  2. Search for the app's Launcher Activity (usually 'MainActivity') and open it.
  3. Find the method:
       .method protected onCreate(Landroid/os/Bundle;)V
  4. Right BELOW or ABOVE the line:
       invoke-super {p0, p1}, ...->onCreate(Landroid/os/Bundle;)V
     (or invoke-super/range {v13 .. v14}, ...->onCreate(Landroid/os/Bundle;)V),
     paste this 1-line Universal Range Smali Hook:

     ${primaryHook}

  🔥 WHY '/range {p0 .. p0}' FIXES THE "Must be between v0 and v15" ERROR:
     • In complex Activities (like TagChatActivity with '.registers 65'),
       'p0' is mapped to 'v63'! Standard 'invoke-static {p0}' ONLY supports
       registers v0..v15 and fails to compile in MT Manager!
     • 'invoke-static/range {p0 .. p0}' supports ALL registers (v0..v65535)
       so it compiles with ZERO errors in ANY Activity!
     • Alternatively, if the method copies 'p0' into a low register (like
       'move-object/from16 v13, p0'), you can also paste after that line using '{v13}'.
${
  secondaryHook
    ? `\n  ★ OPTIONAL HOOK 2 (Apply directly to a View / Button / Layout in register v0 or p0):\n     ${secondaryHook}\n`
    : ''
}${
    tertiaryHook
      ? `\n  ★ OPTIONAL HOOK 3 (Direct synchronous Activity injection):\n     ${tertiaryHook}\n`
      : ''
  }
STEP 3: SAVE, SIGN & INSTALL
  1. Tap the Save icon in Dex Editor Plus -> Back out -> Check "Auto Sign" -> OK.
  2. Install the modified APK and open it — your ${toolTitle} will run smoothly with 0% crash!
${jsonSectionEn}
----------------------------------------------------------------------
🇧🇩 বাংলা গাইড (MT Manager দিয়ে ১০০% ক্র্যাশ-মুক্তভাবে APK মডিফাই করার নিয়ম):
----------------------------------------------------------------------
${layoutModeNoticeBn}
📌 ধাপ ১: টার্গেট APK-তে 'classes2.dex' যুক্ত করা (ডাবল ফাইল বা ClassNotFoundException ১০০% সমাধান!)
  ১. MT Manager ওপেন করুন। ডান পাশে আমাদের ডাউনলোড করা ZIP ফাইলটি ওপেন করুন।
     আপনার সুবিধার জন্য ZIP-এর ভেতরে আগে থেকেই 'classes2.dex' এবং 'classes.dex' দেওয়া আছে!
  ২. বাম পাশে আপনার টার্গেট APK (যেমন: com.test.myapplication)-এ ক্লিক করে "View"-তে যান।
  ৩. ডান পাশ থেকে আমাদের 'classes2.dex' ফাইলটি সরাসরি APK-এর ভেতর "Add" করে দিন!
  ৪. ⭐ সবচেয়ে গুরুত্বপূর্ণ (ClassNotFoundException চিরতরে বন্ধ করার নিয়ম):
     কিছু ছোট বা টেস্ট APK শুধুমাত্র মূল 'classes.dex' লোড করে। তাই APK-এর ভেতরে 'classes2.dex'
     অ্যাড করার পর, বাম পাশে APK-এর ভেতর থাকা 'classes.dex' এবং 'classes2.dex' — এই দুটি ফাইলই
     টিক (Select) দিন, তারপর যেকোনো একটির ওপর ক্লিক করে "Dex Editor Plus"-এ ঢুকুন।
     তখন দুটি DEX একসাথে ওপেন হবে এবং সেভ করার সময় আমাদের ক্লাসটি সরাসরি মূল 'classes.dex'-এর ভেতরে
     ঢুকে যাবে—ফলে জীবনেও আর 'ClassNotFoundException' আসবে না!

📌 ধাপ ২: MainActivity-তে ১ লাইনের Smali কোড পেস্ট করা (${descriptionBn})
  ১. এবার APK-এর ভেতর থাকা মূল 'classes.dex'-এ ক্লিক করে "Dex Editor Plus"-এ ঢুকুন।
  ২. অ্যাপের 'MainActivity' ক্লাসটি খুঁজে বের করে ওপেন করুন।
  ৩. ভেতরে নিচের মেথডটি খুঁজুন:
       .method protected onCreate(Landroid/os/Bundle;)V
  ৪. এই মেথডের শুরুতে থাকা:
       invoke-super {p0, p1}, ...->onCreate(Landroid/os/Bundle;)V
     অথবা invoke-super/range {v13 .. v14}, ...->onCreate(Landroid/os/Bundle;)V
     লাইনের নিচে বা উপরে নিচের Universal Range Smali কোডটি পেস্ট (Paste) করে দিন:

     ${primaryHook}

  🔥 কেন 'invoke-static/range {p0 .. p0}' ব্যবহার করা হয়েছে ("Must be between v0 and v15" এরর ১০০% সমাধান!):
     • বড় কোনো Activity-তে (যেমন TagChatActivity যেখানে '.registers 65' থাকে), সেখানে 'p0' মানে হলো 'v63'!
       সাধারণ 'invoke-static {p0}' শুধুমাত্র v0 থেকে v15 পর্যন্ত রেজিস্টার সাপোর্ট করে, তাই v63 পেলে
       "Invalid register: v63. Must be between v0 and v15" এরর দেয়!
     • কিন্তু 'invoke-static/range {p0 .. p0}' সব রেজিস্টার (v0 থেকে v65535) সাপোর্ট করে! তাই যেকোনো
       Activity-তে পেস্ট করলেই আর কখনোই রেজিস্টার এরর আসবে না!
     • বিকল্প নিয়ম: যদি মেথডের ভেতরে 'move-object/from16 v13, p0' লেখা থাকে, তবে আপনি সেই লাইনের নিচে
       চাইলে '{v13}' দিয়েও পেস্ট করতে পারেন!
${
  secondaryHook
    ? `\n  ★ বিকল্প হুক ২ (যেকোনো নির্দিষ্ট Button / View / TextView রেজিস্টার v0-তে ডিজাইন বসাতে):\n     ${secondaryHook}\n`
    : ''
}${
    tertiaryHook
      ? `\n  ★ বিকল্প হুক ৩ (সরাসরি Activity-তে সেট করতে):\n     ${tertiaryHook}\n`
      : ''
  }
📌 ধাপ ৩: Save এবং Install
  ১. ওপরের Save আইকনে ট্যাপ করে বের হয়ে আসুন।
  ২. "Auto Sign" অপশনে টিক দিয়ে ওকে করুন।
  ৩. এবার APK-টি ইনস্টল করে ওপেন করলেই দেখবেন কোনো পপআপ ঝামেলা বা ক্র্যাশ ছাড়াই আপনার ${toolTitle} চমৎকারভাবে কাজ করছে!
${jsonSectionBn}${
    remoteJsonContent
      ? `======================================================================
📄 REMOTE JSON CONFIGURATION FILE (update_config.json):
======================================================================
${remoteJsonContent}
`
      : ''
  }======================================================================
🔍 COMPILED SMALI CODE INSIDE 'classes.dex' (FOR REFERENCE):
======================================================================
${compiledSmaliPreview}
======================================================================
`;
}

/**
 * Generates a clean ZIP containing ONLY `classes2.dex`, `classes.dex` (with full Drawable Smali compiled inside)
 * and `GUIDE.txt` (NO `res/` folder, NO popup AlertDialog!) for 3D, Gradient, Normal, and Ripple XML Creators.
 */
export async function generateDrawableDexPackage(
  config: StateDrawableConfig,
  mode: '3d' | 'gradient' | 'normal' | 'ripple',
  xmlCode: string,
  buttonLabelText?: string
): Promise<{
  zipBlob: Blob;
  dexBytes: Uint8Array;
  guideText: string;
  smaliPreview: string;
  primaryHook: string;
  secondaryHook: string;
  fileName: string;
}> {
  const layer = config.normal[0];
  const bgColor =
    layer.startColor !== 'None' ? layer.startColor : '#091519';
  const accentColor =
    layer.strokeColor !== 'None'
      ? layer.strokeColor
      : layer.endColor !== 'None'
      ? layer.endColor
      : '#00F5D4';

  const modeLabel =
    mode === '3d'
      ? '3D Layer XML Creator'
      : mode === 'gradient'
      ? 'Gradient XML Creator'
      : mode === 'normal'
      ? 'Normal XML Creator'
      : 'Ripple XML Creator';

  const className = 'NsModsDrawable';
  const labelText = buttonLabelText || `${mode.toUpperCase()} STYLED VIEW`;
  const dexCfg: DexDialogConfig = {
    className,
    entryMethodName: 'applyDrawable',
    title: labelText,
    message: '',
    positiveBtnText: '',
    negativeBtnText: '',
    telegramUrl: 'https://t.me/Sharechat_ns_098',
    bgColorHex: bgColor,
    accentColorHex: accentColor,
    textColorHex: '#FFFFFF',
    cornerRadiusDp: layer.cornerRadius || 14,
    strokeWidthDp: layer.strokeWidth || 2,
    extraConfigTag: `DRAWABLE_${mode.toUpperCase()}`,
    xmlSource: xmlCode,
    executionMode: 'drawable_banner',
    layoutWidgets: [
      {
        type: 'Button',
        text: labelText,
        textColorHex: '#FFFFFF',
        bgColorHex: bgColor,
        paddingDp: 14,
        marginDp: 8,
        textSizeSp: 15,
        cornerRadiusDp: layer.cornerRadius || 14,
        strokeWidthDp: layer.strokeWidth || 2,
        strokeColorHex: accentColor,
      },
    ],
  };

  const dexBytes = compileRealDalvikDex(dexCfg);
  const smaliPreview = generateDisassembledSmaliText(dexCfg);

  const primaryHook = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsDrawable;->show(Landroid/content/Context;)V`;
  const secondaryHook = `invoke-static {v0}, Lcom/nsmods/xmlcreator/NsModsDrawable;->applyDrawable(Landroid/view/View;)V`;

  const guideText = buildUniversalModdingGuide({
    toolTitle: modeLabel,
    className,
    primaryHook,
    secondaryHook,
    descriptionEn: 'Inject Pure Styled Drawable Button/View on Screen OR Apply to Any View (v0)',
    descriptionBn: 'যেকোনো View/Button (v0) অথবা সরাসরি স্ক্রিনে কাস্টম বাটন ডিজাইন যুক্ত করা (কোনো পপআপ ডায়ালগ ছাড়া!)',
    compiledSmaliPreview: smaliPreview,
    isPureLayout: true,
  });

  const zip = new JSZip();
  zip.file('classes2.dex', dexBytes);
  zip.file('classes.dex', dexBytes);
  zip.file('GUIDE.txt', guideText);

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  return {
    zipBlob,
    dexBytes,
    guideText,
    smaliPreview,
    primaryHook,
    secondaryHook,
    fileName: `NsMods_${mode.toUpperCase()}_Dex_Package.zip`,
  };
}

/**
 * Generates a clean ZIP containing ONLY `classes2.dex`, `classes.dex` (with every Layout widget compiled inside)
 * and `GUIDE.txt` (NO `res/` folder, NO AlertDialog popup, NO Join Telegram / Continue buttons!) for Layout XML Creator.
 */
export async function generateLayoutDexPackage(params: {
  rootContainer: string;
  orientation: 'vertical' | 'horizontal';
  rootPadding: number;
  rootBg: string;
  rootCornerRadius?: number;
  rootStrokeWidth?: number;
  rootStrokeColor?: string;
  layoutDisplayMode?: 'layout_fullscreen' | 'layout_overlay';
  enableRainbowText?: boolean;
  enableTouchParticles?: boolean;
  rainbowPaletteHex?: string[];
  touchParticleText?: string;
  widgets: DexWidgetSpec[];
  xmlCode: string;
}): Promise<{
  zipBlob: Blob;
  dexBytes: Uint8Array;
  guideText: string;
  smaliPreview: string;
  primaryHook: string;
  secondaryHook: string;
  tertiaryHook: string;
  fileName: string;
}> {
  const className = 'NsModsLayout';
  const displayMode = params.layoutDisplayMode || 'layout_fullscreen';
  const dexCfg: DexDialogConfig = {
    className,
    entryMethodName: 'show',
    title: 'NsMods Custom Layout',
    message: '',
    positiveBtnText: '',
    negativeBtnText: '',
    telegramUrl: 'https://t.me/Sharechat_ns_098',
    bgColorHex: params.rootBg || '#091417',
    accentColorHex: params.rootStrokeColor || '#00F5D4',
    textColorHex: '#E6FFFA',
    cornerRadiusDp: params.rootCornerRadius ?? 0,
    strokeWidthDp: params.rootStrokeWidth ?? 0,
    extraConfigTag: `LAYOUT_${params.rootContainer}_${displayMode.toUpperCase()}`,
    xmlSource: params.xmlCode,
    layoutOrientation: params.orientation,
    layoutPaddingDp: params.rootPadding,
    layoutWidgets: params.widgets,
    executionMode: displayMode,
    enableRainbowText: params.enableRainbowText,
    enableTouchParticles: params.enableTouchParticles,
    rainbowPaletteHex: params.rainbowPaletteHex,
    touchParticleText: params.touchParticleText,
  };

  const dexBytes = compileRealDalvikDex(dexCfg);
  const smaliPreview = generateDisassembledSmaliText(dexCfg);

  const primaryHook = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsLayout;->show(Landroid/content/Context;)V`;
  const secondaryHook = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsLayout;->buildLayout(Landroid/content/Context;)Landroid/widget/LinearLayout;`;
  const tertiaryHook = `invoke-static {p0}, Lcom/nsmods/xmlcreator/NsModsLayout;->show(Landroid/content/Context;)V`;

  const guideText = buildUniversalModdingGuide({
    toolTitle: `Layout XML Creator (${params.rootContainer} • ${params.widgets.length} Widgets • Pure Layout)`,
    className,
    primaryHook,
    secondaryHook,
    tertiaryHook,
    descriptionEn:
      displayMode === 'layout_fullscreen'
        ? 'Render Pure Full-Screen Android Layout in MainActivity (No Popup Dialog!)'
        : 'Render Pure Overlay / Floating Panel Layout on MainActivity (No Popup Dialog!)',
    descriptionBn:
      displayMode === 'layout_fullscreen'
        ? 'MainActivity-তে সরাসরি পূর্ণাঙ্গ কাস্টম লেআউট স্ক্রিন সেট করা (কোনো পপআপ ডায়ালগ বা Join Telegram বাটন ছাড়া!)'
        : 'MainActivity স্ক্রিনের ওপর ফ্লোটিং/ওভারলে লেআউট প্যানেল বসানো (কোনো পপআপ ডায়ালগ ছাড়া!)',
    compiledSmaliPreview: smaliPreview,
    isPureLayout: true,
  });

  const zip = new JSZip();
  zip.file('classes2.dex', dexBytes);
  zip.file('classes.dex', dexBytes);
  zip.file('GUIDE.txt', guideText);

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  return {
    zipBlob,
    dexBytes,
    guideText,
    smaliPreview,
    primaryHook,
    secondaryHook,
    tertiaryHook,
    fileName: 'NsMods_Layout_Dex_Package.zip',
  };
}

export interface TextAnimPackageConfig {
  text: string;
  effect: string;
  fontStyle: string;
  textSizeSp: number;
  durationMs: number;
  strokeWidthPx: number;
  glowRadiusPx: number;
  textColor: string;
  gradientColor: string;
  strokeColor: string;
  glowColor: string;
  useGradientShader: boolean;
  enableGlobalApkText?: boolean;
  enableTouchParticles?: boolean;
  rainbowPaletteHex?: string[];
  touchParticleText?: string;
}

export async function generateTextAnimationZip(cfg: TextAnimPackageConfig): Promise<{
  zipBlob: Blob;
  dexBlob: Blob;
  guideText: string;
  smaliPreview: string;
  primaryHook: string;
  secondaryHook: string;
  fileName: string;
}> {
  const zip = new JSZip();
  const className = 'NsModsAnimatedTextView';

  const isGlobalApkOnly = cfg.enableGlobalApkText !== false;
  const dexCfg: DexDialogConfig = {
    className,
    entryMethodName: 'show',
    title: cfg.text || 'NS MODS XML CREATOR',
    message: '',
    positiveBtnText: '',
    negativeBtnText: '',
    telegramUrl: 'https://t.me/Sharechat_ns_098',
    bgColorHex: '#091519',
    accentColorHex: cfg.glowColor || cfg.textColor || '#00F5D4',
    textColorHex: cfg.gradientColor || '#FF0055',
    cornerRadiusDp: 14,
    strokeWidthDp: Math.max(1, cfg.strokeWidthPx),
    extraConfigTag: `TEXT_ANIM_${cfg.effect}`,
    animDurationMs: cfg.durationMs,
    executionMode: isGlobalApkOnly ? 'apk_global_fx' : 'layout_overlay',
    enableRainbowText: true,
    enableGlobalApkText: cfg.enableGlobalApkText !== false,
    enableTouchParticles: cfg.enableTouchParticles !== false,
    rainbowPaletteHex: cfg.rainbowPaletteHex,
    touchParticleText: cfg.touchParticleText,
    textGlowRadiusPx: cfg.glowRadiusPx || 12,
    infiniteTextWave: true,
    layoutWidgets: [
      {
        type: 'TextView',
        text: cfg.text || 'NS MODS XML CREATOR',
        textColorHex: cfg.textColor || '#00F5D4',
        bgColorHex: '#091519',
        paddingDp: 12,
        marginDp: 6,
        textSizeSp: cfg.textSizeSp || 18,
        cornerRadiusDp: 14,
        strokeWidthDp: Math.max(1, cfg.strokeWidthPx),
        strokeColorHex: cfg.strokeColor || '#00F5D4',
      },
    ],
  };

  const dexBytes = compileRealDalvikDex(dexCfg);
  const smaliPreview = generateDisassembledSmaliText(dexCfg);

  const primaryHook = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsAnimatedTextView;->show(Landroid/content/Context;)V`;
  const secondaryHook = `invoke-static {v0, v1}, Lcom/nsmods/xmlcreator/NsModsAnimatedTextView;->walkAndStyle(Landroid/view/View;I)V`;

  const guideText = buildUniversalModdingGuide({
    toolTitle: `Rainbow Text Wave & Touch Star FX (${cfg.effect})`,
    className,
    primaryHook,
    secondaryHook,
    descriptionEn:
      'Transform ALL TextViews & Buttons in ANY APK into Flowing Rainbow Wave Text + Add Touch Star Particle Animation',
    descriptionBn:
      'যেকোনো APK-এর সব লেখাকে (TextView/Button) রঙিন অ্যানিমেটেড করা এবং স্ক্রিনে টাচ করলে তারার (Touch Star Particle) অ্যানিমেশন যুক্ত করা!',
    compiledSmaliPreview: smaliPreview,
    isPureLayout: true,
  });

  const dexBlob = new Blob([dexBytes.buffer as ArrayBuffer], {
    type: 'application/octet-stream',
  });

  // Strictly classes2.dex + classes.dex + GUIDE.txt (no res/ folder clutter!)
  zip.file('classes2.dex', dexBytes);
  zip.file('classes.dex', dexBytes);
  zip.file('GUIDE.txt', guideText);

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  return {
    zipBlob,
    dexBlob,
    guideText,
    smaliPreview,
    primaryHook,
    secondaryHook,
    fileName: 'NsMods_TextAnimation_Package.zip',
  };
}

export function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 2500);
}
