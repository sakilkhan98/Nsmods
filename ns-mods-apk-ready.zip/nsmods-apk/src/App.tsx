import React, { useEffect, useState } from 'react';
import { AmbientAndParticleCanvas } from './components/AmbientAndParticleCanvas';
import { AnimatedText } from './components/AnimatedText';
import {
  AdvancedDialogMakerScreen,
  AndroidAnimationMakerScreen,
  NotificationDesignerScreen,
  TextAnimationMakerScreen,
} from './components/AnimationAndNotificationScreens';
import { JavaKotlinConverterScreen } from './components/JavaKotlinConverterScreen';
import {
  AboutDeveloperScreen,
  ConversionAnimationsScreen,
  SettingsScreen,
  TransitionAnimationsScreen,
} from './components/SettingsAndDeveloperScreens';
import {
  LayoutXmlCreatorScreen,
  XmlDrawableCreatorScreen,
} from './components/XmlCreatorScreens';
import {
  ButtonCreatorScreen,
  CustomToastMakerScreen,
  FloatingModMenuMakerScreen,
  RainbowTouchFxCreatorScreen,
  SmaliHookVaultScreen,
  SplashScreenMakerScreen,
} from './components/NewModdingToolsScreens';
import {
  SmaliBranchPatcherScreen,
  NativeSoHexPatcherScreen,
} from './components/PureModdingToolsScreens';
import {
  HistoryModal,
  ImportXmlModal,
  PresetsModal,
} from './components/XmlCustomModals';
import {
  ApkAndDriveCenterModal,
} from './components/ApkAndDriveCenterModal';
import {
  CONVERSION_SHADERS,
  DEFAULT_SETTINGS,
  SCREEN_TRANSITIONS,
  XML_PRESETS,
  XmlPresetItem,
  createInitialDrawableConfig,
} from './data/fxCatalog';
import {
  AppSettings,
  ConversionShaderItem,
  HistoryEntry,
  ScreenId,
  StateDrawableConfig,
  TransitionItem,
} from './types/appTypes';
import {
  parseImportedXml,
  triggerBlobDownload,
} from './utils/packageGenerator';
import { usePwaAndOffline } from './utils/usePwaAndOffline';

const STORAGE_KEY_SETTINGS = 'ns_mods_settings_v3_rainbow';
const STORAGE_KEY_HISTORY = 'ns_mods_history_v1';

interface ToastData {
  id: number;
  title: string;
  subtitle: string;
}

const HOME_TOOLS: Array<{ id: ScreenId; label: string }> = [
  { id: 'smali_branch_patcher', label: '🛠️ Smali Branch Inverter & Opcode NOP Studio' },
  { id: 'native_so_hex_patcher', label: '🎯 Native .so ARM64 Hex Patcher Studio' },
  { id: 'floating_mod_menu', label: 'Floating Mod Menu Maker (Heavy VIP)' },
  { id: 'button_creator', label: 'VIP Button Creator (Link + Animation + DEX)' },
  { id: 'rainbow_touch_fx', label: 'Rainbow Text, Touch & Screen Rain/Bubble FX' },
  { id: 'dialog_maker', label: 'Advanced Dialog Maker (Pro + Remote JSON)' },
  { id: 'smali_snippets', label: 'Smali Hook & v15 Register Error Fixer' },
  { id: 'splash_maker', label: 'Splash Screen & Intro Maker' },
  { id: 'xml_layout', label: 'Layout XML Creator (Pure Layout)' },
  { id: 'xml_3d', label: '3D / Layer XML Creator' },
  { id: 'xml_gradient', label: 'Gradient XML Creator' },
  { id: 'xml_normal', label: 'Normal XML Creator' },
  { id: 'xml_ripple', label: 'Ripple XML Creator' },
  { id: 'toast_maker', label: 'Custom Toast & Banner Maker' },
  { id: 'java_kotlin', label: 'Java ↔ Kotlin Converter' },
  { id: 'android_anim', label: 'Android Animation Maker' },
  { id: 'text_anim', label: 'Text Animation Maker' },
  { id: 'notification_designer', label: 'Notification Designer' },
];

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  const [currentScreen, setCurrentScreen] = useState<ScreenId>('home');
  const [drawableConfig, setDrawableConfig] = useState<StateDrawableConfig>(() =>
    createInitialDrawableConfig()
  );

  const [customTransitions, setCustomTransitions] = useState<TransitionItem[]>([]);
  const [customShaders, setCustomShaders] = useState<ConversionShaderItem[]>([]);

  const [history, setHistory] = useState<HistoryEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [];
  });

  // Modals on Home Screen
  const [showPresetsModal, setShowPresetsModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [showApkDriveModal, setShowApkDriveModal] = useState(false);

  // Toast Notification state
  const [toast, setToast] = useState<ToastData | null>(null);

  // Screen Transition Animation State
  const [transitionAnimStyle, setTransitionAnimStyle] =
    useState<React.CSSProperties>({});

  const { isInstallable, isOnline, promptInstall } = usePwaAndOffline();

  // Sync settings to localStorage & document theme
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch {
      // ignore storage quota errors
    }

    document.documentElement.setAttribute('data-theme', settings.theme);
    const mult =
      settings.masterSpeed === 'Turbo'
        ? '0.45'
        : settings.masterSpeed === 'Fast'
        ? '0.7'
        : settings.masterSpeed === 'Slow'
        ? '1.5'
        : '1';
    document.documentElement.style.setProperty('--anim-speed-mult', mult);
  }, [settings]);

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(history));
    } catch {
      // ignore
    }
  }, [history]);

  const showToast = (title: string, subtitle: string) => {
    const id = Date.now();
    setToast({ id, title, subtitle });
  };

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => {
      setToast(null);
    }, 3400);
    return () => clearTimeout(timer);
  }, [toast]);

  // Compute Ultra-Soft & Clean Screen Transition effect (zero-jank GPU compositor glide)
  const triggerScreenTransitionEffect = (transitionId: number) => {
    let initialTransform = 'translateY(8px) scale(0.99)';
    if (transitionId === 1) initialTransform = 'translateX(14px)';
    else if (transitionId === 2) initialTransform = 'translateY(12px)';
    else if (transitionId === 3 || transitionId === 10)
      initialTransform = 'scale(0.975)';

    setTransitionAnimStyle({
      transform: initialTransform,
      opacity: 0.72,
      transition: 'none',
    });

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        setTransitionAnimStyle({
          transform: 'translate3d(0, 0, 0) scale(1)',
          opacity: 1,
          transition:
            'transform 0.26s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.22s ease-out',
        });
      });
    });
  };

  const navigateTo = (target: ScreenId) => {
    let tid = settings.activeTransitionId;
    const allTrans = [...SCREEN_TRANSITIONS, ...customTransitions];
    if (settings.transitionShuffleMode === 'shuffle_all') {
      tid = allTrans[Math.floor(Math.random() * allTrans.length)].id;
    } else if (settings.transitionShuffleMode === 'shuffle_cyber') {
      const cyberList = allTrans.filter((t) => t.category === 'HACKING');
      if (cyberList.length > 0) {
        tid = cyberList[Math.floor(Math.random() * cyberList.length)].id;
      }
    }
    window.scrollTo(0, 0);
    triggerScreenTransitionEffect(tid);
    setCurrentScreen(target);
  };

  const addHistoryEntry = (title: string, code: string) => {
    const entry: HistoryEntry = {
      id: `h_${Date.now()}`,
      title,
      tool: currentScreen,
      timestamp: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
      code,
      type: 'xml',
    };
    setHistory((prev) => [entry, ...prev.slice(0, 39)]);
  };

  const handleLoadPreset = (preset: XmlPresetItem) => {
    setDrawableConfig(JSON.parse(JSON.stringify(preset.config)));
    navigateTo(preset.targetScreen);
    showToast('Preset Loaded!', `${preset.name} opened in editor.`);
  };

  const handleImportXml = (xmlString: string) => {
    const { config, detectedMode } = parseImportedXml(xmlString);
    setDrawableConfig(config);
    navigateTo(detectedMode);
    showToast(
      'XML Imported Successfully',
      'Parsed layers, gradients & states into live editor.'
    );
  };

  // Dynamic CSS helper classes from Settings
  const microClass =
    settings.buttonMicro === 'Spring'
      ? 'btn-micro-spring'
      : settings.buttonMicro === 'Pop'
      ? 'btn-micro-pop'
      : settings.buttonMicro === 'Glow'
      ? 'btn-micro-glow'
      : settings.buttonMicro === 'Squeeze'
      ? 'btn-micro-squeeze'
      : '';

  const glowClass =
    settings.glowBorder === 'Matrix'
      ? 'glow-border-matrix'
      : settings.glowBorder === 'Cyber'
      ? 'glow-border-cyber'
      : settings.glowBorder === 'Solar'
      ? 'glow-border-solar'
      : settings.glowBorder === 'Rainbow'
      ? 'glow-border-rainbow'
      : 'glow-border-off';

  const staggerClass =
    settings.staggerStyle === 'Cascade'
      ? 'stagger-cascade'
      : settings.staggerStyle === 'Pop'
      ? 'stagger-pop'
      : settings.staggerStyle === 'Horizontal'
      ? 'stagger-horizontal'
      : '';

  // Active Conversion Shader ID (handling shuffle modes)
  const getEffectiveShaderId = () => {
    const allShaders = [...CONVERSION_SHADERS, ...customShaders];
    if (settings.conversionShuffleMode === 'shuffle_all') {
      return allShaders[Math.floor(Math.random() * allShaders.length)].id;
    }
    if (settings.conversionShuffleMode === 'shuffle_hack') {
      const hack = allShaders.filter((s) => s.category === 'HACKING');
      if (hack.length > 0) {
        return hack[Math.floor(Math.random() * hack.length)].id;
      }
    }
    return settings.activeConversionShaderId;
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-start py-2 px-2 sm:py-4 sm:px-4 select-none">
      {/* Live Ambient Background & Touch Tap Particle Bursts Canvas */}
      <AmbientAndParticleCanvas
        ambientBg={settings.ambientBg}
        touchParticle={settings.touchParticle}
      />

      {/* Main Mobile-First Cyber HUD Container Frame (Matches Video 00:03 - 04:48) */}
      <div
        style={transitionAnimStyle}
        className={`relative z-10 w-full max-w-[460px] min-h-[calc(100vh-16px)] sm:min-h-[820px] rounded-[22px] border-2 bg-[var(--bg-primary)]/90 backdrop-blur-sm p-3.5 sm:p-4 flex flex-col justify-between ${glowClass}`}
      >
        {/* Corner HUD Brackets (Top-Left, Top-Right, Bottom-Left, Bottom-Right) */}
        <div className="pointer-events-none absolute top-1.5 left-1.5 w-3.5 h-3.5 border-t-2 border-l-2 border-[#00f5d4]" />
        <div className="pointer-events-none absolute top-1.5 right-1.5 w-3.5 h-3.5 border-t-2 border-r-2 border-[#00f5d4]" />
        <div className="pointer-events-none absolute bottom-1.5 left-1.5 w-3.5 h-3.5 border-b-2 border-l-2 border-[#00f5d4]" />
        <div className="pointer-events-none absolute bottom-1.5 right-1.5 w-3.5 h-3.5 border-b-2 border-r-2 border-[#00f5d4]" />

        <div className="flex-1 flex flex-col">
          {/* ================================================================
             HOME SCREEN (Video 00:03 - 00:05, 01:32, 02:35)
          ================================================================ */}
          {currentScreen === 'home' && (
            <div className="flex flex-col pb-4">
              {/* Top App Title Bar */}
              <div className="relative flex items-center justify-between pt-1 pb-3.5 mb-1">
                {/* Offline / Version / Cache Refresh Pill Badge */}
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      if ('caches' in window) {
                        const keys = await caches.keys();
                        await Promise.all(keys.map((k) => caches.delete(k)));
                      }
                      if ('serviceWorker' in navigator) {
                        const regs =
                          await navigator.serviceWorker.getRegistrations();
                        await Promise.all(regs.map((r) => r.unregister()));
                      }
                    } catch {
                      // ignore
                    }
                    showToast(
                      'v10.0 Crash-Free Engine Active ✓',
                      'Cache cleared! Loading latest v10.0 Pro tools...'
                    );
                    setTimeout(() => window.location.reload(), 600);
                  }}
                  className="px-2.5 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0a181c] text-[10px] font-mono font-bold text-[#00f5d4] flex items-center gap-1"
                  title="Tap to Refresh Latest v10.0 Update"
                >
                  <span>{isOnline ? '⚡' : '📴'}</span>
                  <span>{isOnline ? 'v10.0 PRO ↻' : 'OFFLINE v10'}</span>
                </button>

                {/* Main Brand Title: @Nsmods */}
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-wide text-[#00f5d4] drop-shadow-[0_0_12px_rgba(0,245,212,0.45)] text-center">
                  <AnimatedText text="@Nsmods" config={settings.typing} />
                </h1>

                {/* Theme Mode & Install Quick Action */}
                <div className="flex items-center gap-1.5">
                  {isInstallable && (
                    <button
                      type="button"
                      onClick={promptInstall}
                      className="px-2 py-1 rounded-lg border border-[#00ff88] bg-[#0b2922] text-[10px] font-bold text-[#00ff88]"
                    >
                      ⬇ App
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      const next =
                        settings.theme === 'cyber'
                          ? 'amoled'
                          : settings.theme === 'amoled'
                          ? 'light'
                          : 'cyber';
                      setSettings((prev) => ({ ...prev, theme: next }));
                      showToast(
                        'Theme Mode Switched',
                        next === 'cyber'
                          ? 'Cyber Dark Theme'
                          : next === 'amoled'
                          ? 'AMOLED Pitch Black'
                          : 'Clean Light Mode'
                      );
                    }}
                    className="w-8 h-8 rounded-lg border border-[#00f5d4]/50 bg-[#0a181c] flex items-center justify-center text-xs"
                    title="Switch Dark / Light Theme"
                  >
                    {settings.theme === 'light'
                      ? '☀️'
                      : settings.theme === 'amoled'
                      ? '🌑'
                      : '🌙'}
                  </button>
                </div>
              </div>

              {/* Top 2x2 Utility Grid: Presets | History | Import XML | Settings */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <button
                  type="button"
                  onClick={() => setShowPresetsModal(true)}
                  className={`rounded-2xl border-2 bg-[#091519] p-1 ${glowClass} ${microClass} ${staggerClass}`}
                >
                  <div className="w-full h-full rounded-xl border border-[#00f5d4]/40 bg-[#0c1a1f] py-3 px-3.5 flex items-center gap-2.5">
                    <span className="text-[#00f5d4] text-base font-bold">↻</span>
                    <span className="text-xs sm:text-sm font-bold text-[#00f5d4]">
                      <AnimatedText text="Presets" config={settings.typing} />
                    </span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShowHistoryModal(true)}
                  className={`rounded-2xl border-2 bg-[#091519] p-1 ${glowClass} ${microClass} ${staggerClass}`}
                >
                  <div className="w-full h-full rounded-xl border border-[#00f5d4]/40 bg-[#0c1a1f] py-3 px-3.5 flex items-center gap-2.5">
                    <span className="text-slate-200 text-sm">❐</span>
                    <span className="text-xs sm:text-sm font-bold text-white">
                      <AnimatedText text="History" config={settings.typing} />
                    </span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShowImportModal(true)}
                  className={`rounded-2xl border-2 bg-[#091519] p-1 ${glowClass} ${microClass} ${staggerClass}`}
                >
                  <div className="w-full h-full rounded-xl border border-[#00f5d4]/40 bg-[#0c1a1f] py-3 px-3.5 flex items-center gap-2.5">
                    <span className="text-[#00ff88] text-sm">☁</span>
                    <span className="text-xs sm:text-sm font-bold text-[#00ff88]">
                      <AnimatedText
                        text="Import XML"
                        config={settings.typing}
                      />
                    </span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => navigateTo('settings')}
                  className={`rounded-2xl border-2 bg-[#091519] p-1 ${glowClass} ${microClass} ${staggerClass}`}
                >
                  <div className="w-full h-full rounded-xl border border-[#00f5d4]/40 bg-[#0c1a1f] py-3 px-3.5 flex items-center gap-2.5">
                    <span className="text-[#ff2a85] text-sm font-bold">→</span>
                    <span className="text-xs sm:text-sm font-bold text-[#ff2a85]">
                      <AnimatedText text="Settings" config={settings.typing} />
                    </span>
                  </div>
                </button>
              </div>

              {/* 10 Main Tool Cards List (Exact Double-Bordered Cyber Buttons from Video 00:04 & 01:32) */}
              <div className="space-y-3">
                {HOME_TOOLS.map((tool, index) => (
                  <button
                    key={tool.id}
                    type="button"
                    style={{ animationDelay: `${index * 35}ms` }}
                    onClick={() => navigateTo(tool.id)}
                    className={`w-full rounded-2xl border-2 bg-[#091519] p-1.5 text-left transition-all ${glowClass} ${microClass} ${staggerClass}`}
                  >
                    <div className="w-full rounded-xl border border-[#00f5d4]/45 bg-[#0c1a1f] hover:bg-[#102329] py-3.5 px-4 flex items-center justify-between">
                      <span className="text-sm sm:text-[15px] font-bold text-white tracking-wide">
                        <AnimatedText
                          text={tool.label}
                          config={settings.typing}
                        />
                      </span>
                      <span className="text-xs text-[#00f5d4]/70 font-mono">
                        ›
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ================================================================
             SETTINGS & SUBSCREENS
          ================================================================ */}
          {currentScreen === 'settings' && (
            <SettingsScreen
              settings={settings}
              setSettings={setSettings}
              customTransitions={customTransitions}
              setCustomTransitions={setCustomTransitions}
              customShaders={customShaders}
              setCustomShaders={setCustomShaders}
              microClass={microClass}
              glowClass={glowClass}
              staggerClass={staggerClass}
              onNavigate={navigateTo}
              onTriggerScreenTransition={triggerScreenTransitionEffect}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'transitions' && (
            <TransitionAnimationsScreen
              settings={settings}
              setSettings={setSettings}
              customTransitions={customTransitions}
              setCustomTransitions={setCustomTransitions}
              customShaders={customShaders}
              setCustomShaders={setCustomShaders}
              microClass={microClass}
              glowClass={glowClass}
              staggerClass={staggerClass}
              onNavigate={navigateTo}
              onTriggerScreenTransition={triggerScreenTransitionEffect}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'conversion_shaders' && (
            <ConversionAnimationsScreen
              settings={settings}
              setSettings={setSettings}
              customTransitions={customTransitions}
              setCustomTransitions={setCustomTransitions}
              customShaders={customShaders}
              setCustomShaders={setCustomShaders}
              microClass={microClass}
              glowClass={glowClass}
              staggerClass={staggerClass}
              onNavigate={navigateTo}
              onTriggerScreenTransition={triggerScreenTransitionEffect}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'about_developer' && (
            <AboutDeveloperScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('settings')}
              onShowToast={showToast}
            />
          )}

          {/* ================================================================
             XML DRAWABLE & LAYOUT CREATORS
          ================================================================ */}
          {(currentScreen === 'xml_3d' ||
            currentScreen === 'xml_gradient' ||
            currentScreen === 'xml_normal' ||
            currentScreen === 'xml_ripple') && (
            <XmlDrawableCreatorScreen
              mode={
                currentScreen === 'xml_3d'
                  ? '3d'
                  : currentScreen === 'xml_gradient'
                  ? 'gradient'
                  : currentScreen === 'xml_normal'
                  ? 'normal'
                  : 'ripple'
              }
              config={drawableConfig}
              setConfig={setDrawableConfig}
              xmlIndentation={settings.xmlIndentation}
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'xml_layout' && (
            <LayoutXmlCreatorScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {/* ================================================================
             JAVA <-> KOTLIN CONVERTER
          ================================================================ */}
          {currentScreen === 'java_kotlin' && (
            <JavaKotlinConverterScreen
              activeShaderId={getEffectiveShaderId()}
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onOpenHistory={() => setShowHistoryModal(true)}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {/* ================================================================
             ANIMATION, DIALOG & NOTIFICATION MAKERS
          ================================================================ */}
          {currentScreen === 'android_anim' && (
            <AndroidAnimationMakerScreen
              activeShaderId={getEffectiveShaderId()}
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'text_anim' && (
            <TextAnimationMakerScreen
              activeShaderId={getEffectiveShaderId()}
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'dialog_maker' && (
            <AdvancedDialogMakerScreen
              activeShaderId={getEffectiveShaderId()}
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'notification_designer' && (
            <NotificationDesignerScreen
              activeShaderId={getEffectiveShaderId()}
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'floating_mod_menu' && (
            <FloatingModMenuMakerScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'toast_maker' && (
            <CustomToastMakerScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'splash_maker' && (
            <SplashScreenMakerScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'smali_snippets' && (
            <SmaliHookVaultScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'rainbow_touch_fx' && (
            <RainbowTouchFxCreatorScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'button_creator' && (
            <ButtonCreatorScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'smali_branch_patcher' && (
            <SmaliBranchPatcherScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}

          {currentScreen === 'native_so_hex_patcher' && (
            <NativeSoHexPatcherScreen
              typingConfig={settings.typing}
              microClass={microClass}
              glowClass={glowClass}
              onBack={() => navigateTo('home')}
              onSaveHistory={addHistoryEntry}
              onShowToast={showToast}
            />
          )}
        </div>
      </div>

      {/* Bottom Floating Toast Banner (Matches Video 00:09, 00:22, 01:14, 02:45, 03:09) */}
      {toast && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-[420px] rounded-2xl border-2 border-[#00f5d4] bg-[#081519]/95 backdrop-blur-md p-3 shadow-[0_0_25px_rgba(0,245,212,0.35)] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl border border-[#00f5d4] bg-[#0d262e] flex items-center justify-center text-[#00f5d4] text-base shrink-0">
              ✨
            </div>
            <div className="min-w-0">
              <div className="text-xs font-extrabold text-[#00f5d4] truncate">
                {toast.title}
              </div>
              <div className="text-[11px] text-slate-200 truncate mt-0.5">
                {toast.subtitle}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="text-slate-400 hover:text-white px-2 py-1 text-sm shrink-0"
          >
            ✕
          </button>
        </div>
      )}

      {/* Home Utility Modals */}
      <PresetsModal
        isOpen={showPresetsModal}
        onClose={() => setShowPresetsModal(false)}
        onSelectPreset={handleLoadPreset}
      />

      <HistoryModal
        isOpen={showHistoryModal}
        history={history}
        onClose={() => setShowHistoryModal(false)}
        onCopy={(code) => {
          navigator.clipboard.writeText(code);
          showToast('Copied!', 'Code copied from workspace history.');
        }}
        onClearHistory={() => {
          setHistory([]);
          showToast('History Cleared', 'All saved entries removed.');
        }}
      />

      <ImportXmlModal
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        onImport={handleImportXml}
      />

      <ApkAndDriveCenterModal
        isOpen={showApkDriveModal}
        onClose={() => setShowApkDriveModal(false)}
        isInstallable={isInstallable}
        onPromptInstall={promptInstall}
        onShowToast={showToast}
      />
    </div>
  );
}
