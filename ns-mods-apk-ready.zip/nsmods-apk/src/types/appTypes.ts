export type ScreenId =
  | 'home'
  | 'settings'
  | 'transitions'
  | 'conversion_shaders'
  | 'about_developer'
  | 'xml_3d'
  | 'xml_gradient'
  | 'xml_normal'
  | 'xml_layout'
  | 'xml_ripple'
  | 'java_kotlin'
  | 'android_anim'
  | 'text_anim'
  | 'dialog_maker'
  | 'notification_designer'
  | 'floating_mod_menu'
  | 'toast_maker'
  | 'splash_maker'
  | 'smali_snippets'
  | 'rainbow_touch_fx'
  | 'button_creator'
  | 'manifest_architect'
  | 'smali_obfuscator'
  | 'smali_branch_patcher'
  | 'native_so_hex_patcher';

export type ThemeMode = 'cyber' | 'amoled' | 'light';

export type MasterSpeed = 'Normal' | 'Fast' | 'Slow' | 'Turbo';

export type StaggerStyle = 'Disabled' | 'Cascade' | 'Pop' | 'Horizontal';

export type ButtonMicroStyle = 'Disabled' | 'Spring' | 'Glow' | 'Squeeze' | 'Pop';

export type AmbientBgStyle =
  | 'None'
  | 'Starfield'
  | 'Matrix'
  | 'Quantum'
  | 'Embers'
  | 'Frosted';

export type GlowBorderStyle = 'Matrix' | 'Cyber' | 'Solar' | 'Rainbow' | 'Off';

export type TouchParticleStyle =
  | 'None'
  | 'Golden'
  | 'Neon'
  | 'Fairy'
  | 'Fire'
  | 'Hearts'
  | 'Bubbles'
  | 'Water'
  | 'Crystals'
  | 'MatrixRain'
  | 'Sakura'
  | 'Ice'
  | 'Starlight'
  | 'Laser';

export interface TypingConfig {
  enabled: boolean;
  loopContinuous: boolean;
  speedMs: number;
  cursorStyle: 'Bar (|)' | 'Block (█)' | 'Underscore (_)' | 'None';
  pauseSec: number;
  styleId: number; // 1 to 18
}

export interface TransitionItem {
  id: number;
  name: string;
  category: 'CLASSIC' | 'CINEMATIC' | 'HACKING';
  isCustom?: boolean;
}

export interface ConversionShaderItem {
  id: number;
  name: string;
  category: 'CINEMATIC' | 'HACKING' | 'CUSTOM';
  engine?: string;
  themeColor?: string;
}

export interface AppSettings {
  theme: ThemeMode;
  activeTransitionId: number;
  transitionShuffleMode: 'selected' | 'shuffle_all' | 'shuffle_cyber';
  activeConversionShaderId: number;
  conversionShuffleMode: 'fixed' | 'shuffle_all' | 'shuffle_hack';
  masterSpeed: MasterSpeed;
  staggerStyle: StaggerStyle;
  touchParticle: TouchParticleStyle;
  buttonMicro: ButtonMicroStyle;
  ambientBg: AmbientBgStyle;
  glowBorder: GlowBorderStyle;
  typing: TypingConfig;
  xmlIndentation: '4 Spaces' | '2 Spaces' | 'Tabs';
}

export interface DrawableLayer {
  id: number;
  enabled: boolean;
  startColor: string; // 'None' or '#RRGGBB' / '#AARRGGBB'
  centerColor: string;
  endColor: string;
  useCenterColor: boolean;
  gradientType: 'Linear' | 'Radial' | 'Sweep';
  angle: number; // 0 to 360 step 45
  strokeColor: string; // 'None' or hex
  strokeWidth: number; // dp
  dashWidth: number;
  dashGap: number;
  cornerRadius: number;
  useIndividualCorners: boolean;
  topLeftRadius: number;
  topRightRadius: number;
  bottomLeftRadius: number;
  bottomRightRadius: number;
  insetLeft: number;
  insetTop: number;
  insetRight: number;
  insetBottom: number;
}

export interface StateDrawableConfig {
  normal: DrawableLayer[];
  checked: DrawableLayer[];
  pressed: DrawableLayer[];
  rippleColor: string;
}

export interface HistoryEntry {
  id: string;
  title: string;
  tool: string;
  timestamp: string;
  code: string;
  type: 'xml' | 'code' | 'package';
}
