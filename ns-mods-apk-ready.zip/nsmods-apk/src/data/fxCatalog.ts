import {
  AppSettings,
  ConversionShaderItem,
  DrawableLayer,
  StateDrawableConfig,
  TransitionItem,
} from '../types/appTypes';

export const SCREEN_TRANSITIONS: TransitionItem[] = [
  { id: 1, name: 'Slide Horizontal (Classic)', category: 'CLASSIC' },
  { id: 2, name: 'Slide Vertical (Modern)', category: 'CLASSIC' },
  { id: 3, name: 'Fluid Zoom & Fade', category: 'CINEMATIC' },
  { id: 4, name: 'Bounce & Pop (Playful)', category: 'CLASSIC' },
  { id: 5, name: '3D Card Flip Horizontal', category: 'CINEMATIC' },
  { id: 6, name: 'Accordion Fold', category: 'CLASSIC' },
  { id: 7, name: 'Portal Iris Expand', category: 'CINEMATIC' },
  { id: 8, name: 'Rotate & Cascade', category: 'CINEMATIC' },
  { id: 9, name: 'Shutter Split', category: 'HACKING' },
  { id: 10, name: 'Cinema Depth Zoom', category: 'CINEMATIC' },
  { id: 11, name: 'Cyber Vortex Spin', category: 'HACKING' },
  { id: 12, name: 'Quantum Hyperdrive', category: 'CINEMATIC' },
  { id: 13, name: '3D Vertical Flip', category: 'CINEMATIC' },
  { id: 14, name: 'Pendulum Arc Swing', category: 'CLASSIC' },
  { id: 15, name: 'Origami Unfold', category: 'CINEMATIC' },
  { id: 16, name: 'Gravity Bounce Drop', category: 'CLASSIC' },
  { id: 17, name: 'Kaleidoscope Twist', category: 'CINEMATIC' },
  { id: 18, name: 'Boomerang Arc', category: 'CINEMATIC' },
  { id: 19, name: 'Velvet Silk Dissolve', category: 'CINEMATIC' },
  { id: 20, name: 'Rocket Boost Launch', category: 'CINEMATIC' },
  { id: 21, name: 'Cyber Glitch Breach', category: 'HACKING' },
  { id: 22, name: 'Matrix Terminal Rain', category: 'HACKING' },
  { id: 23, name: 'Gargantua Singularity Vortex', category: 'CINEMATIC' },
  { id: 24, name: 'Cyber Katana Slash', category: 'HACKING' },
  { id: 25, name: 'Holographic Parallax', category: 'HACKING' },
];

export const CONVERSION_SHADERS: ConversionShaderItem[] = [
  { id: 1, name: 'Quantum Core Reactor', category: 'CINEMATIC' },
  { id: 2, name: 'Matrix Digital Breach (Hacker Rain)', category: 'HACKING' },
  { id: 3, name: 'AI Neural Synapse Cortex', category: 'CINEMATIC' },
  { id: 4, name: 'Singularity Blackhole Horizon', category: 'CINEMATIC' },
  { id: 5, name: 'Eldritch Mandala & Mech HUD', category: 'CINEMATIC' },
  { id: 6, name: 'Crystal Prism Refraction', category: 'CINEMATIC' },
  { id: 7, name: 'Supernova Plasma Core', category: 'CINEMATIC' },
  { id: 8, name: 'Cyber Katana AST Slicer', category: 'HACKING' },
  { id: 9, name: 'Holographic Hex Grid', category: 'HACKING' },
  { id: 10, name: 'Bio-Digital DNA Helix', category: 'CINEMATIC' },
  { id: 11, name: 'Neon Synthwave Overdrive', category: 'CINEMATIC' },
  { id: 12, name: 'Dark Matter Collider', category: 'CINEMATIC' },
  { id: 13, name: 'Chrono Time Vortex', category: 'CINEMATIC' },
  { id: 14, name: 'Orbital Laser Uplink', category: 'HACKING' },
  { id: 15, name: 'Glitch Phantom Protocol', category: 'HACKING' },
  { id: 16, name: 'Arcane Runic Compiler', category: 'CINEMATIC' },
  { id: 17, name: 'Hypercube 4D Tesseract', category: 'HACKING' },
];

export interface TypingStyleItem {
  id: number;
  name: string;
  shortTag: string;
  description: string;
}

export const TYPING_STYLES: TypingStyleItem[] = [
  {
    id: 1,
    name: 'Classic Typewriter (Cursor)',
    shortTag: 'Typewriter',
    description: 'Types character by character with blinking terminal cursor & auto-rewind loop',
  },
  {
    id: 2,
    name: 'Cyber Hacker Scramble',
    shortTag: 'Hacker',
    description: 'Letters rapidly scramble with cyber symbols before resolving cleanly',
  },
  {
    id: 3,
    name: 'Neon Tube Glow Pulse',
    shortTag: 'Neon',
    description: 'Glowing neon tube pulse that sweeps across words with breathing brightness',
  },
  {
    id: 4,
    name: 'Rainbow Spectrum Shimmer',
    shortTag: 'Rainbow',
    description: 'Dynamic iridescent rainbow spectrum gradient traveling across characters',
  },
  {
    id: 5,
    name: 'Bounce Letter Drop',
    shortTag: 'Bounce',
    description: 'Playful letter-by-letter spring drop-in from top into position',
  },
  {
    id: 6,
    name: 'Cinematic Smooth Fade',
    shortTag: 'Fade',
    description: 'High-end cinematic word-by-word smooth alpha & tracking transition',
  },
  {
    id: 7,
    name: 'Matrix Code Cascade',
    shortTag: 'Matrix',
    description: 'Digital green katakana & binary code decoding across each character',
  },
  {
    id: 8,
    name: 'Glitch Chromatic Shift',
    shortTag: 'Glitch',
    description: 'RGB split cyber glitch displacement with rapid recovery',
  },
  {
    id: 9,
    name: 'Liquid Gold Wave',
    shortTag: 'Gold',
    description: 'Metallic golden sheen flowing smoothly across letters',
  },
  {
    id: 10,
    name: 'Plasma Energy Surge',
    shortTag: 'Plasma',
    description: 'High-voltage magenta and cyan plasma wave pulsing through text',
  },
  {
    id: 11,
    name: 'Quantum Phase Blink',
    shortTag: 'Quantum',
    description: 'Sub-atomic phase flicker reveal with quantum afterimage',
  },
  {
    id: 12,
    name: 'Laser Beam Scanner',
    shortTag: 'Laser',
    description: 'High intensity cyan-white laser scan line traveling across the word',
  },
  {
    id: 13,
    name: '3D Perspective Flip',
    shortTag: '3D Flip',
    description: 'Letters tumble and unfold smoothly in 3D perspective space',
  },
  {
    id: 14,
    name: 'Fire & Magma Flare',
    shortTag: 'Fire',
    description: 'Incandescent magma orange-yellow heat wave with burning ember glow',
  },
  {
    id: 15,
    name: 'Aurora Borealis Wave',
    shortTag: 'Aurora',
    description: 'Ethereal northern lights wave blending emerald, teal, and violet rays',
  },
  {
    id: 16,
    name: 'Retro 8-Bit Arcade',
    shortTag: 'Retro',
    description: 'Classic 8-bit gaming progressive pixel block reveal',
  },
  {
    id: 17,
    name: 'Electric Lightning Arc',
    shortTag: 'Electric',
    description: 'Crackling blue-white electric zap burst illuminating each letter',
  },
  {
    id: 18,
    name: 'Vaporwave Hologram',
    shortTag: 'Vaporwave',
    description: 'Translucent iridescent vaporwave hologram breathing in soft cycles',
  },
];

export const TOUCH_PARTICLE_LIST = [
  { id: 'None', label: 'None (Normal)', short: 'None' },
  { id: 'Golden', label: 'Golden Sparkles', short: 'Golden' },
  { id: 'Neon', label: 'Neon Spheres', short: 'Neon' },
  { id: 'Fairy', label: 'Magic Fairy Dust', short: 'Fairy' },
  { id: 'Fire', label: 'Fire & Embers', short: 'Fire' },
  { id: 'Hearts', label: 'Romantic Hearts', short: 'Hearts' },
  { id: 'Bubbles', label: 'Rainbow Bubbles', short: 'Bubbles' },
  { id: 'Water', label: 'Water Splash', short: 'Water' },
  { id: 'Crystals', label: 'Sparkling Crystals', short: 'Crystals' },
  { id: 'MatrixRain', label: 'Cyber Matrix Rain', short: 'Matrix' },
  { id: 'Sakura', label: 'Sakura Petals', short: 'Sakura' },
  { id: 'Ice', label: 'Frozen Ice Shards', short: 'Ice' },
  { id: 'Starlight', label: 'Starlight Supernova', short: 'Starlight' },
  { id: 'Laser', label: 'Neon Laser Sparks', short: 'Laser' },
] as const;

export const AMBIENT_BG_LIST = [
  { id: 'None', label: 'None (Normal Background)', short: 'None' },
  { id: 'Starfield', label: 'Cyber Starfield', short: 'Starfield' },
  { id: 'Matrix', label: 'Matrix Digital Rain', short: 'Matrix' },
  { id: 'Quantum', label: 'Floating Quantum Orbs', short: 'Quantum' },
  { id: 'Embers', label: 'Cyberpunk Embers', short: 'Embers' },
  { id: 'Frosted', label: 'Frosted Snow Crystals', short: 'Frosted' },
] as const;

export const BUTTON_MICRO_LIST = [
  { id: 'Disabled', label: 'Disabled (Normal)', short: 'Off' },
  { id: 'Spring', label: 'Spring Elastic Bounce', short: 'Spring' },
  { id: 'Glow', label: 'Glow Pulse', short: 'Glow' },
  { id: 'Squeeze', label: 'Gentle Depth Squeeze', short: 'Squeeze' },
  { id: 'Pop', label: 'Pop & Overshoot', short: 'Pop' },
] as const;

export const STAGGER_ENTRANCE_LIST = [
  { id: 'Disabled', label: 'Disabled (Instant)', short: 'Instant' },
  { id: 'Cascade', label: 'Smooth Cascade Slide-Up', short: 'Cascade' },
  { id: 'Pop', label: 'Pop & Elastic Scale', short: 'Pop' },
  { id: 'Horizontal', label: 'Horizontal Drift', short: 'Horizontal' },
] as const;

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'cyber',
  activeTransitionId: 23, // Gargantua Singularity Vortex
  transitionShuffleMode: 'selected',
  activeConversionShaderId: 1, // Quantum Core Reactor
  conversionShuffleMode: 'fixed',
  masterSpeed: 'Normal',
  staggerStyle: 'Horizontal',
  touchParticle: 'Starlight',
  buttonMicro: 'Pop',
  ambientBg: 'Frosted',
  glowBorder: 'Matrix',
  typing: {
    enabled: true,
    loopContinuous: true,
    speedMs: 135,
    cursorStyle: 'Bar (|)',
    pauseSec: 1.8,
    styleId: 4, // Rainbow Spectrum Shimmer
  },
  xmlIndentation: '4 Spaces',
};

export function createBlankLayer(id: number, inset = 0): DrawableLayer {
  return {
    id,
    enabled: id === 1,
    startColor: 'None',
    centerColor: 'None',
    endColor: 'None',
    useCenterColor: false,
    gradientType: 'Linear',
    angle: 90,
    strokeColor: 'None',
    strokeWidth: 0,
    dashWidth: 0,
    dashGap: 0,
    cornerRadius: 12,
    useIndividualCorners: false,
    topLeftRadius: 12,
    topRightRadius: 12,
    bottomLeftRadius: 12,
    bottomRightRadius: 12,
    insetLeft: inset,
    insetTop: inset,
    insetRight: inset,
    insetBottom: inset,
  };
}

export function createInitialDrawableConfig(): StateDrawableConfig {
  return {
    normal: [
      createBlankLayer(1, 0),
      createBlankLayer(2, 3),
      createBlankLayer(3, 6),
      createBlankLayer(4, 9),
    ],
    checked: [
      createBlankLayer(1, 0),
      createBlankLayer(2, 3),
      createBlankLayer(3, 6),
      createBlankLayer(4, 9),
    ],
    pressed: [
      createBlankLayer(1, 0),
      createBlankLayer(2, 3),
      createBlankLayer(3, 6),
      createBlankLayer(4, 9),
    ],
    rippleColor: '#4000F5D4',
  };
}

export interface XmlPresetItem {
  id: string;
  name: string;
  category: '3D Layer' | 'Gradient' | 'Normal' | 'Ripple';
  description: string;
  targetScreen: 'xml_3d' | 'xml_gradient' | 'xml_normal' | 'xml_ripple';
  config: StateDrawableConfig;
}

export const XML_PRESETS: XmlPresetItem[] = [
  {
    id: 'preset_3d_cyber',
    name: 'Cyber Neon 3D Multi-Layer Card',
    category: '3D Layer',
    description: '4-layer glowing cyan & magenta 3D inset button with pressed state (from Video 04:40)',
    targetScreen: 'xml_3d',
    config: {
      normal: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#00FFFF',
          endColor: '#FF00AA',
          angle: 270,
          strokeColor: '#00FFFF',
          strokeWidth: 1,
          cornerRadius: 10,
        },
        {
          ...createBlankLayer(2, 3),
          enabled: true,
          startColor: '#051220',
          endColor: '#0A2540',
          angle: 270,
          cornerRadius: 8,
          insetLeft: 2,
          insetTop: 2,
          insetRight: 2,
          insetBottom: 4,
        },
        {
          ...createBlankLayer(3, 6),
          enabled: true,
          startColor: '#00F5D4',
          centerColor: '#0055FF',
          endColor: '#FF2A85',
          useCenterColor: true,
          angle: 270,
          cornerRadius: 7,
          insetLeft: 5,
          insetTop: 5,
          insetRight: 5,
          insetBottom: 8,
        },
        createBlankLayer(4, 9),
      ],
      checked: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#00FF88',
          endColor: '#00BBF9',
          angle: 180,
          strokeColor: '#00FF88',
          strokeWidth: 2,
          cornerRadius: 10,
        },
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      pressed: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#FF2A85',
          endColor: '#7209B7',
          angle: 90,
          strokeColor: '#FFFFFF',
          strokeWidth: 1,
          cornerRadius: 10,
        },
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      rippleColor: '#6600F5D4',
    },
  },
  {
    id: 'preset_grad_synth',
    name: 'Neon Magenta-Cyan 3-Stop Gradient',
    category: 'Gradient',
    description: 'Vibrant 270° 3-color linear gradient (#FF007F → #0055FF → #00FFFF) shown in Video 02:42',
    targetScreen: 'xml_gradient',
    config: {
      normal: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#FF007F',
          centerColor: '#0055FF',
          endColor: '#00FFFF',
          useCenterColor: true,
          gradientType: 'Linear',
          angle: 270,
          strokeColor: '#00F5D4',
          strokeWidth: 1,
          cornerRadius: 14,
        },
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      checked: [
        createBlankLayer(1, 0),
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      pressed: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#00FFFF',
          centerColor: '#0055FF',
          endColor: '#FF007F',
          useCenterColor: true,
          gradientType: 'Linear',
          angle: 90,
          cornerRadius: 14,
        },
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      rippleColor: '#4000FFFF',
    },
  },
  {
    id: 'preset_matrix_hud',
    name: 'Matrix Hacker HUD Frame',
    category: 'Normal',
    description: 'Obsidian terminal background with crisp emerald neon stroke and asymmetric corners',
    targetScreen: 'xml_normal',
    config: {
      normal: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#071712',
          endColor: '#071712',
          strokeColor: '#00FF88',
          strokeWidth: 2,
          useIndividualCorners: true,
          topLeftRadius: 16,
          topRightRadius: 4,
          bottomLeftRadius: 4,
          bottomRightRadius: 16,
        },
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      checked: [
        createBlankLayer(1, 0),
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      pressed: [
        createBlankLayer(1, 0),
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      rippleColor: '#4000FF88',
    },
  },
  {
    id: 'preset_ripple_pro',
    name: 'Electric Cyan Ripple Button',
    category: 'Ripple',
    description: 'Interactive Android <ripple> drawable with custom mask and glowing border',
    targetScreen: 'xml_ripple',
    config: {
      normal: [
        {
          ...createBlankLayer(1, 0),
          enabled: true,
          startColor: '#0C2229',
          endColor: '#071418',
          strokeColor: '#00F5D4',
          strokeWidth: 2,
          cornerRadius: 12,
        },
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      checked: [
        createBlankLayer(1, 0),
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      pressed: [
        createBlankLayer(1, 0),
        createBlankLayer(2, 3),
        createBlankLayer(3, 6),
        createBlankLayer(4, 9),
      ],
      rippleColor: '#6600F5D4',
    },
  },
];
