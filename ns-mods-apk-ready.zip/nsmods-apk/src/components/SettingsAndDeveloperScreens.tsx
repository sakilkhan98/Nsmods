import React, { useState } from 'react';
import {
  AMBIENT_BG_LIST,
  BUTTON_MICRO_LIST,
  CONVERSION_SHADERS,
  DEFAULT_SETTINGS,
  SCREEN_TRANSITIONS,
  STAGGER_ENTRANCE_LIST,
  TOUCH_PARTICLE_LIST,
  TYPING_STYLES,
} from '../data/fxCatalog';
import {
  AmbientBgStyle,
  AppSettings,
  ButtonMicroStyle,
  ConversionShaderItem,
  GlowBorderStyle,
  ScreenId,
  StaggerStyle,
  TouchParticleStyle,
  TransitionItem,
} from '../types/appTypes';
import { AnimatedText } from './AnimatedText';
import { ConversionShaderView } from './ConversionShaderView';

interface SettingsProps {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  customTransitions: TransitionItem[];
  setCustomTransitions: React.Dispatch<React.SetStateAction<TransitionItem[]>>;
  customShaders: ConversionShaderItem[];
  setCustomShaders: React.Dispatch<React.SetStateAction<ConversionShaderItem[]>>;
  microClass: string;
  glowClass: string;
  staggerClass: string;
  onNavigate: (screen: ScreenId) => void;
  onTriggerScreenTransition: (transitionId: number) => void;
  onShowToast: (title: string, subtitle: string) => void;
}

export const SettingsScreen: React.FC<SettingsProps> = ({
  settings,
  setSettings,
  customTransitions,
  customShaders,
  microClass,
  glowClass,
  staggerClass,
  onNavigate,
  onShowToast,
}) => {
  const [activeModal, setActiveModal] = useState<
    | null
    | 'typing'
    | 'touch_particle'
    | 'ambient_bg'
    | 'button_micro'
    | 'stagger'
    | 'glow_border'
  >(null);

  const [previewReplay, setPreviewReplay] = useState(0);

  const allTransitions = [...SCREEN_TRANSITIONS, ...customTransitions];
  const currentTransition =
    allTransitions.find((t) => t.id === settings.activeTransitionId) ||
    SCREEN_TRANSITIONS[22];

  const allShaders = [...CONVERSION_SHADERS, ...customShaders];
  const currentShader =
    allShaders.find((s) => s.id === settings.activeConversionShaderId) ||
    CONVERSION_SHADERS[0];

  const currentTypingStyle =
    TYPING_STYLES.find((s) => s.id === settings.typing.styleId) ||
    TYPING_STYLES[3];

  const currentParticleObj =
    TOUCH_PARTICLE_LIST.find((p) => p.id === settings.touchParticle) ||
    TOUCH_PARTICLE_LIST[2];

  const currentAmbientObj =
    AMBIENT_BG_LIST.find((a) => a.id === settings.ambientBg) ||
    AMBIENT_BG_LIST[5];

  const cycleMasterSpeed = () => {
    const order: AppSettings['masterSpeed'][] = [
      'Normal',
      'Fast',
      'Turbo',
      'Slow',
    ];
    const next =
      order[(order.indexOf(settings.masterSpeed) + 1) % order.length];
    setSettings((prev) => ({ ...prev, masterSpeed: next }));
    onShowToast(
      'Animation Speed Updated',
      `Conversion & UI speed set to ${next}`
    );
  };

  const cycleIndentation = () => {
    const order: AppSettings['xmlIndentation'][] = [
      '4 Spaces',
      '2 Spaces',
      'Tabs',
    ];
    const next =
      order[(order.indexOf(settings.xmlIndentation) + 1) % order.length];
    setSettings((prev) => ({ ...prev, xmlIndentation: next }));
    onShowToast('Indentation Updated', `Code formatting set to ${next}`);
  };

  const cycleTheme = () => {
    const order: AppSettings['theme'][] = ['cyber', 'amoled', 'light'];
    const next = order[(order.indexOf(settings.theme) + 1) % order.length];
    setSettings((prev) => ({ ...prev, theme: next }));
    const labels = {
      cyber: 'Cyber Dark (Default)',
      amoled: 'AMOLED Pitch Dark',
      light: 'Clean Light Mode',
    };
    onShowToast('Theme Updated', labels[next]);
  };

  return (
    <div className="flex flex-col pb-6">
      {/* Top Bar matching Video 00:06 */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white flex items-center gap-1.5 ${microClass}`}
        >
          <span>←</span>
          <AnimatedText text="Back" config={settings.typing} />
        </button>

        <h1 className="text-base font-extrabold text-white">
          <AnimatedText text="Settings" config={settings.typing} />
        </h1>

        <div className="w-16" />
      </div>

      {/* SECTION 1: SCREEN & MOTION TRANSITIONS */}
      <div className="text-[11px] font-bold tracking-wider uppercase text-slate-400 mb-2 px-1 flex items-center gap-1.5">
        <span>🎬</span>
        <AnimatedText
          text="SCREEN & MOTION TRANSITIONS"
          config={settings.typing}
        />
      </div>

      <div className="space-y-2.5 mb-5">
        {/* 1. Screen Transitions */}
        <button
          type="button"
          onClick={() => onNavigate('transitions')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">✨</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Screen Transitions"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-2.5 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white max-w-[140px] truncate shrink-0">
            {currentTransition.name}
          </span>
        </button>

        {/* 2. Conversion Visual Shaders */}
        <button
          type="button"
          onClick={() => onNavigate('conversion_shaders')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] font-mono text-xs font-bold">
              &lt;&gt;
            </span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Conversion Visual S..."
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-2.5 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white max-w-[140px] truncate shrink-0">
            {currentShader.name}
          </span>
        </button>

        {/* 3. Master Animation Speed */}
        <button
          type="button"
          onClick={cycleMasterSpeed}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">↻</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Master Animation Speed"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {settings.masterSpeed}
          </span>
        </button>

        {/* 4. Card Staggered Entrance */}
        <button
          type="button"
          onClick={() => setActiveModal('stagger')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">✨</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Card Staggered Entrance"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {settings.staggerStyle} &gt;
          </span>
        </button>
      </div>

      {/* SECTION 2: LIVE INTERACTIVE & VISUAL FX */}
      <div className="text-[11px] font-bold tracking-wider uppercase text-slate-400 mb-2 px-1 flex items-center gap-1.5">
        <span>✨</span>
        <AnimatedText
          text="LIVE INTERACTIVE & VISUAL FX"
          config={settings.typing}
        />
      </div>

      <div className="space-y-2.5 mb-5">
        {/* 5. Touch Tap Particle Bursts */}
        <button
          type="button"
          onClick={() => setActiveModal('touch_particle')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">✨</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Touch Tap Particle Bursts"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {currentParticleObj.short} &gt;
          </span>
        </button>

        {/* 6. Button Click Micro-Interactions */}
        <button
          type="button"
          onClick={() => setActiveModal('button_micro')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">↻</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Button Click Micro-Interactions"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {settings.buttonMicro} &gt;
          </span>
        </button>

        {/* 7. Ambient Live Background FX */}
        <button
          type="button"
          onClick={() => setActiveModal('ambient_bg')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">✨</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Ambient Live Background FX"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {currentAmbientObj.short} &gt;
          </span>
        </button>

        {/* 8. Pulsing Neon Glow Border */}
        <button
          type="button"
          onClick={() => setActiveModal('glow_border')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] text-sm">👤</span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Pulsing Neon Glow Border"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {settings.glowBorder} &gt;
          </span>
        </button>

        {/* 9. Typing & Text Animations */}
        <button
          type="button"
          onClick={() => setActiveModal('typing')}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass} ${staggerClass}`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-[#00f5d4] font-mono text-xs font-bold">
              &lt;&gt;
            </span>
            <span className="text-xs font-bold text-white truncate">
              <AnimatedText
                text="Typing & Text Animations"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white shrink-0">
            {settings.typing.enabled
              ? `ON (${currentTypingStyle.shortTag}) >`
              : 'OFF >'}
          </span>
        </button>

        {/* 10. Tap Here to Test Touch & Click FX */}
        <button
          type="button"
          onClick={() =>
            onShowToast(
              'Interactive FX Active!',
              `Particles: ${currentParticleObj.label} • Button: ${settings.buttonMicro}`
            )
          }
          className={`w-full rounded-2xl border-2 border-[#ffd166]/80 bg-[#0c1a1c] p-3.5 flex items-center justify-center gap-2 text-xs font-bold text-white shadow-[0_0_16px_rgba(255,209,102,0.18)] ${microClass} ${staggerClass}`}
        >
          <span className="text-[#ffd166]">✨</span>
          <AnimatedText
            text="Tap Here to Test Touch & Click FX"
            config={settings.typing}
          />
        </button>
      </div>

      {/* SECTION 3: CODE & WORKSPACE CONFIG */}
      <div className="text-[11px] font-bold tracking-wider uppercase text-slate-400 mb-2 px-1 flex items-center gap-1.5">
        <span className="font-mono">&lt;&gt;</span>
        <AnimatedText
          text="CODE & WORKSPACE CONFIG"
          config={settings.typing}
        />
      </div>

      <div className="space-y-2.5 mb-5">
        <button
          type="button"
          onClick={cycleIndentation}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass}`}
        >
          <div className="flex items-center gap-2.5">
            <span className="text-[#00f5d4] text-sm">❐</span>
            <span className="text-xs font-bold text-white">
              <AnimatedText
                text="Code & XML Indentation"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white">
            {settings.xmlIndentation}
          </span>
        </button>

        <button
          type="button"
          onClick={cycleTheme}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass}`}
        >
          <div className="flex items-center gap-2.5">
            <span className="text-[#00f5d4] text-sm">🌓</span>
            <span className="text-xs font-bold text-white">
              <AnimatedText
                text="Dark & Theme Mode"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white uppercase">
            {settings.theme} &gt;
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            setSettings(DEFAULT_SETTINGS);
            onShowToast(
              'Settings Reset',
              'All settings restored to factory default.'
            );
          }}
          className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass}`}
        >
          <div className="flex items-center gap-2.5">
            <span className="text-[#00f5d4] text-sm">↻</span>
            <span className="text-xs font-bold text-white">
              <AnimatedText
                text="Reset All Settings to Default"
                config={settings.typing}
              />
            </span>
          </div>
          <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white">
            Reset
          </span>
        </button>
      </div>

      {/* SECTION 4: DEVELOPER & CREDITS */}
      <div className="text-[11px] font-bold tracking-wider uppercase text-slate-400 mb-2 px-1 flex items-center gap-1.5">
        <span>👤</span>
        <AnimatedText text="DEVELOPER & CREDITS" config={settings.typing} />
      </div>

      <button
        type="button"
        onClick={() => onNavigate('about_developer')}
        className={`w-full rounded-2xl border-2 bg-[#091519] p-3.5 flex items-center justify-between gap-2 text-left ${glowClass} ${microClass}`}
      >
        <div className="flex items-center gap-2.5">
          <span className="text-[#00f5d4] text-sm">👤</span>
          <span className="text-xs font-bold text-white">
            <AnimatedText text="About Developer" config={settings.typing} />
          </span>
        </div>
        <span className="px-3 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-semibold text-white">
          Open &gt;
        </span>
      </button>

      {/* ====================================================================
         MODALS FOR SETTINGS
      ==================================================================== */}

      {/* 1. TYPING & TEXT VISUAL STUDIO MODAL (Video 00:15 - 00:36, 00:46, 01:02) */}
      {activeModal === 'typing' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl border-2 border-[#00f5d4] bg-[#081316] p-4 shadow-[0_0_32px_rgba(0,245,212,0.3)] max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-white mb-3">
              <span className="text-[#00f5d4] font-mono">&lt;&gt;</span>
              <span>Typing &amp; Text Visual Studio</span>
            </div>

            {/* Top Toggles: Animation ON/OFF | Loop: Single Run / Continuous */}
            <div className="grid grid-cols-2 gap-2.5 mb-3">
              <button
                type="button"
                onClick={() =>
                  setSettings((prev) => ({
                    ...prev,
                    typing: {
                      ...prev.typing,
                      enabled: !prev.typing.enabled,
                    },
                  }))
                }
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${
                  settings.typing.enabled
                    ? 'border-[#00ff88] bg-[#0b2e26] text-white'
                    : 'border-[#00f5d4]/50 bg-[#0c1a1f] text-slate-300'
                }`}
              >
                <span className="text-[#ffd166]">⚡</span>
                <span>
                  Animation: {settings.typing.enabled ? 'ON' : 'OFF'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const nextLoop = !settings.typing.loopContinuous;
                  setSettings((prev) => ({
                    ...prev,
                    typing: {
                      ...prev.typing,
                      loopContinuous: nextLoop,
                    },
                  }));
                  onShowToast(
                    'Loop Mode Updated',
                    nextLoop
                      ? 'Continuous Infinite Loop (ON)'
                      : 'Single Run Mode (ON)'
                  );
                }}
                className="py-2.5 px-3 rounded-xl border border-[#00f5d4]/60 bg-[#0c1a1f] text-xs font-bold text-white flex items-center justify-center gap-1.5"
              >
                <span className="text-[#00bbf9]">🔁</span>
                <span>
                  Loop:{' '}
                  {settings.typing.loopContinuous ? 'Continuous' : 'Single Run'}
                </span>
              </button>
            </div>

            {/* LIVE PREVIEW BOX */}
            <div className="rounded-xl border border-[#00f5d4]/50 bg-[#050d10] p-3 mb-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                  LIVE PREVIEW (
                  {settings.typing.loopContinuous ? 'CONTINUOUS' : 'SINGLE RUN'}
                  )
                </span>
                <button
                  type="button"
                  onClick={() => setPreviewReplay((r) => r + 1)}
                  className="px-2.5 py-1 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[10px] font-bold text-white"
                >
                  ▶ Replay Now
                </button>
              </div>
              <div className="min-h-[44px] rounded-lg border border-[#00f5d4]/30 bg-[#081519] px-3 py-2 flex items-center justify-center text-center text-xs font-bold text-white">
                <AnimatedText
                  text="Ns mods XML Creator • Ultra Pro Modding Suite"
                  config={settings.typing}
                  forceEnable
                  replayTrigger={previewReplay}
                />
              </div>
            </div>

            {/* SPEED & CURSOR CONTROLS */}
            <div className="grid grid-cols-3 gap-2 mb-2.5">
              <div className="col-span-1 rounded-xl border border-[#00f5d4]/40 bg-[#0c1a1f] px-2.5 py-2 flex items-center justify-center text-[11px] font-mono font-bold text-[#00ff88]">
                SPEED: {settings.typing.speedMs} ms
              </div>
              <button
                type="button"
                onClick={() =>
                  setSettings((prev) => ({
                    ...prev,
                    typing: {
                      ...prev.typing,
                      speedMs: Math.max(35, prev.typing.speedMs - 20),
                    },
                  }))
                }
                className="rounded-xl border border-[#00f5d4]/60 bg-[#0d2228] text-base font-bold text-white py-1.5"
              >
                −
              </button>
              <button
                type="button"
                onClick={() =>
                  setSettings((prev) => ({
                    ...prev,
                    typing: {
                      ...prev.typing,
                      speedMs: Math.min(260, prev.typing.speedMs + 20),
                    },
                  }))
                }
                className="rounded-xl border border-[#00f5d4]/60 bg-[#0d2228] text-base font-bold text-white py-1.5"
              >
                +
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 mb-3">
              <button
                type="button"
                onClick={() => {
                  const cursors: AppSettings['typing']['cursorStyle'][] = [
                    'Bar (|)',
                    'Block (█)',
                    'Underscore (_)',
                    'None',
                  ];
                  const next =
                    cursors[
                      (cursors.indexOf(settings.typing.cursorStyle) + 1) %
                        cursors.length
                    ];
                  setSettings((prev) => ({
                    ...prev,
                    typing: { ...prev.typing, cursorStyle: next },
                  }));
                }}
                className="py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-xs font-bold text-white"
              >
                Cursor: {settings.typing.cursorStyle}
              </button>

              <button
                type="button"
                onClick={() =>
                  setSettings((prev) => ({
                    ...prev,
                    typing: {
                      ...prev.typing,
                      pauseSec:
                        prev.typing.pauseSec >= 3.0
                          ? 1.0
                          : Number((prev.typing.pauseSec + 0.4).toFixed(1)),
                    },
                  }))
                }
                className="py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-xs font-bold text-white"
              >
                Pause: {settings.typing.pauseSec}s
              </button>
            </div>

            <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-2">
              CHOOSE ANIMATION STYLE (18 PRO STYLES)
            </div>

            {/* 18 Pro Styles Scrollable List */}
            <div className="space-y-2 overflow-y-auto pr-1 flex-1 max-h-56">
              {TYPING_STYLES.map((st) => {
                const isSelected = settings.typing.styleId === st.id;
                return (
                  <div
                    key={st.id}
                    onClick={() => {
                      setSettings((prev) => ({
                        ...prev,
                        typing: {
                          ...prev.typing,
                          enabled: true,
                          styleId: st.id,
                        },
                      }));
                      onShowToast(
                        'Typing Style Selected',
                        `${st.id}. ${st.name}`
                      );
                    }}
                    className={`rounded-xl border p-2.5 cursor-pointer transition-all flex items-center justify-between gap-2 ${
                      isSelected
                        ? 'border-[#00ff88] bg-[#0b2922]'
                        : 'border-[#00f5d4]/40 bg-[#0c1a1f]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white">
                        {st.id}. {st.name}
                      </div>
                      <div className="text-[11px] text-slate-400 leading-snug mt-0.5">
                        {st.description}
                      </div>
                    </div>
                    <button
                      type="button"
                      className={`px-2.5 py-1.5 rounded-lg border text-[10px] font-bold shrink-0 ${
                        isSelected
                          ? 'border-[#00ff88] bg-[#0f3d32] text-[#00ff88]'
                          : 'border-[#00f5d4]/60 bg-[#0d2228] text-white'
                      }`}
                    >
                      {isSelected ? '✓ ACTIVE' : 'SELECT'}
                    </button>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal(null)}
              className="mt-3 w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d242b] text-xs font-extrabold text-white"
            >
              Close &amp; Apply Everywhere
            </button>
          </div>
        </div>
      )}

      {/* 2. TOUCH PARTICLE ANIMATIONS MODAL (Video 01:13 & 01:21) */}
      {activeModal === 'touch_particle' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#081316] p-4 max-h-[82vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-white mb-3">
              <span className="text-[#00f5d4]">✨</span>
              <span>Touch Particle Animations</span>
            </div>

            <div className="space-y-2 overflow-y-auto pr-1 flex-1">
              {TOUCH_PARTICLE_LIST.map((item) => {
                const active = settings.touchParticle === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setSettings((prev) => ({
                        ...prev,
                        touchParticle: item.id as TouchParticleStyle,
                      }));
                      onShowToast('Touch Particle Active', item.label);
                      setActiveModal(null);
                    }}
                    className={`rounded-xl border p-3 flex items-center justify-between cursor-pointer ${
                      active
                        ? 'border-[#00ff88] bg-[#0b2922]'
                        : 'border-[#00f5d4]/50 bg-[#0c1a1f]'
                    }`}
                  >
                    <span className="text-xs font-bold text-white">
                      {item.label}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-lg border text-[11px] font-bold ${
                        active
                          ? 'border-[#00ff88] bg-[#0f3d32] text-[#00ff88]'
                          : 'border-[#00f5d4]/60 bg-[#0d2228] text-white'
                      }`}
                    >
                      {active ? '✓ ACTIVE' : 'APPLY'}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal(null)}
              className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 3. AMBIENT BACKGROUND EFFECTS MODAL (Video 01:46) */}
      {activeModal === 'ambient_bg' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#081316] p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-white mb-3">
              <span className="text-[#00f5d4]">✨</span>
              <span>Ambient Background Effects</span>
            </div>

            <div className="space-y-2">
              {AMBIENT_BG_LIST.map((item) => {
                const active = settings.ambientBg === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setSettings((prev) => ({
                        ...prev,
                        ambientBg: item.id as AmbientBgStyle,
                      }));
                      onShowToast('Ambient Background Set', item.label);
                      setActiveModal(null);
                    }}
                    className={`rounded-xl border p-3 flex items-center justify-between cursor-pointer ${
                      active
                        ? 'border-[#00ff88] bg-[#0b2922]'
                        : 'border-[#00f5d4]/50 bg-[#0c1a1f]'
                    }`}
                  >
                    <span className="text-xs font-bold text-white">
                      {item.label}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-lg border text-[11px] font-bold ${
                        active
                          ? 'border-[#00ff88] bg-[#0f3d32] text-[#00ff88]'
                          : 'border-[#00f5d4]/60 bg-[#0d2228] text-white'
                      }`}
                    >
                      {active ? '✓ ACTIVE' : 'APPLY'}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal(null)}
              className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 4. BUTTON MICRO-INTERACTIONS MODAL (Video 01:58) */}
      {activeModal === 'button_micro' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#081316] p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-white mb-3">
              <span className="text-[#00f5d4]">✨</span>
              <span>Button Micro-Interactions</span>
            </div>

            <div className="space-y-2">
              {BUTTON_MICRO_LIST.map((item) => {
                const active = settings.buttonMicro === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setSettings((prev) => ({
                        ...prev,
                        buttonMicro: item.id as ButtonMicroStyle,
                      }));
                      onShowToast('Button Interaction Applied', item.label);
                      setActiveModal(null);
                    }}
                    className={`rounded-xl border p-3 flex items-center justify-between cursor-pointer ${
                      active
                        ? 'border-[#00ff88] bg-[#0b2922]'
                        : 'border-[#00f5d4]/50 bg-[#0c1a1f]'
                    }`}
                  >
                    <span className="text-xs font-bold text-white">
                      {item.label}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-lg border text-[11px] font-bold ${
                        active
                          ? 'border-[#00ff88] bg-[#0f3d32] text-[#00ff88]'
                          : 'border-[#00f5d4]/60 bg-[#0d2228] text-white'
                      }`}
                    >
                      {active ? '✓ ACTIVE' : 'SELECT'}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal(null)}
              className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 5. CARD STAGGERED ENTRANCE MODAL (Video 01:24, 02:09) */}
      {activeModal === 'stagger' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#081316] p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-white mb-3">
              <span className="text-[#00f5d4]">✨</span>
              <span>Card Staggered Entrance</span>
            </div>

            <div className="space-y-2">
              {STAGGER_ENTRANCE_LIST.map((item) => {
                const active = settings.staggerStyle === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setSettings((prev) => ({
                        ...prev,
                        staggerStyle: item.id as StaggerStyle,
                      }));
                      onShowToast('Entrance Animation Set', item.label);
                      setActiveModal(null);
                    }}
                    className={`rounded-xl border p-3 flex items-center justify-between cursor-pointer ${
                      active
                        ? 'border-[#00ff88] bg-[#0b2922]'
                        : 'border-[#00f5d4]/50 bg-[#0c1a1f]'
                    }`}
                  >
                    <span className="text-xs font-bold text-white">
                      {item.label}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-lg border text-[11px] font-bold ${
                        active
                          ? 'border-[#00ff88] bg-[#0f3d32] text-[#00ff88]'
                          : 'border-[#00f5d4]/60 bg-[#0d2228] text-white'
                      }`}
                    >
                      {active ? '✓ ACTIVE' : 'SELECT'}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal(null)}
              className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 6. PULSING NEON GLOW BORDER MODAL */}
      {activeModal === 'glow_border' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#081316] p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-white mb-3">
              <span className="text-[#00f5d4]">👤</span>
              <span>Pulsing Neon Glow Border</span>
            </div>

            <div className="space-y-2">
              {(
                [
                  { id: 'Matrix', label: 'Matrix Emerald-Cyan Pulse' },
                  { id: 'Cyber', label: 'Cyber Cyan-Magenta Dual Pulse' },
                  { id: 'Solar', label: 'Solar Gold-Amber Pulse' },
                  { id: 'Rainbow', label: 'RGB Chroma Spectrum Loop' },
                  { id: 'Off', label: 'Static Clean Border (No Pulse)' },
                ] as const
              ).map((item) => {
                const active = settings.glowBorder === item.id;
                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setSettings((prev) => ({
                        ...prev,
                        glowBorder: item.id as GlowBorderStyle,
                      }));
                      onShowToast('Border Glow Updated', item.label);
                      setActiveModal(null);
                    }}
                    className={`rounded-xl border p-3 flex items-center justify-between cursor-pointer ${
                      active
                        ? 'border-[#00ff88] bg-[#0b2922]'
                        : 'border-[#00f5d4]/50 bg-[#0c1a1f]'
                    }`}
                  >
                    <span className="text-xs font-bold text-white">
                      {item.label}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-lg border text-[11px] font-bold ${
                        active
                          ? 'border-[#00ff88] bg-[#0f3d32] text-[#00ff88]'
                          : 'border-[#00f5d4]/60 bg-[#0d2228] text-white'
                      }`}
                    >
                      {active ? '✓ ACTIVE' : 'SELECT'}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal(null)}
              className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   TRANSITION ANIMATIONS SCREEN (Video 00:07 - 00:10)
============================================================================ */

export const TransitionAnimationsScreen: React.FC<SettingsProps> = ({
  settings,
  setSettings,
  customTransitions,
  setCustomTransitions,
  microClass,
  glowClass,
  onNavigate,
  onTriggerScreenTransition,
  onShowToast,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'HACKING' | 'CINEMATIC' | 'CLASSIC'>('ALL');
  const [customName, setCustomName] = useState('');
  const [enterStyle, setEnterStyle] = useState('Cyber Glitch Breach');
  const [backStyle, setBackStyle] = useState('Hologram Laser');

  const allTransitions = [...SCREEN_TRANSITIONS, ...customTransitions];
  const currentTransition =
    allTransitions.find((t) => t.id === settings.activeTransitionId) ||
    SCREEN_TRANSITIONS[22];

  const filtered = allTransitions.filter((t) =>
    filter === 'ALL' ? true : t.category === filter
  );

  const handleAddCustomTransition = () => {
    const name =
      customName.trim() || `${enterStyle.split(' ')[0]} + ${backStyle.split(' ')[0]}`;
    const newId = allTransitions.length + 1;
    const item: TransitionItem = {
      id: newId,
      name,
      category: 'HACKING',
      isCustom: true,
    };
    setCustomTransitions((prev) => [...prev, item]);
    setSettings((prev) => ({ ...prev, activeTransitionId: newId }));
    setCustomName('');
    onTriggerScreenTransition(newId);
    onShowToast(
      'Transition Activated!',
      `${newId}. ${name} is now active across the entire app.`
    );
  };

  return (
    <div className="flex flex-col pb-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          Transition Animations
        </h1>
        <div className="w-14" />
      </div>

      {/* Active Transition Status Card (Video 00:10) */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-2.5">
          Active: {currentTransition.id}. {currentTransition.name}
        </div>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                transitionShuffleMode: 'selected',
              }))
            }
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              settings.transitionShuffleMode === 'selected'
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
            }`}
          >
            ✓ Selected
          </button>
          <button
            type="button"
            onClick={() => {
              setSettings((prev) => ({
                ...prev,
                transitionShuffleMode: 'shuffle_all',
              }));
              onShowToast('Shuffle All Active', 'Random transition on every screen change.');
            }}
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              settings.transitionShuffleMode === 'shuffle_all'
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
            }`}
          >
            🔀 Shuffle All
          </button>
          <button
            type="button"
            onClick={() => {
              setSettings((prev) => ({
                ...prev,
                transitionShuffleMode: 'shuffle_cyber',
              }));
              onShowToast('Cyber Shuffle Active', 'Shuffling Hacking & Cyber transitions.');
            }}
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              settings.transitionShuffleMode === 'shuffle_cyber'
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
            }`}
          >
            🔥 Cyber Shuf...
          </button>
        </div>
      </div>

      {/* Custom Screen Transition Builder (Video 00:10) */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-2.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white flex items-center gap-1.5">
          <span>🎬</span>
          <span>Custom Screen Transition Builder</span>
        </div>

        <input
          type="text"
          value={customName}
          onChange={(e) => setCustomName(e.target.value)}
          placeholder="Custom Transition Name"
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs text-white"
        />

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() =>
              setEnterStyle((s) =>
                s === 'Cyber Glitch Breach'
                  ? 'Gargantua Vortex'
                  : 'Cyber Glitch Breach'
              )
            }
            className="py-2 px-2 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-[11px] font-bold text-white truncate"
          >
            Enter: {enterStyle}
          </button>
          <button
            type="button"
            onClick={() =>
              setBackStyle((s) =>
                s === 'Hologram Laser' ? 'Matrix Rain' : 'Hologram Laser'
              )
            }
            className="py-2 px-2 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-[11px] font-bold text-white truncate"
          >
            Back: {backStyle}
          </button>
        </div>

        <button
          type="button"
          onClick={handleAddCustomTransition}
          className={`w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d262e] text-xs font-bold text-white ${microClass}`}
        >
          + Add &amp; Apply Custom Transition
        </button>
      </div>

      {/* Category Filter Tabs */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        {(
          [
            { id: 'ALL', label: '✓ All' },
            { id: 'HACKING', label: '💻 Hacking' },
            { id: 'CINEMATIC', label: '🎬 Cinema' },
            { id: 'CLASSIC', label: '⚡ Classic' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id)}
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              filter === tab.id
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0a161a] text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 25 Transition Items List (Video 00:07 - 00:09) */}
      <div className="space-y-2.5">
        {filtered.map((item) => {
          const isSelected = settings.activeTransitionId === item.id;
          return (
            <div
              key={item.id}
              onClick={() => {
                setSettings((prev) => ({
                  ...prev,
                  activeTransitionId: item.id,
                  transitionShuffleMode: 'selected',
                }));
                onTriggerScreenTransition(item.id);
                onShowToast(
                  'Transition Activated!',
                  `${item.id}. ${item.name} is now active across the entire app.`
                );
              }}
              className={`rounded-2xl border-2 p-3.5 flex items-center justify-between gap-2 cursor-pointer transition-all ${microClass} ${
                isSelected
                  ? 'border-[#ffd166] bg-gradient-to-r from-[#590d22] via-[#800f2f] to-[#a4133c] shadow-[0_0_20px_rgba(255,42,133,0.4)]'
                  : 'border-[#00f5d4]/60 bg-[#091519]'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    isSelected ? 'border-white' : 'border-slate-400'
                  }`}
                >
                  {isSelected && (
                    <div className="w-2.5 h-2.5 rounded-full bg-[#00f5d4]" />
                  )}
                </div>
                <span className="text-xs font-bold text-white truncate">
                  {item.id}. {item.name}
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] font-mono text-[#00f5d4] uppercase">
                  {item.category}
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSettings((prev) => ({
                      ...prev,
                      activeTransitionId: item.id,
                    }));
                    onTriggerScreenTransition(item.id);
                    onShowToast(
                      'Testing Transition',
                      `${item.id}. ${item.name}`
                    );
                  }}
                  className="px-3 py-1.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d2228] text-xs font-bold text-white"
                >
                  ▶ Test
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ============================================================================
   CONVERSION ANIMATIONS SCREEN (Video 01:42 - 01:44)
============================================================================ */

export const ConversionAnimationsScreen: React.FC<SettingsProps> = ({
  settings,
  setSettings,
  customShaders,
  setCustomShaders,
  microClass,
  glowClass,
  onNavigate,
  onShowToast,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'HACKING' | 'CINEMATIC' | 'CUSTOM'>('ALL');
  const [liveProgress, setLiveProgress] = useState(100);
  const [swappedStream, setSwappedStream] = useState(false);
  const [customName, setCustomName] = useState('');

  const allShaders = [...CONVERSION_SHADERS, ...customShaders];

  const triggerReplay = (shaderId: number) => {
    setSettings((prev) => ({ ...prev, activeConversionShaderId: shaderId }));
    setLiveProgress(12);
    let p = 12;
    const id = window.setInterval(() => {
      p += 16;
      if (p >= 100) {
        p = 100;
        setLiveProgress(100);
        clearInterval(id);
      } else {
        setLiveProgress(p);
      }
    }, 110);
  };

  const filtered = allShaders.filter((s) =>
    filter === 'ALL' ? true : s.category === filter
  );

  return (
    <div className="flex flex-col pb-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          Conversion Animations
        </h1>
        <div className="w-14" />
      </div>

      {/* Live Shader Preview Card (Video 01:42 & 01:44) */}
      <div className="mb-3">
        <ConversionShaderView
          shaderId={settings.activeConversionShaderId}
          sourceLabel={swappedStream ? 'KOTLIN' : 'INPUT'}
          targetLabel={swappedStream ? 'JAVA' : 'OUTPUT'}
          progress={liveProgress}
        />
      </div>

      {/* Stream & Shuffle Controls */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3 mb-3.5 space-y-2 ${glowClass}`}>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => triggerReplay(settings.activeConversionShaderId)}
            className="py-2 rounded-xl border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-bold text-white"
          >
            ▶ Replay O...
          </button>
          <button
            type="button"
            onClick={() => setSwappedStream((s) => !s)}
            className="py-2 rounded-xl border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-bold text-white"
          >
            ⇄ Swap Stream
          </button>
          <button
            type="button"
            onClick={() =>
              onShowToast('Shader Speed', `Master Speed: ${settings.masterSpeed}`)
            }
            className="py-2 rounded-xl border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-bold text-white"
          >
            ⚡ Speed: {settings.masterSpeed}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                conversionShuffleMode: 'fixed',
              }))
            }
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              settings.conversionShuffleMode === 'fixed'
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0c1a1f] text-white'
            }`}
          >
            ✓ Fixed Style
          </button>
          <button
            type="button"
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                conversionShuffleMode: 'shuffle_all',
              }))
            }
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              settings.conversionShuffleMode === 'shuffle_all'
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0c1a1f] text-white'
            }`}
          >
            🔀 Shuffle All
          </button>
          <button
            type="button"
            onClick={() =>
              setSettings((prev) => ({
                ...prev,
                conversionShuffleMode: 'shuffle_hack',
              }))
            }
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              settings.conversionShuffleMode === 'shuffle_hack'
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0c1a1f] text-white'
            }`}
          >
            💻 Shuffle Hack
          </button>
        </div>
      </div>

      {/* Custom Conversion Animation Builder (Video 01:43) */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-2.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white flex items-center gap-1.5">
          <span>🎨</span>
          <span>Custom Conversion Animation Builder</span>
        </div>
        <input
          type="text"
          value={customName}
          onChange={(e) => setCustomName(e.target.value)}
          placeholder="Custom Animation Name"
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs text-white"
        />
        <div className="grid grid-cols-2 gap-2">
          <div className="py-2 px-2.5 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-[11px] font-bold text-white truncate">
            Engine: Matrix Breac...
          </div>
          <div className="py-2 px-2.5 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-[11px] font-bold text-white truncate">
            Theme: Cyber Cyan...
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="py-2 px-2.5 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-[11px] font-bold text-white text-center">
            🔥 Overdrive FX: ON
          </div>
          <button
            type="button"
            onClick={() => {
              const newId = allShaders.length + 1;
              const name = customName.trim() || `Cyber Custom Engine #${newId}`;
              setCustomShaders((prev) => [
                ...prev,
                { id: newId, name, category: 'CUSTOM' },
              ]);
              setCustomName('');
              triggerReplay(newId);
              onShowToast(
                'Conversion Animation Set!',
                `${newId}. ${name} is now active for all conversions.`
              );
            }}
            className="py-2 px-2.5 rounded-xl border border-[#00f5d4] bg-[#0d262e] text-[11px] font-bold text-white"
          >
            + Add &amp; Activate
          </button>
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        {(
          [
            { id: 'ALL', label: `✓ All (${allShaders.length})` },
            { id: 'HACKING', label: '💻 Hacking' },
            { id: 'CINEMATIC', label: '🎬 Cinema' },
            { id: 'CUSTOM', label: '★ Custom' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id)}
            className={`py-2 rounded-xl border text-[11px] font-bold ${
              filter === tab.id
                ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0a161a] text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 17 Shaders List */}
      <div className="space-y-2.5">
        {filtered.map((item) => {
          const isSelected = settings.activeConversionShaderId === item.id;
          return (
            <div
              key={item.id}
              onClick={() => {
                triggerReplay(item.id);
                onShowToast(
                  'Conversion Animation Set!',
                  `${item.id}. ${item.name} is now active for all conversions.`
                );
              }}
              className={`rounded-2xl border-2 p-3.5 flex items-center justify-between gap-2 cursor-pointer ${microClass} ${
                isSelected
                  ? 'border-[#00ff88] bg-[#0b2922]'
                  : 'border-[#00f5d4]/60 bg-[#091519]'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    isSelected ? 'border-[#00ff88]' : 'border-slate-400'
                  }`}
                >
                  {isSelected && (
                    <div className="w-2.5 h-2.5 rounded-full bg-[#00ff88]" />
                  )}
                </div>
                <span className="text-xs font-bold text-white truncate">
                  {item.id}. {item.name}
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] font-mono text-[#00f5d4]">
                  {item.category}
                </span>
                <button
                  type="button"
                  className="px-3 py-1.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d2228] text-xs font-bold text-white"
                >
                  ▶ Live
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ============================================================================
   ABOUT DEVELOPER SCREEN (Video 02:19 - 02:33)
============================================================================ */

export const AboutDeveloperScreen: React.FC<{
  typingConfig: AppSettings['typing'];
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onShowToast: (title: string, subtitle: string) => void;
}> = ({ typingConfig, microClass, glowClass, onBack, onShowToast }) => {
  const leftArchLines = [
    '★ TOOLKIT ARCHITECTURE ★',
    '• 3D & Normal Drawable Studio',
    '• Multi-Stop Gradient Engine',
    '• Interactive Layout XML Builder',
    '• Universal Conversion Engine',
    '⚡ 17+ Cinematic Visual Shaders',
    '• Quantum Core & Matrix Rain',
    '• AI Neural Cortex & Singularity',
    '• Eldritch Mandala & Mech HUD',
    '• Crystal Prism & Supernova',
    '✨ 25+ Screen Transitions',
    '• Custom Mix & Match Studio',
    '• Zero-Error AST Syntax Verifier',
    '• Auto-Fix & Nullability Engine',
    '• Real-Time Live XML Renderer',
    '• Custom Asset Font System',
    '• One-Click SAF Export & Share',
    'ENGINEERED FOR PRECISION',
  ];

  const rightCreditsLines = [
    '★ DEVELOPER CREDITS ★',
    '👑 Ns mods — Program Creator',
    '• Core Systems & Modding Logic',
    '• UI/UX Architecture & Design',
    '🔥 Ns mods — Lead Modder',
    '• Graphic Design & Cyber Theme',
    '• App Modding & Tool Engineering',
    '★ OUR MISSION & VISION ★',
    '• Empower Android Modders',
    '• 100% Offline High-Speed Tools',
    '• Next-Gen Hacking Visuals',
    '• Clean & Professional Workflow',
    '★ OFFICIAL COMMUNITY ★',
    '• Telegram: t.me/Sharechat_ns_098',
    '• Official Brand: Ns mods',
    '• Thank You For Using Our App!',
    '~ THIS TOOLS BY NS MODS ~',
  ];

  const openExternal = (label: string, url: string) => {
    onShowToast(`Opening ${label}`, url);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="flex flex-col pb-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          <AnimatedText text="About Developer" config={typingConfig} />
        </h1>
        <div className="w-14" />
      </div>

      {/* Exclusive Ns mods Developer Profile Showcase */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-4 mb-3.5 flex flex-col items-center text-center ${glowClass}`}
      >
        <div className="w-24 h-24 rounded-full border-2 border-[#00f5d4] p-1.5 shadow-[0_0_24px_rgba(0,245,212,0.45)] mb-3 bg-gradient-to-br from-[#00f5d4]/30 via-[#061217] to-[#ff2a85]/30 flex items-center justify-center">
          <svg viewBox="0 0 100 100" className="w-full h-full rounded-full">
            <circle cx="50" cy="50" r="48" fill="#07161c" />
            <polygon
              points="50,12 83,31 83,69 50,88 17,69 17,31"
              fill="#0b2229"
              stroke="#00f5d4"
              strokeWidth="3"
            />
            <text
              x="50"
              y="57"
              textAnchor="middle"
              fill="#00f5d4"
              fontSize="24"
              fontWeight="900"
            >
              NS
            </text>
          </svg>
        </div>
        <div className="text-lg font-extrabold text-[#00f5d4] tracking-wide">
          Ns mods
        </div>
        <div className="text-xs text-slate-200 font-semibold mt-1">
          Program Creator • Lead Developer • Designer &amp; App Modder
        </div>
        <div className="mt-2 text-[11px] font-mono text-[#ff2a85]">
          Official Telegram: t.me/Sharechat_ns_098
        </div>
      </div>

      {/* Dual-Column Vertical Auto-Scrolling Marquee Box */}
      <div className="grid grid-cols-2 gap-2.5 mb-3.5">
        {/* Left Marquee Box */}
        <div
          className={`h-44 overflow-hidden rounded-2xl border-2 bg-[#071216] p-2.5 relative ${glowClass}`}
        >
          <div className="animate-marquee-vertical space-y-2 text-[10px] leading-relaxed">
            {[...leftArchLines, ...leftArchLines].map((line, i) => (
              <div
                key={i}
                className={
                  line.startsWith('★') || line.startsWith('ENGINEERED')
                    ? 'font-extrabold text-[#00f5d4] text-center pt-1'
                    : line.startsWith('⚡') || line.startsWith('✨')
                    ? 'font-bold text-[#ff2a85]'
                    : 'text-slate-200'
                }
              >
                {line}
              </div>
            ))}
          </div>
        </div>

        {/* Right Marquee Box */}
        <div
          className={`h-44 overflow-hidden rounded-2xl border-2 bg-[#071216] p-2.5 relative ${glowClass}`}
        >
          <div className="animate-marquee-vertical space-y-2 text-[10px] leading-relaxed">
            {[...rightCreditsLines, ...rightCreditsLines].map((line, i) => (
              <div
                key={i}
                className={
                  line.startsWith('★') || line.startsWith('~')
                    ? 'font-extrabold text-[#00f5d4] text-center pt-1'
                    : line.startsWith('👑') || line.startsWith('🔥')
                    ? 'font-bold text-[#ff2a85]'
                    : 'text-slate-200'
                }
              >
                {line}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Official Links Stack */}
      <div className="space-y-2.5">
        <button
          type="button"
          onClick={() =>
            openExternal('Telegram Channel', 'https://t.me/Sharechat_ns_098')
          }
          className={`w-full py-3.5 rounded-2xl border-2 border-[#00f5d4] bg-gradient-to-r from-[#091c22] via-[#0e2d36] to-[#091c22] text-xs font-extrabold text-[#00f5d4] tracking-wider uppercase shadow-[0_0_18px_rgba(0,245,212,0.28)] ${glowClass} ${microClass}`}
        >
          ✈️ TELEGRAM (Official Channel)
        </button>

        <button
          type="button"
          onClick={() =>
            openExternal('GitHub Repository', 'https://t.me/Sharechat_ns_098')
          }
          className={`w-full py-3.5 rounded-2xl border-2 bg-[#091519] text-xs font-extrabold text-white tracking-wider uppercase ${glowClass} ${microClass}`}
        >
          GITHUB (Repository)
        </button>

        <button
          type="button"
          onClick={() =>
            openExternal('YouTube Channel', 'https://t.me/Sharechat_ns_098')
          }
          className={`w-full py-3.5 rounded-2xl border-2 bg-[#091519] text-xs font-extrabold text-white tracking-wider uppercase ${glowClass} ${microClass}`}
        >
          YOUTUBE CHANNEL
        </button>

        <button
          type="button"
          onClick={() =>
            openExternal('Facebook', 'https://t.me/Sharechat_ns_098')
          }
          className={`w-full py-3.5 rounded-2xl border-2 bg-[#091519] text-xs font-extrabold text-white tracking-wider uppercase ${glowClass} ${microClass}`}
        >
          FACEBOOK
        </button>

        <div
          className={`w-full py-3.5 rounded-2xl border-2 bg-[#091519] text-center text-xs font-extrabold text-[#00f5d4] tracking-wider ${glowClass}`}
        >
          This Tools By Ns mods
        </div>
      </div>
    </div>
  );
};
