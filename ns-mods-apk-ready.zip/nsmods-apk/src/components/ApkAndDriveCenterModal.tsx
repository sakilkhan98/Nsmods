import JSZip from 'jszip';
import React, { useEffect, useState } from 'react';
import { User } from 'firebase/auth';
import {
  DexDialogConfig,
  compileRealDalvikDex,
  generateDisassembledSmaliText,
} from '../utils/dexCompiler';
import {
  DriveFileItem,
  createDriveFolder,
  deleteDriveFile,
  getAccessToken,
  googleSignIn,
  initAuth,
  listDriveFiles,
  logout,
  uploadBlobToDrive,
} from '../utils/googleDriveService';
import {
  buildUniversalModdingGuide,
  triggerBlobDownload,
} from '../utils/packageGenerator';

interface ApkAndDriveCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  onPromptInstall: () => void;
  onShowToast: (title: string, subtitle: string) => void;
}

export async function generateStandaloneApkBlob(): Promise<{
  apkBlob: Blob;
  dexBytes: Uint8Array;
  smaliText: string;
  guideText: string;
}> {
  const defaultModMenuConfig: DexDialogConfig = {
    className: 'NsModLoader',
    entryMethodName: 'show',
    title: 'Ns VIP Mod Menu v10.0 PRO',
    message:
      'Floating Mod Menu with Full-Length YouTube Video Player, Full Spotify Songs, Ludo Game & Baning Report',
    positiveBtnText: 'START',
    negativeBtnText: 'CLOSE',
    telegramUrl: 'https://t.me/',
    bgColorHex: '#071318',
    accentColorHex: '#00f5d4',
    textColorHex: '#ffffff',
    cornerRadiusDp: 20,
    strokeWidthDp: 2,
    extraConfigTag: 'vip_mod_menu',
    executionMode: 'layout_overlay',
    isFloatingModMenu: true,
    enableLudoModule: true,
    ludoUrl: 'https://ludo-master-three.vercel.app',
    enableBaningReport: true,
    baningReportUrl: 'https://sc-baning-report.vercel.app/',
    enableYoutubeModule: true,
    enableSpotifyModule: true,
    autoMinimizeOnAppOpen: true,
    layoutWidgets: [
      {
        type: 'Switch',
        text: 'God Mode / Antiban Protection',
        textColorHex: '#ffffff',
        bgColorHex: '#0a1e24',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 13,
        checked: true,
      },
      {
        type: 'Switch',
        text: 'Full HD 120 FPS Unlocker',
        textColorHex: '#ffffff',
        bgColorHex: '#0a1e24',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 13,
        checked: true,
      },
      {
        type: 'SeekBar',
        text: 'VIP Speed Boost',
        textColorHex: '#ffffff',
        bgColorHex: '#0a1e24',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 13,
        progress: 100,
      },
    ],
  };

  const dexBytes = compileRealDalvikDex(defaultModMenuConfig);
  const smaliText = generateDisassembledSmaliText(defaultModMenuConfig);
  const guideText = buildUniversalModdingGuide({
    toolTitle: 'Ns_Mods_v10_Pro_APK',
    className: 'NsModLoader',
    primaryHook: 'invoke-static {p0}, Lcom/nsmods/NsModLoader;->show(Landroid/app/Activity;)V',
    descriptionEn: 'Standalone Pro APK & Mod Menu Loader',
    descriptionBn: 'স্ট্যান্ডঅ্যালোন প্রো APK ও মড মেনু লোডার',
    compiledSmaliPreview: smaliText,
    isPureLayout: true,
  });

  const zip = new JSZip();
  zip.file('classes.dex', dexBytes, { compression: 'DEFLATE' });
  zip.file(
    'AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.nsmods.vip.v10pro"
    android:versionCode="100"
    android:versionName="10.0-PRO">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <application
        android:allowBackup="true"
        android:label="Ns Mods v10.0 PRO"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true">
        <activity
            android:name="com.nsmods.vip.v10pro.MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
  );
  zip.file('smali/com/nsmods/NsModLoader.smali', smaliText);
  zip.file('assets/Modding_Guide_Bangla_And_English.txt', guideText);
  zip.file(
    'META-INF/MANIFEST.MF',
    'Manifest-Version: 1.0\r\nCreated-By: Ns Mods v10.0 PRO APK Builder\r\n\r\n'
  );

  const rawZipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
  });
  const apkBlob = new Blob([rawZipBlob], {
    type: 'application/vnd.android.package-archive',
  });

  return { apkBlob, dexBytes, smaliText, guideText };
}

export const ApkAndDriveCenterModal: React.FC<ApkAndDriveCenterModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  onPromptInstall,
  onShowToast,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState<boolean>(true);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  const [activeHubTab, setActiveHubTab] = useState<'apk_guide' | 'drive_backup'>('apk_guide');
  const [isBuildingApk, setIsBuildingApk] = useState<boolean>(false);
  const [isUploadingAll, setIsUploadingAll] = useState<boolean>(false);
  const [uploadProgressText, setUploadProgressText] = useState<string>('');
  const [uploadPercent, setUploadPercent] = useState<number>(0);
  const [uploadedFolderUrl, setUploadedFolderUrl] = useState<string>('');
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const [loadingDriveFiles, setLoadingDriveFiles] = useState<boolean>(false);

  // Mandatory Confirmation Dialog state before deleting any file from Google Drive
  const [pendingDeleteFile, setPendingDeleteFile] =
    useState<DriveFileItem | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  useEffect(() => {
    const unsub = initAuth(
      (u, t) => {
        setUser(u);
        setToken(t);
        setNeedsAuth(false);
      },
      () => {
        setNeedsAuth(true);
      }
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    if (isOpen && token && !needsAuth) {
      refreshDriveFileList(token);
    }
  }, [isOpen, token, needsAuth]);

  const refreshDriveFileList = async (activeToken: string) => {
    setLoadingDriveFiles(true);
    try {
      const files = await listDriveFiles(activeToken);
      setDriveFiles(files);
    } catch {
      // ignore
    } finally {
      setLoadingDriveFiles(false);
    }
  };

  const handleGoogleLogin = async (): Promise<string | null> => {
    setIsLoggingIn(true);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        setNeedsAuth(false);
        onShowToast(
          'Google Drive Connected ✓',
          `Signed in as ${res.user.email || res.user.displayName || 'User'}`
        );
        refreshDriveFileList(res.accessToken);
        return res.accessToken;
      }
    } catch (err: any) {
      onShowToast(
        'Google Sign-In Failed',
        err?.message || 'Could not sign in to Google Drive.'
      );
    } finally {
      setIsLoggingIn(false);
    }
    return null;
  };

  const handleDirectApkDownload = async () => {
    setIsBuildingApk(true);
    try {
      const { apkBlob } = await generateStandaloneApkBlob();
      triggerBlobDownload(apkBlob, 'Ns_Mods_v10_Pro.apk');
      onShowToast(
        '📲 Ns_Mods_v10_Pro.apk ডাউনলোড শুরু হয়েছে!',
        'ফোনের Download ফোল্ডারে APK ফাইলটি সেভ হচ্ছে।'
      );
    } catch (err: any) {
      onShowToast(
        'APK Build Error',
        err?.message || 'Failed to build APK file.'
      );
    } finally {
      setIsBuildingApk(false);
    }
  };

  const handleDownloadFullApkZip = async () => {
    setIsBuildingApk(true);
    try {
      const { apkBlob, dexBytes, smaliText, guideText } =
        await generateStandaloneApkBlob();
      const masterZip = new JSZip();
      masterZip.file('Ns_Mods_v10_Pro.apk', apkBlob);
      masterZip.file('classes.dex', dexBytes);
      masterZip.file('NsModLoader.smali', smaliText);
      masterZip.file('Bangla_APK_Install_Guide.txt', guideText);

      const zipBlob = await masterZip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
      });
      triggerBlobDownload(zipBlob, 'Ns_Mods_v10_Pro_APK_And_DEX_Bundle.zip');
      onShowToast(
        '📦 APK + classes.dex Bundle Downloaded!',
        'MT Manager ও সরাসরি ইনস্টলের সব ফাইল ডাউনলোড হয়েছে।'
      );
    } catch (err: any) {
      onShowToast('Download Error', err?.message || 'Could not create bundle.');
    } finally {
      setIsBuildingApk(false);
    }
  };

  const handleUploadAllFilesToDrive = async () => {
    let activeToken = token || (await getAccessToken());
    if (!activeToken || needsAuth) {
      activeToken = await handleGoogleLogin();
      if (!activeToken) return;
    }

    setIsUploadingAll(true);
    setUploadPercent(5);
    setUploadProgressText('Google Drive-এ নতুন ফোল্ডার তৈরি হচ্ছে...');

    try {
      // 1. Create folder on Google Drive
      const folderName = `Ns_Mods_v10_PRO_APK_And_All_Files_${new Date()
        .toISOString()
        .slice(0, 10)}`;
      const folder = await createDriveFolder(folderName, activeToken);
      const folderUrl =
        folder.webViewLink ||
        `https://drive.google.com/drive/folders/${folder.id}`;
      setUploadedFolderUrl(folderUrl);

      // 2. Build APK, classes.dex, and Smali
      setUploadPercent(15);
      setUploadProgressText('Ns_Mods_v10_Pro.apk এবং classes.dex তৈরি হচ্ছে...');
      const { apkBlob, dexBytes, smaliText, guideText } =
        await generateStandaloneApkBlob();

      // 3. Upload Ns_Mods_v10_Pro.apk
      setUploadPercent(25);
      setUploadProgressText('Uploading Ns_Mods_v10_Pro.apk to Google Drive...');
      await uploadBlobToDrive({
        name: 'Ns_Mods_v10_Pro.apk',
        blob: apkBlob,
        mimeType: 'application/vnd.android.package-archive',
        parentFolderId: folder.id,
        token: activeToken,
      });

      // 4. Upload classes.dex
      setUploadPercent(35);
      setUploadProgressText('Uploading classes.dex (Real Dalvik DEX)...');
      await uploadBlobToDrive({
        name: 'classes.dex',
        blob: new Blob([dexBytes.buffer as ArrayBuffer], {
          type: 'application/octet-stream',
        }),
        mimeType: 'application/octet-stream',
        parentFolderId: folder.id,
        token: activeToken,
      });

      // 5. Upload NsModLoader.smali
      setUploadPercent(45);
      setUploadProgressText('Uploading NsModLoader.smali...');
      await uploadBlobToDrive({
        name: 'NsModLoader.smali',
        blob: new Blob([smaliText], { type: 'text/plain' }),
        mimeType: 'text/plain',
        parentFolderId: folder.id,
        token: activeToken,
      });

      // 6. Fetch all project source files from /api/project-files
      setUploadPercent(55);
      setUploadProgressText('প্রজেক্টের সব সোর্স ফাইল সংগ্রহ করা হচ্ছে...');
      const res = await fetch('/api/project-files');
      const data = await res.json();
      const projectFiles: Array<{
        path: string;
        name: string;
        content: string;
        mimeType: string;
      }> = Array.isArray(data?.files) ? data.files : [];

      // Create Complete Master Project ZIP + upload individual files
      const fullProjectZip = new JSZip();
      fullProjectZip.file('Ns_Mods_v10_Pro.apk', apkBlob);
      fullProjectZip.file('classes.dex', dexBytes);
      fullProjectZip.file('NsModLoader.smali', smaliText);
      fullProjectZip.file('Modding_Guide.txt', guideText);
      for (const pf of projectFiles) {
        fullProjectZip.file(pf.path, pf.content);
      }

      setUploadPercent(65);
      setUploadProgressText(
        'Uploading NsMods_v10_Complete_All_Files.zip to Google Drive...'
      );
      const fullZipBlob = await fullProjectZip.generateAsync({
        type: 'blob',
        compression: 'DEFLATE',
      });
      await uploadBlobToDrive({
        name: 'NsMods_v10_Complete_All_Files.zip',
        blob: fullZipBlob,
        mimeType: 'application/zip',
        parentFolderId: folder.id,
        token: activeToken,
      });

      // 7. Upload individual project files to the folder
      for (let i = 0; i < projectFiles.length; i++) {
        const pf = projectFiles[i];
        const pct = 68 + Math.round(((i + 1) / projectFiles.length) * 30);
        setUploadPercent(pct);
        setUploadProgressText(
          `Uploading (${i + 1}/${projectFiles.length}): ${pf.path}...`
        );
        await uploadBlobToDrive({
          name: pf.path.replace(/\//g, '__'),
          blob: new Blob([pf.content], { type: pf.mimeType || 'text/plain' }),
          mimeType: pf.mimeType || 'text/plain',
          parentFolderId: folder.id,
          token: activeToken,
        });
      }

      setUploadPercent(100);
      setUploadProgressText(
        `✅ ১০০% সম্পন্ন! APK, classes.dex এবং সব প্রজেক্ট ফাইল Google Drive-এ আপলোড হয়েছে!`
      );
      onShowToast(
        '☁️ সব ফাইল Google Drive-এ আপলোড সম্পন্ন!',
        'Ns_Mods_v10_Pro.apk সহ সব ফাইল আপনার Google Drive-এ সেভ হয়েছে।'
      );
      refreshDriveFileList(activeToken);
    } catch (err: any) {
      setUploadProgressText(`❌ Error: ${err?.message || 'Upload failed'}`);
      onShowToast(
        'Google Drive Upload Error',
        err?.message || 'Please sign in with Google and try again.'
      );
    } finally {
      setIsUploadingAll(false);
    }
  };

  const confirmAndDeleteDriveFile = async () => {
    if (!pendingDeleteFile) return;
    const activeToken = token || (await getAccessToken());
    if (!activeToken) {
      setNeedsAuth(true);
      setPendingDeleteFile(null);
      return;
    }
    setIsDeleting(true);
    try {
      await deleteDriveFile(pendingDeleteFile.id, activeToken);
      setDriveFiles((prev) =>
        prev.filter((f) => f.id !== pendingDeleteFile.id)
      );
      onShowToast(
        'File Deleted from Google Drive',
        `${pendingDeleteFile.name} was removed.`
      );
    } catch (err: any) {
      onShowToast(
        'Delete Failed',
        err?.message || 'Could not delete file from Google Drive.'
      );
    } finally {
      setIsDeleting(false);
      setPendingDeleteFile(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 overflow-y-auto">
      <div className="relative w-full max-w-[440px] max-h-[92vh] overflow-y-auto rounded-2xl border-2 border-[#00f5d4] bg-[#071318] p-4 text-white shadow-[0_0_35px_rgba(0,245,212,0.35)] space-y-4">
        {/* Top Modal Header */}
        <div className="flex items-center justify-between border-b border-[#00f5d4]/30 pb-3">
          <div>
            <h2 className="text-base font-extrabold text-[#00f5d4] flex items-center gap-1.5">
              <span>📲</span>
              <span>@Nsmods Hub — APK &amp; WebApp Guide</span>
            </h2>
            <p className="text-[11px] text-slate-300 mt-0.5">
              ফোনে ইনস্টল গাইড, ডিরেক্ট APK এবং ডেভেলপার ক্লাউড ব্যাকআপ
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg border border-white/20 bg-white/5 hover:bg-white/15 flex items-center justify-center text-sm font-bold"
          >
            ✕
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex rounded-xl bg-[#09171b] p-1 border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveHubTab('apk_guide')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeHubTab === 'apk_guide'
                ? 'bg-[#00f5d4] text-[#041014] shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            📲 ফোনে Install ও APK
          </button>
          <button
            type="button"
            onClick={() => setActiveHubTab('drive_backup')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeHubTab === 'drive_backup'
                ? 'bg-[#3ea6ff] text-[#041014] shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            ☁️ Google Drive
          </button>
        </div>

        {activeHubTab === 'apk_guide' ? (
          <>
            {/* SECTION 1: DIRECT APK DOWNLOAD & PHONE INSTALL BUTTONS */}
            <div className="rounded-xl border border-[#00ff88]/50 bg-[#0a211b] p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-[#00ff88]">
                  🚀 সরাসরি ইনস্টল ও APK ডাউনলোড
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#00ff88]/20 text-[#00ff88] text-[9px] font-black">
                  @Nsmods v10
                </span>
              </div>

              {/* Primary Button: Direct .APK File Download */}
              <button
                type="button"
                disabled={isBuildingApk}
                onClick={handleDirectApkDownload}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#00f5d4] to-[#00ff88] text-[#041014] font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(0,255,136,0.4)] hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>📲</span>
                <span>
                  {isBuildingApk
                    ? 'APK তৈরি হচ্ছে...'
                    : 'Download Standalone APK (@Nsmods_v10_Pro.apk)'}
                </span>
              </button>

              {/* Secondary Buttons Row: Direct App Install + MT Manager ZIP */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    if (isInstallable) {
                      onPromptInstall();
                    } else {
                      onShowToast(
                        '📲 ব্রাউজার মেনু থেকে Install App চাপুন',
                        'Chrome-এর উপরে ৩-ডট (⋮) মেনুতে গিয়ে "Install App" বা "Add to Home screen" চাপলে সরাসরি আসল অ্যাপ হিসেবে ইনস্টল হয়ে যাবে!'
                      );
                    }
                  }}
                  className="py-2.5 px-2.5 rounded-xl border border-[#00f5d4] bg-[#0b252c] hover:bg-[#113540] text-[#00f5d4] font-extrabold text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>⚡</span>
                  <span>সরাসরি ফোনে Install</span>
                </button>

                <button
                  type="button"
                  disabled={isBuildingApk}
                  onClick={handleDownloadFullApkZip}
                  className="py-2.5 px-2.5 rounded-xl border border-[#ffd166]/60 bg-[#241d0b] hover:bg-[#33290f] text-[#ffd166] font-extrabold text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>📦</span>
                  <span>APK + DEX Bundle ZIP</span>
                </button>
              </div>
            </div>

            {/* STEP-BY-STEP BANGLA GUIDE */}
            <div className="rounded-xl border border-[#00f5d4]/40 bg-[#09191f] p-3.5 space-y-2 text-[11.5px] leading-relaxed text-slate-200">
              <div className="text-xs font-extrabold text-[#00f5d4]">
                📖 আপনার ফোনে অ্যাপটি কীভাবে চালাবেন (বাংলা গাইড):
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-[11px]">
                <li>
                  <b>পদ্ধতি ১ — সরাসরি ফোনে ১-ক্লিকে Native App হিসেবে ইনস্টল (সবচেয়ে স্মুথ):</b>{' '}
                  Chrome বা Samsung Internet ব্রাউজারের উপরে ৩-ডট (⋮) মেনুতে যান এবং{' '}
                  <span className="text-[#00ff88] font-bold">"Add to Home screen"</span> বা{' '}
                  <span className="text-[#00ff88] font-bold">"Install app"</span> এ ট্যাপ করুন।
                  সাথে সাথে আপনার মোবাইলে <b>@Nsmods</b> এর আসল অ্যাপ ইনস্টল হয়ে যাবে, কোনো ব্রাউজার ইউআই থাকবে না এবং অফলাইনেও চলবে!
                </li>
                <li>
                  <b>পদ্ধতি ২ — Direct APK ডাউনলোড ও MT Manager দিয়ে Sign:</b>{' '}
                  উপরে <span className="text-[#00ff88] font-bold">"Download Standalone APK"</span> বাটনে চাপলে ফোনের <b>Download</b> ফোল্ডারে APK ফাইলটি সেভ হবে। এরপর <b>MT Manager</b> ওপেন করে ফাইলটিতে ট্যাপ করে <b>Function → Sign file (Auto Sign)</b> করে সরাসরি মোবাইলে ইনস্টল করুন!
                </li>
                <li>
                  <b>পদ্ধতি ৩ — ডেভেলপারদের জন্য Bubblewrap / Capacitor বিল্ড:</b>{' '}
                  কমান্ড লাইনে সাইন করা রিলিজ APK বানাতে টার্মিনালে চালান:{' '}
                  <code className="text-[#00f5d4] bg-black/60 px-1 py-0.5 rounded">npx @bubblewrap/cli build</code>
                </li>
              </ol>
            </div>
          </>
        ) : (
          /* SECTION 2: GOOGLE DRIVE 1-CLICK UPLOAD ALL FILES */
          <div className="rounded-xl border border-[#3ea6ff]/50 bg-[#0a1826] p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-[#3ea6ff]">
                ☁️ Google Drive-এ সব ফাইল ও APK আপলোড
              </span>
              {user && !needsAuth && (
                <button
                  type="button"
                  onClick={async () => {
                    await logout();
                    setUser(null);
                    setToken(null);
                    setNeedsAuth(true);
                  }}
                  className="text-[10px] text-slate-300 hover:text-white underline"
                >
                  Sign out
                </button>
              )}
            </div>

            {needsAuth || !token ? (
              <div className="space-y-2">
                <p className="text-[11px] text-slate-300">
                  আপনার Google Drive-এ <b>@Nsmods</b> APK, <b>classes.dex</b> এবং প্রজেক্টের সব সোর্স ফাইল এক ক্লিকে ব্যাকআপ রাখতে নিচের বাটনে সাইন-ইন করুন:
                </p>
                <button
                  type="button"
                  disabled={isLoggingIn}
                  onClick={handleGoogleLogin}
                  className="gsi-material-button w-full py-2.5 px-4 rounded-xl bg-white text-[#1f1f1f] font-bold text-xs flex items-center justify-center gap-2.5 shadow hover:bg-slate-100 cursor-pointer"
                >
                  <div className="gsi-material-button-state"></div>
                  <div className="gsi-material-button-content-wrapper flex items-center gap-2.5">
                    <div className="gsi-material-button-icon w-4 h-4">
                      <svg
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 48 48"
                        style={{ display: 'block' }}
                      >
                        <path
                          fill="#EA4335"
                          d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                        ></path>
                        <path
                          fill="#4285F4"
                          d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                        ></path>
                        <path
                          fill="#FBBC05"
                          d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                        ></path>
                        <path
                          fill="#34A853"
                          d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                        ></path>
                        <path fill="none" d="M0 0h48v48H0z"></path>
                      </svg>
                    </div>
                    <span className="gsi-material-button-contents">
                      {isLoggingIn ? 'Connecting...' : 'Sign in with Google'}
                    </span>
                  </div>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                <div className="text-[11px] text-emerald-300 font-semibold truncate">
                  ✓ Connected: {user?.email || user?.displayName}
                </div>

                <button
                  type="button"
                  disabled={isUploadingAll}
                  onClick={handleUploadAllFilesToDrive}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#3ea6ff] hover:bg-[#5bb4ff] text-[#041014] font-black text-xs flex items-center justify-center gap-2 shadow cursor-pointer"
                >
                  <span>☁️</span>
                  <span>
                    {isUploadingAll
                      ? 'Google Drive-এ আপলোড হচ্ছে...'
                      : 'Upload All Files & APK to Google Drive'}
                  </span>
                </button>

                {uploadProgressText && (
                  <div className="space-y-1.5 pt-1">
                    <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#00f5d4] to-[#00ff88] transition-all duration-300"
                        style={{ width: `${uploadPercent}%` }}
                      />
                    </div>
                    <div className="text-[10.5px] text-slate-200 font-mono">
                      {uploadProgressText}
                    </div>
                  </div>
                )}

                {uploadedFolderUrl && (
                  <a
                    href={uploadedFolderUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full py-2 px-3 rounded-lg border border-[#00ff88] bg-[#09261e] text-[#00ff88] text-center text-xs font-extrabold hover:bg-[#0f382c]"
                  >
                    📂 Open Uploaded Folder in Google Drive ↗
                  </a>
                )}

                {/* Recent Drive Files List with Delete Confirmation */}
                {driveFiles.length > 0 && (
                  <div className="pt-2 border-t border-white/10 space-y-1.5">
                    <div className="flex items-center justify-between text-[10px] text-slate-300 font-bold">
                      <span>সাম্প্রতিক Google Drive ফাইলসমূহ:</span>
                      <button
                        type="button"
                        onClick={() => token && refreshDriveFileList(token)}
                        className="text-[#3ea6ff] hover:underline"
                      >
                        {loadingDriveFiles ? '...' : '↻ Refresh'}
                      </button>
                    </div>
                    <div className="max-h-32 overflow-y-auto space-y-1 pr-1">
                      {driveFiles.slice(0, 8).map((df) => (
                        <div
                          key={df.id}
                          className="flex items-center justify-between gap-2 px-2 py-1 rounded bg-black/40 border border-white/10 text-[10px]"
                        >
                          <a
                            href={
                              df.webViewLink ||
                              `https://drive.google.com/file/d/${df.id}/view`
                            }
                            target="_blank"
                            rel="noopener noreferrer"
                            className="truncate text-slate-200 hover:text-[#00f5d4] flex-1"
                          >
                            📄 {df.name}
                          </a>
                          <button
                            type="button"
                            onClick={() => setPendingDeleteFile(df)}
                            className="text-rose-400 hover:text-rose-300 px-1.5 py-0.5 rounded bg-rose-950/50 text-[9px] font-bold shrink-0"
                          >
                            Delete
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Mandatory Destructive Action Confirmation Modal for Deleting a Google Drive File */}
        {pendingDeleteFile && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
            <div className="w-full max-w-[340px] rounded-2xl border-2 border-rose-500 bg-[#14090c] p-4 text-white space-y-3 shadow-2xl">
              <div className="text-sm font-extrabold text-rose-400">
                ⚠️ Confirm Delete from Google Drive?
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                Are you sure you want to permanently delete{' '}
                <b className="text-white">"{pendingDeleteFile.name}"</b> from
                your Google Drive? This action cannot be undone.
              </p>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={() => setPendingDeleteFile(null)}
                  className="px-3 py-1.5 rounded-lg border border-white/20 bg-white/10 text-xs font-bold text-slate-200 hover:bg-white/20"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={confirmAndDeleteDriveFile}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-extrabold text-white"
                >
                  {isDeleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
