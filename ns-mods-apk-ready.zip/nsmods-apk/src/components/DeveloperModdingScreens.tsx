import JSZip from 'jszip';
import React, { useMemo, useState } from 'react';
import { AnimatedText } from './AnimatedText';
import { TypingConfig } from '../types/appTypes';
import { triggerBlobDownload } from '../utils/packageGenerator';

interface CommonToolProps {
  typingConfig: TypingConfig;
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onSaveHistory: (title: string, code: string) => void;
  onShowToast: (title: string, subtitle: string) => void;
}

/* =====================================================================
   TOOL 1: ANDROID MANIFEST ARCHITECT & SECURITY BYPASS STUDIO
   ===================================================================== */
interface PermissionItem {
  name: string;
  category: 'DANGEROUS' | 'OVERLAY' | 'NETWORK' | 'STORAGE' | 'SYSTEM';
  description: string;
  recommendedForMods?: boolean;
}

const AVAILABLE_PERMISSIONS: PermissionItem[] = [
  {
    name: 'android.permission.SYSTEM_ALERT_WINDOW',
    category: 'OVERLAY',
    description: 'Allows Floating Mod Menu overlay on top of all other apps',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.INTERNET',
    category: 'NETWORK',
    description: 'Allows network communication for online mods & bypasses',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.ACCESS_NETWORK_STATE',
    category: 'NETWORK',
    description: 'Allows checking network state & Wi-Fi connection',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.FOREGROUND_SERVICE',
    category: 'OVERLAY',
    description: 'Keeps mod menu floating service running without being killed',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
    category: 'OVERLAY',
    description: 'Android 14+ required permission for background mod overlays',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.VIBRATE',
    category: 'SYSTEM',
    description: 'Haptic feedback on mod button touches and toggles',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.WAKE_LOCK',
    category: 'SYSTEM',
    description: 'Prevents CPU from sleeping during gameplay & mod loops',
    recommendedForMods: true,
  },
  {
    name: 'android.permission.WRITE_EXTERNAL_STORAGE',
    category: 'STORAGE',
    description: 'Write mod configs and inject save data (Android 5-10)',
  },
  {
    name: 'android.permission.READ_EXTERNAL_STORAGE',
    category: 'STORAGE',
    description: 'Read game OBB and mod resources from storage',
  },
  {
    name: 'android.permission.MANAGE_EXTERNAL_STORAGE',
    category: 'STORAGE',
    description: 'All-files access for Android 11+ data/obb file modding',
  },
  {
    name: 'android.permission.REQUEST_INSTALL_PACKAGES',
    category: 'DANGEROUS',
    description: 'Allows in-app auto-updating and APK installer plugins',
  },
  {
    name: 'android.permission.POST_NOTIFICATIONS',
    category: 'SYSTEM',
    description: 'Show floating status notifications on Android 13+',
  },
];

export const ManifestArchitectScreen: React.FC<CommonToolProps> = ({
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [packageName, setPackageName] = useState('com.nsmods.vip.modmenu');
  const [appLabel, setAppLabel] = useState('Ns Mods VIP');
  const [mainActivityName, setMainActivityName] = useState(
    'com.nsmods.MainActivity'
  );
  const [themeStyle, setThemeStyle] = useState(
    '@android:style/Theme.DeviceDefault.NoActionBar'
  );
  const [debuggable, setDebuggable] = useState(true);
  const [cleartextTraffic, setCleartextTraffic] = useState(true);
  const [hardwareAccelerated, setHardwareAccelerated] = useState(true);
  const [requestLegacyStorage, setRequestLegacyStorage] = useState(true);
  const [antiBanSignatureBypass, setAntiBanSignatureBypass] = useState(true);
  const [enableDeepLink, setEnableDeepLink] = useState(true);
  const [deepLinkScheme, setDeepLinkScheme] = useState('nsmods');
  const [customPermissionInput, setCustomPermissionInput] = useState('');
  const [selectedPermissions, setSelectedPermissions] = useState<Set<string>>(
    new Set([
      'android.permission.SYSTEM_ALERT_WINDOW',
      'android.permission.INTERNET',
      'android.permission.ACCESS_NETWORK_STATE',
      'android.permission.FOREGROUND_SERVICE',
      'android.permission.VIBRATE',
    ])
  );

  const togglePermission = (name: string) => {
    setSelectedPermissions((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const addCustomPermission = () => {
    const perm = customPermissionInput.trim();
    if (!perm) return;
    setSelectedPermissions((prev) => new Set([...prev, perm]));
    setCustomPermissionInput('');
    onShowToast('Permission Added', perm);
  };

  const applyPreset = (presetName: string) => {
    if (presetName === 'floating_mod') {
      setSelectedPermissions(
        new Set([
          'android.permission.SYSTEM_ALERT_WINDOW',
          'android.permission.INTERNET',
          'android.permission.ACCESS_NETWORK_STATE',
          'android.permission.FOREGROUND_SERVICE',
          'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
          'android.permission.VIBRATE',
          'android.permission.WAKE_LOCK',
        ])
      );
      setCleartextTraffic(true);
      setDebuggable(true);
      setHardwareAccelerated(true);
      onShowToast(
        'Preset Applied',
        'Floating Mod Menu Permissions & Flags Injected'
      );
    } else if (presetName === 'antiban') {
      setAntiBanSignatureBypass(true);
      setDebuggable(false);
      setCleartextTraffic(true);
      setSelectedPermissions(
        new Set([
          'android.permission.INTERNET',
          'android.permission.ACCESS_NETWORK_STATE',
        ])
      );
      onShowToast('Preset Applied', 'Anti-Ban & Stealth Flags Enabled');
    } else if (presetName === 'minimal') {
      setSelectedPermissions(new Set(['android.permission.INTERNET']));
      setDebuggable(false);
      onShowToast('Preset Applied', 'Clean Minimal Manifest Configured');
    }
  };

  const generatedXml = useMemo(() => {
    const permsList = Array.from(selectedPermissions)
      .map((p) => `    <uses-permission android:name="${p}" />`)
      .join('\n');

    const deepLinkBlock = enableDeepLink
      ? `
            <!-- Custom Deep Link Launcher (Launch via ${deepLinkScheme}://) -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="${deepLinkScheme}" />
            </intent-filter>`
      : '';

    const signatureMockComment = antiBanSignatureBypass
      ? `
    <!-- Antiban Signature Spoofing Metadata -->
    <meta-data android:name="com.nsmods.antiban.bypass" android:value="true" />
    <meta-data android:name="android.max_aspect" android:value="2.5" />`
      : '';

    return `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="${packageName}"
    android:versionCode="100"
    android:versionName="10.0-PRO">

${permsList}

    <application
        android:allowBackup="true"
        android:label="${appLabel}"
        android:theme="${themeStyle}"
        android:debuggable="${debuggable}"
        android:usesCleartextTraffic="${cleartextTraffic}"
        android:hardwareAccelerated="${hardwareAccelerated}"
        android:requestLegacyExternalStorage="${requestLegacyStorage}"
        tools:ignore="HardcodedDebugMode">
${signatureMockComment}

        <!-- Main Launcher Activity -->
        <activity
            android:name="${mainActivityName}"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:windowSoftInputMode="adjustPan">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>${deepLinkBlock}
        </activity>

        <!-- Floating Mod Overlay Service -->
        <service
            android:name="com.nsmods.overlay.FloatingModService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="specialUse" />

    </application>
</manifest>`;
  }, [
    packageName,
    appLabel,
    mainActivityName,
    themeStyle,
    debuggable,
    cleartextTraffic,
    hardwareAccelerated,
    requestLegacyStorage,
    antiBanSignatureBypass,
    enableDeepLink,
    deepLinkScheme,
    selectedPermissions,
  ]);

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedXml);
    onShowToast('Copied!', 'AndroidManifest.xml copied to clipboard.');
    onSaveHistory('AndroidManifest.xml', generatedXml);
  };

  const handleDownload = () => {
    const blob = new Blob([generatedXml], { type: 'application/xml' });
    triggerBlobDownload(blob, 'AndroidManifest.xml');
    onShowToast('Downloaded!', 'AndroidManifest.xml saved.');
    onSaveHistory('AndroidManifest.xml', generatedXml);
  };

  return (
    <div className="flex flex-col space-y-3.5 pb-6">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-[#00f5d4]/30 pb-2.5">
        <button
          type="button"
          onClick={onBack}
          className="px-2.5 py-1 rounded-lg border border-[#00f5d4]/40 bg-[#0a181c] text-[#00f5d4] text-xs font-bold flex items-center gap-1 cursor-pointer"
        >
          <span>‹</span> <span>Back</span>
        </button>
        <h2 className="text-sm font-extrabold text-[#00f5d4] flex items-center gap-1.5">
          <span>📜</span>
          <AnimatedText
            text="Manifest Security Studio"
            config={typingConfig}
          />
        </h2>
        <span className="px-2 py-0.5 rounded-full bg-[#00ff88]/20 text-[#00ff88] text-[9px] font-black">
          v10 PRO
        </span>
      </div>

      {/* Quick Presets Row */}
      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => applyPreset('floating_mod')}
          className="py-1.5 px-2 rounded-xl border border-[#00f5d4]/50 bg-[#091a1f] hover:bg-[#0f2930] text-[#00f5d4] text-[10px] font-bold text-center cursor-pointer"
        >
          👑 Mod Overlay
        </button>
        <button
          type="button"
          onClick={() => applyPreset('antiban')}
          className="py-1.5 px-2 rounded-xl border border-[#ffd166]/50 bg-[#1f1a09] hover:bg-[#30270e] text-[#ffd166] text-[10px] font-bold text-center cursor-pointer"
        >
          🛡️ Anti-Ban Bypass
        </button>
        <button
          type="button"
          onClick={() => applyPreset('minimal')}
          className="py-1.5 px-2 rounded-xl border border-white/20 bg-[#121212] hover:bg-[#1e1e1e] text-white text-[10px] font-bold text-center cursor-pointer"
        >
          ⚡ Minimal Clean
        </button>
      </div>

      {/* Basic Package Info Card */}
      <div className="rounded-xl border border-[#00f5d4]/30 bg-[#071318] p-3 space-y-2.5">
        <div className="text-[11px] font-extrabold text-[#00f5d4]">
          📦 Package &amp; Application Settings
        </div>
        <div className="grid grid-cols-2 gap-2 text-[10.5px]">
          <div>
            <label className="text-[9.5px] text-slate-300 block mb-0.5 font-bold">
              Package Name
            </label>
            <input
              type="text"
              value={packageName}
              onChange={(e) => setPackageName(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-[#0b1b22] border border-white/15 text-white font-mono text-[10px]"
            />
          </div>
          <div>
            <label className="text-[9.5px] text-slate-300 block mb-0.5 font-bold">
              App Label
            </label>
            <input
              type="text"
              value={appLabel}
              onChange={(e) => setAppLabel(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-[#0b1b22] border border-white/15 text-white text-[10px]"
            />
          </div>
          <div className="col-span-2">
            <label className="text-[9.5px] text-slate-300 block mb-0.5 font-bold">
              Main Activity Name
            </label>
            <input
              type="text"
              value={mainActivityName}
              onChange={(e) => setMainActivityName(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg bg-[#0b1b22] border border-white/15 text-white font-mono text-[10px]"
            />
          </div>
        </div>

        {/* Toggles Grid */}
        <div className="grid grid-cols-2 gap-2 pt-1 text-[10px]">
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-200">
            <input
              type="checkbox"
              checked={debuggable}
              onChange={(e) => setDebuggable(e.target.checked)}
              className="accent-[#00f5d4]"
            />
            <span>android:debuggable</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-200">
            <input
              type="checkbox"
              checked={cleartextTraffic}
              onChange={(e) => setCleartextTraffic(e.target.checked)}
              className="accent-[#00f5d4]"
            />
            <span>Cleartext (HTTP) Traffic</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-200">
            <input
              type="checkbox"
              checked={antiBanSignatureBypass}
              onChange={(e) => setAntiBanSignatureBypass(e.target.checked)}
              className="accent-[#ffd166]"
            />
            <span>Antiban Meta-Data</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-200">
            <input
              type="checkbox"
              checked={enableDeepLink}
              onChange={(e) => setEnableDeepLink(e.target.checked)}
              className="accent-[#00ff88]"
            />
            <span>Deep Link ({deepLinkScheme}://)</span>
          </label>
        </div>
      </div>

      {/* Permissions Manager */}
      <div className="rounded-xl border border-[#00f5d4]/30 bg-[#071318] p-3 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-extrabold text-[#00f5d4]">
            🛡️ Permissions ({selectedPermissions.size} Selected)
          </span>
          <span className="text-[9px] text-slate-400">Tap to toggle</span>
        </div>

        <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
          {AVAILABLE_PERMISSIONS.map((perm) => {
            const isChecked = selectedPermissions.has(perm.name);
            return (
              <div
                key={perm.name}
                onClick={() => togglePermission(perm.name)}
                className={`p-2 rounded-lg border text-[10px] cursor-pointer transition-all flex items-start justify-between gap-2 ${
                  isChecked
                    ? 'border-[#00f5d4] bg-[#0c242b] text-white'
                    : 'border-white/10 bg-[#0a1519] text-slate-400 hover:border-white/20'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="font-mono font-bold truncate">
                    {perm.name.replace('android.permission.', '')}
                  </div>
                  <div className="text-[8.5px] opacity-80 mt-0.5 truncate">
                    {perm.description}
                  </div>
                </div>
                <span
                  className={`text-[8.5px] font-black px-1.5 py-0.5 rounded ${
                    perm.category === 'OVERLAY'
                      ? 'bg-purple-900/60 text-purple-300'
                      : perm.category === 'DANGEROUS'
                      ? 'bg-rose-900/60 text-rose-300'
                      : 'bg-emerald-900/60 text-emerald-300'
                  }`}
                >
                  {isChecked ? '✓ ON' : perm.category}
                </span>
              </div>
            );
          })}
        </div>

        {/* Custom Permission Input */}
        <div className="flex gap-1.5 pt-1">
          <input
            type="text"
            value={customPermissionInput}
            onChange={(e) => setCustomPermissionInput(e.target.value)}
            placeholder="Add custom permission..."
            className="flex-1 px-2.5 py-1 rounded-lg bg-[#0b1b22] border border-white/15 text-white text-[10px] font-mono"
          />
          <button
            type="button"
            onClick={addCustomPermission}
            className="px-3 py-1 rounded-lg bg-[#00f5d4] text-[#041014] font-extrabold text-[10px] cursor-pointer"
          >
            + Add
          </button>
        </div>
      </div>

      {/* Code Preview & Actions */}
      <div className="rounded-xl border border-white/15 bg-[#040c0f] p-3 space-y-2">
        <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
          <span>AndroidManifest.xml Preview</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleCopy}
              className="px-2.5 py-1 rounded-md bg-[#00f5d4] text-[#041014] font-black text-[10px] cursor-pointer"
            >
              📋 Copy
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="px-2.5 py-1 rounded-md bg-[#00ff88] text-[#041014] font-black text-[10px] cursor-pointer"
            >
              💾 Save XML
            </button>
          </div>
        </div>
        <pre className="max-h-48 overflow-y-auto p-2.5 rounded-lg bg-black/60 text-[9.5px] font-mono text-emerald-400 select-all leading-tight">
          {generatedXml}
        </pre>
      </div>
    </div>
  );
};

/* =====================================================================
   TOOL 2: SMALI BYTECODE STRING OBFUSCATOR & CRYPTO VAULT
   ===================================================================== */
export const SmaliObfuscatorScreen: React.FC<CommonToolProps> = ({
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [inputText, setInputText] = useState(
    'https://api.nsmods.vip/antiban/key'
  );
  const [cipherMode, setCipherMode] = useState<
    'XOR' | 'RC4' | 'BASE64_HEX' | 'UNICODE'
  >('XOR');
  const [xorKey, setXorKey] = useState<number>(0x5a);
  const [rc4Key, setRc4Key] = useState<string>('NsSecretKey99');
  const [className, setClassName] = useState<string>('com/nsmods/NsDecryptor');

  // Encryption Implementations
  const encryptedResult = useMemo(() => {
    if (!inputText) return '';
    try {
      if (cipherMode === 'XOR') {
        const out: number[] = [];
        for (let i = 0; i < inputText.length; i++) {
          out.push(inputText.charCodeAt(i) ^ (xorKey & 0xff));
        }
        return out.map((b) => ('0' + b.toString(16)).slice(-2)).join('');
      } else if (cipherMode === 'BASE64_HEX') {
        const b64 = btoa(encodeURIComponent(inputText));
        let hex = '';
        for (let i = 0; i < b64.length; i++) {
          hex += ('0' + b64.charCodeAt(i).toString(16)).slice(-2);
        }
        return hex;
      } else if (cipherMode === 'UNICODE') {
        let u = '';
        for (let i = 0; i < inputText.length; i++) {
          u += '\\u' + ('0000' + inputText.charCodeAt(i).toString(16)).slice(-4);
        }
        return u;
      } else if (cipherMode === 'RC4') {
        // Simple standard RC4 keystream
        const s = Array.from({ length: 256 }, (_, i) => i);
        let j = 0;
        for (let i = 0; i < 256; i++) {
          j = (j + s[i] + rc4Key.charCodeAt(i % rc4Key.length)) % 256;
          [s[i], s[j]] = [s[j], s[i]];
        }
        let i = 0;
        j = 0;
        let hexOut = '';
        for (let c = 0; c < inputText.length; c++) {
          i = (i + 1) % 256;
          j = (j + s[i]) % 256;
          [s[i], s[j]] = [s[j], s[i]];
          const k = s[(s[i] + s[j]) % 256];
          const cipherChar = inputText.charCodeAt(c) ^ k;
          hexOut += ('0' + cipherChar.toString(16)).slice(-2);
        }
        return hexOut;
      }
    } catch {
      return 'Error encrypting';
    }
    return '';
  }, [inputText, cipherMode, xorKey, rc4Key]);

  // Verified in-browser live decryption to confirm runtime correctness
  const verifiedDecryptedText = useMemo(() => {
    if (!encryptedResult) return '';
    try {
      if (cipherMode === 'XOR') {
        let str = '';
        for (let i = 0; i < encryptedResult.length; i += 2) {
          const byte = parseInt(encryptedResult.slice(i, i + 2), 16);
          str += String.fromCharCode(byte ^ (xorKey & 0xff));
        }
        return str;
      } else if (cipherMode === 'BASE64_HEX') {
        let b64 = '';
        for (let i = 0; i < encryptedResult.length; i += 2) {
          b64 += String.fromCharCode(
            parseInt(encryptedResult.slice(i, i + 2), 16)
          );
        }
        return decodeURIComponent(atob(b64));
      } else if (cipherMode === 'UNICODE') {
        return JSON.parse(`"${encryptedResult}"`);
      } else if (cipherMode === 'RC4') {
        const s = Array.from({ length: 256 }, (_, i) => i);
        let j = 0;
        for (let i = 0; i < 256; i++) {
          j = (j + s[i] + rc4Key.charCodeAt(i % rc4Key.length)) % 256;
          [s[i], s[j]] = [s[j], s[i]];
        }
        let i = 0;
        j = 0;
        let out = '';
        for (let c = 0; c < encryptedResult.length; c += 2) {
          i = (i + 1) % 256;
          j = (j + s[i]) % 256;
          [s[i], s[j]] = [s[j], s[i]];
          const k = s[(s[i] + s[j]) % 256];
          const cipherByte = parseInt(encryptedResult.slice(c, c + 2), 16);
          out += String.fromCharCode(cipherByte ^ k);
        }
        return out;
      }
    } catch {
      return 'Decryption error';
    }
    return '';
  }, [encryptedResult, cipherMode, xorKey, rc4Key]);

  // Smali Method Snippet to inject at call site
  const smaliCallSnippet = useMemo(() => {
    if (cipherMode === 'XOR') {
      return `# --- Injected by @Nsmods String Obfuscator ---
const-string v0, "${encryptedResult}"
const/16 v1, 0x${xorKey.toString(16)}
invoke-static {v0, v1}, L${className};->xorDecrypt(Ljava/lang/String;I)Ljava/lang/String;
move-result-object v0
# v0 now holds: "${inputText}"`;
    } else if (cipherMode === 'RC4') {
      return `# --- Injected by @Nsmods String Obfuscator ---
const-string v0, "${encryptedResult}"
const-string v1, "${rc4Key}"
invoke-static {v0, v1}, L${className};->rc4Decrypt(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
move-result-object v0
# v0 now holds: "${inputText}"`;
    } else {
      return `# --- Injected by @Nsmods String Obfuscator ---
const-string v0, "${encryptedResult}"
invoke-static {v0}, L${className};->decrypt(Ljava/lang/String;)Ljava/lang/String;
move-result-object v0
# v0 now holds: "${inputText}"`;
    }
  }, [encryptedResult, cipherMode, xorKey, rc4Key, className, inputText]);

  // Full Smali Utility Class (`NsDecryptor.smali`)
  const fullSmaliClassCode = useMemo(() => {
    return `.class public L${className};
.super Ljava/lang/Object;

# Smali String Decryptor Utility - Built by @Nsmods
.method public constructor <init>()V
    .registers 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    return-void
.end method

# Method: xorDecrypt(hexCipher, key)
.method public static xorDecrypt(Ljava/lang/String;I)Ljava/lang/String;
    .registers 7
    .param p0, "hex"    # Ljava/lang/String;
    .param p1, "key"    # I

    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    :goto_6
    invoke-virtual {p0}, Ljava/lang/String;->length()I
    move-result v2
    if-ge v1, v2, :cond_24

    add-int/lit8 v2, v1, 0x2
    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;
    move-result-object v2
    const/16 v3, 0x10
    invoke-static {v2, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I
    move-result v2
    xor-int/2addr v2, p1
    int-to-char v2, v2
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x2
    goto :goto_6

    :cond_24
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method
`;
  }, [className]);

  const handleCopySnippet = () => {
    navigator.clipboard.writeText(smaliCallSnippet);
    onShowToast('Copied!', 'Smali call snippet copied to clipboard.');
    onSaveHistory('Smali Snippet', smaliCallSnippet);
  };

  const handleDownloadSmaliClass = () => {
    const blob = new Blob([fullSmaliClassCode], { type: 'text/plain' });
    triggerBlobDownload(blob, 'NsDecryptor.smali');
    onShowToast('Downloaded!', 'NsDecryptor.smali saved.');
  };

  return (
    <div className="flex flex-col space-y-3.5 pb-6">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-[#00f5d4]/30 pb-2.5">
        <button
          type="button"
          onClick={onBack}
          className="px-2.5 py-1 rounded-lg border border-[#00f5d4]/40 bg-[#0a181c] text-[#00f5d4] text-xs font-bold flex items-center gap-1 cursor-pointer"
        >
          <span>‹</span> <span>Back</span>
        </button>
        <h2 className="text-sm font-extrabold text-[#00f5d4] flex items-center gap-1.5">
          <span>🔐</span>
          <AnimatedText
            text="Smali String Obfuscator"
            config={typingConfig}
          />
        </h2>
        <span className="px-2 py-0.5 rounded-full bg-[#00ff88]/20 text-[#00ff88] text-[9px] font-black">
          SECURITY
        </span>
      </div>

      {/* Input Plaintext Card */}
      <div className="rounded-xl border border-[#00f5d4]/30 bg-[#071318] p-3 space-y-2">
        <label className="text-[11px] font-extrabold text-[#00f5d4] block">
          ✏️ Input Plaintext String (URL, Secret Key, Token, Package)
        </label>
        <textarea
          rows={2}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Enter sensitive string to obfuscate in Smali..."
          className="w-full p-2.5 rounded-lg bg-[#0b1b22] border border-white/15 text-white font-mono text-xs outline-none focus:border-[#00f5d4]"
        />

        {/* Cipher Selector */}
        <div className="grid grid-cols-4 gap-1.5 pt-1">
          {(['XOR', 'RC4', 'BASE64_HEX', 'UNICODE'] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setCipherMode(mode)}
              className={`py-1.5 rounded-lg text-[9.5px] font-bold transition-all cursor-pointer ${
                cipherMode === mode
                  ? 'bg-[#00f5d4] text-[#041014] shadow'
                  : 'bg-[#0a1820] text-slate-300 border border-white/10 hover:border-white/30'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>

        {/* Key Settings */}
        {cipherMode === 'XOR' && (
          <div className="flex items-center justify-between text-[10px] pt-1">
            <span className="text-slate-300">XOR Byte Key (0 - 255):</span>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={1}
                max={255}
                value={xorKey}
                onChange={(e) => setXorKey(Number(e.target.value))}
                className="w-24 accent-[#00f5d4]"
              />
              <span className="font-mono text-[#00f5d4] font-bold">
                0x{xorKey.toString(16).toUpperCase()} ({xorKey})
              </span>
            </div>
          </div>
        )}

        {cipherMode === 'RC4' && (
          <div className="flex items-center justify-between text-[10px] pt-1">
            <span className="text-slate-300">RC4 Secret Passphrase:</span>
            <input
              type="text"
              value={rc4Key}
              onChange={(e) => setRc4Key(e.target.value)}
              className="w-36 px-2 py-0.5 rounded bg-[#0b1b22] border border-white/20 text-[#00f5d4] font-mono text-[10px]"
            />
          </div>
        )}
      </div>

      {/* Encrypted Result & Live Verifier Card */}
      <div className="rounded-xl border border-[#00ff88]/40 bg-[#061c16] p-3 space-y-2">
        <div className="flex items-center justify-between text-[11px] font-extrabold text-[#00ff88]">
          <span>🔒 Obfuscated Hex / Cipher Output</span>
          <span className="text-[9.5px] font-mono text-emerald-300">
            {encryptedResult.length} chars
          </span>
        </div>
        <div className="p-2 rounded-lg bg-black/70 font-mono text-[11px] text-[#00ff88] break-all select-all border border-[#00ff88]/30">
          {encryptedResult || '(empty)'}
        </div>

        {/* Live Verifier */}
        <div className="flex items-center justify-between text-[10px] pt-1 text-slate-300 border-t border-white/10">
          <span>⚡ Live Runtime Verify:</span>
          <span
            className={`font-mono font-bold truncate max-w-[200px] ${
              verifiedDecryptedText === inputText
                ? 'text-[#00ff88]'
                : 'text-rose-400'
            }`}
          >
            {verifiedDecryptedText === inputText
              ? `✓ Match: "${verifiedDecryptedText}"`
              : 'Mismatch!'}
          </span>
        </div>
      </div>

      {/* Smali Injection Snippet Card */}
      <div className="rounded-xl border border-white/15 bg-[#040c0f] p-3 space-y-2">
        <div className="flex items-center justify-between text-[11px] font-bold text-slate-200">
          <span>⚡ Smali Injection Snippet (Paste in Method)</span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleCopySnippet}
              className="px-2.5 py-1 rounded-md bg-[#00f5d4] text-[#041014] font-black text-[10px] cursor-pointer"
            >
              📋 Copy Smali
            </button>
            <button
              type="button"
              onClick={handleDownloadSmaliClass}
              className="px-2.5 py-1 rounded-md bg-[#00ff88] text-[#041014] font-black text-[10px] cursor-pointer"
            >
              💾 Save .smali
            </button>
          </div>
        </div>
        <pre className="max-h-36 overflow-y-auto p-2.5 rounded-lg bg-black/60 text-[9.5px] font-mono text-cyan-300 select-all leading-tight">
          {smaliCallSnippet}
        </pre>
      </div>
    </div>
  );
};

/* =====================================================================
   MODAL: WEB TO APK CONVERSION GUIDE & BUILDER (বাংলায় সম্পূর্ণ নিয়ম)
   ===================================================================== */
interface WebToApkModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  onPromptInstall: () => void;
  onShowToast: (title: string, subtitle: string) => void;
}

export const WebToApkGuideModal: React.FC<WebToApkModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  onPromptInstall,
  onShowToast,
}) => {
  const [downloadingZip, setDownloadingZip] = useState(false);

  const handleDownloadAndroidStudioProject = async () => {
    setDownloadingZip(true);
    try {
      const currentUrl = window.location.href;
      const zip = new JSZip();

      // AndroidManifest.xml
      zip.file(
        'app/src/main/AndroidManifest.xml',
        `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.nsmods.webapp">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <application
        android:allowBackup="true"
        android:label="@Nsmods"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true"
        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
      );

      // MainActivity.java
      zip.file(
        'app/src/main/java/com/nsmods/webapp/MainActivity.java',
        `package com.nsmods.webapp;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("${currentUrl}");
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}`
      );

      // README instructions
      zip.file(
        'README_BANGLA_HOW_TO_BUILD_APK.txt',
        `============================================================
@Nsmods Web to APK — সম্পূর্ণ বাংলা নির্দেশিকা
============================================================

১. এই ফোল্ডারটি Android Studio-তে Open Project করুন।
২. Build মেনু থেকে "Build Bundle(s) / APK(s)" -> "Build APK(s)" চাপুন।
৩. ৩ সেকেন্ডে আপনার Nsmods অ্যাপের নিজস্ব আসল .APK ফাইল রেডি হয়ে যাবে!
৪. অথবা Website 2 APK Builder বা PWABuilder-এ আপনার ওয়েব অ্যাপের লিংক (${currentUrl}) দিন।
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      triggerBlobDownload(blob, 'Nsmods_Web_To_APK_Project.zip');
      onShowToast(
        'ZIP Downloaded!',
        'Nsmods_Web_To_APK_Project.zip ডাউনলোড হয়েছে।'
      );
    } catch (err: any) {
      onShowToast('Error', err?.message || 'Failed to create ZIP.');
    } finally {
      setDownloadingZip(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 overflow-y-auto">
      <div className="relative w-full max-w-[430px] max-h-[92vh] overflow-y-auto rounded-2xl border-2 border-[#00f5d4] bg-[#071318] p-4 text-white shadow-[0_0_35px_rgba(0,245,212,0.35)] space-y-3.5">
        <div className="flex items-center justify-between border-b border-[#00f5d4]/30 pb-2.5">
          <h2 className="text-sm font-extrabold text-[#00f5d4] flex items-center gap-1.5">
            <span>📦</span>
            <span>@Nsmods Web App কে APK বানানোর নিয়ম</span>
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-lg border border-white/20 bg-white/5 hover:bg-white/15 flex items-center justify-center text-xs font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* 1-Click Install Button */}
        <div className="rounded-xl border border-[#00ff88]/50 bg-[#0a231c] p-3 space-y-2">
          <div className="text-xs font-extrabold text-[#00ff88] flex items-center justify-between">
            <span>⚡ পদ্ধতি ১: ১ ক্লিকে সরাসরি ফোনে আসল অ্যাপ ইনস্টল</span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#00ff88]/20 font-black">
              সবচেয়ে সহজ
            </span>
          </div>
          <p className="text-[11px] text-slate-200 leading-snug">
            কোনো APK ফাইল ডাউনলোড বা সাইন ছাড়াই আপনার মোবাইলের হোম স্ক্রিনে সরাসরি
            আসল অ্যাপ (PWA Standalone) হিসেবে ইনস্টল হয়ে যাবে:
          </p>
          <button
            type="button"
            onClick={() => {
              if (isInstallable) {
                onPromptInstall();
              } else {
                onShowToast(
                  'Chrome Menu খুলুন',
                  'ব্রাউজারের ৩-ডট (⋮) মেনু থেকে "Install app" বা "Add to Home screen" চাপুন।'
                );
              }
            }}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00f5d4] to-[#00ff88] text-[#041014] font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer hover:brightness-110"
          >
            <span>📲</span>
            <span>সরাসরি ফোনে Install করুন (Add to Home screen)</span>
          </button>
        </div>

        {/* Method 2: Website 2 APK Builder */}
        <div className="rounded-xl border border-[#3ea6ff]/40 bg-[#081824] p-3 space-y-2 text-[11px] text-slate-200">
          <div className="text-xs font-extrabold text-[#3ea6ff]">
            🌐 পদ্ধতি ২: Website 2 APK Builder / Web2Apk দিয়ে .apk তৈরি
          </div>
          <p>
            যেকোনো <b>Web to APK Converter</b> (যেমন Web2Apk, Website 2 APK
            Builder, AppsGeyser) সফটওয়্যারে আপনার অ্যাপের লিংক পেস্ট করলেই
            সরাসরি স্ট্যান্ডঅ্যালোন <b>.apk</b> ফাইল তৈরি হয়ে যাবে:
          </p>
          <div className="p-2 rounded bg-black/60 font-mono text-[10px] text-[#3ea6ff] break-all border border-[#3ea6ff]/30 select-all">
            {window.location.origin}
          </div>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(window.location.origin);
              onShowToast('Link Copied!', 'App URL copied to clipboard.');
            }}
            className="px-3 py-1 rounded-lg bg-[#3ea6ff] text-[#041014] font-extrabold text-[10px] cursor-pointer"
          >
            📋 কপি অ্যাপ লিংক
          </button>
        </div>

        {/* Method 3: Download Android Studio WebView Project */}
        <div className="rounded-xl border border-[#ffd166]/40 bg-[#1f1a09] p-3 space-y-2 text-[11px] text-slate-200">
          <div className="text-xs font-extrabold text-[#ffd166]">
            🛠️ পদ্ধতি ৩: Android Studio WebView Project (Developer Ready)
          </div>
          <p>
            আমরা সম্পূর্ণ রেডিমেড Android Studio সোর্স কোড ZIP বানিয়ে দিচ্ছি
            (MainActivity + Manifest + Offline Support):
          </p>
          <button
            type="button"
            disabled={downloadingZip}
            onClick={handleDownloadAndroidStudioProject}
            className="w-full py-2 rounded-xl bg-[#ffd166] text-[#041014] font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer hover:brightness-110"
          >
            <span>💾</span>
            <span>
              {downloadingZip
                ? 'তৈরি হচ্ছে...'
                : 'Download Android Studio APK Project ZIP'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
