import React, { useState } from 'react';
import { TypingConfig } from '../types/appTypes';
import {
  JAVA_SAMPLE_CODE,
  KOTLIN_SAMPLE_CODE,
  convertCodeAst,
  triggerBlobDownload,
} from '../utils/packageGenerator';
import { AnimatedText } from './AnimatedText';
import { ConversionShaderView } from './ConversionShaderView';

interface Props {
  activeShaderId: number;
  typingConfig: TypingConfig;
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onOpenHistory: () => void;
  onSaveHistory: (title: string, code: string) => void;
  onShowToast: (title: string, subtitle: string) => void;
}

export const JavaKotlinConverterScreen: React.FC<Props> = ({
  activeShaderId,
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onOpenHistory,
  onSaveHistory,
  onShowToast,
}) => {
  const [direction, setDirection] = useState<'java_to_kotlin' | 'kotlin_to_java'>('java_to_kotlin');
  const [compilerMode, setCompilerMode] = useState<'FAST' | 'BALANCED' | 'STRICT'>('BALANCED');
  const [sourceCode, setSourceCode] = useState(JAVA_SAMPLE_CODE);
  const [convertedCode, setConvertedCode] = useState('');
  const [showLineNumbers, setShowLineNumbers] = useState(true);
  const [wordWrap, setWordWrap] = useState(true);

  // Conversion animation state
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [viewMode, setViewMode] = useState<'editor' | 'converting' | 'result'>('editor');

  const handleSwap = () => {
    const nextDir =
      direction === 'java_to_kotlin' ? 'kotlin_to_java' : 'java_to_kotlin';
    setDirection(nextDir);
    if (viewMode === 'result' && convertedCode) {
      setSourceCode(convertedCode);
      setViewMode('editor');
    } else {
      setSourceCode(
        nextDir === 'java_to_kotlin' ? JAVA_SAMPLE_CODE : KOTLIN_SAMPLE_CODE
      );
    }
  };

  const handleStartConversion = () => {
    if (!sourceCode.trim()) {
      onShowToast('Empty Code', 'Please enter or load sample code first.');
      return;
    }

    setIsConverting(true);
    setViewMode('converting');
    setProgress(4);

    const speedStep =
      compilerMode === 'FAST' ? 14 : compilerMode === 'BALANCED' ? 9 : 6;

    let current = 4;
    const timer = window.setInterval(() => {
      current += speedStep + Math.floor(Math.random() * 6);
      if (current >= 100) {
        current = 100;
        setProgress(100);
        clearInterval(timer);
        const result = convertCodeAst(sourceCode, direction);
        setConvertedCode(result);
        setTimeout(() => {
          setIsConverting(false);
          setViewMode('result');
        }, 480);
      } else {
        setProgress(current);
      }
    }, 95);
  };

  const activeText = viewMode === 'result' ? convertedCode : sourceCode;
  const lines = activeText.split('\n');
  const fileName =
    direction === 'java_to_kotlin'
      ? viewMode === 'result'
        ? 'MyActivity.kt'
        : 'MyActivity.java'
      : viewMode === 'result'
      ? 'MyActivity.java'
      : 'MyActivity.kt';

  return (
    <div className="flex flex-col pb-6">
      {/* Top Bar matching Video 01:33 */}
      <div className="flex items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white flex items-center gap-1 ${microClass}`}
        >
          <span>←</span>
          <AnimatedText text="Back" config={typingConfig} />
        </button>

        <div className="text-center min-w-0">
          <h1 className="text-sm font-extrabold text-white truncate">
            <AnimatedText text="Java ↔ Kotlin Converter" config={typingConfig} />
          </h1>
          <div className="text-[10px] text-slate-400 truncate">
            AST Parser • Type &amp; Nullability Verifier
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenHistory}
          className={`px-3 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white flex items-center gap-1 ${microClass}`}
        >
          <span className="text-[#00f5d4]">❐</span>
          <span>Histo...</span>
        </button>
      </div>

      {/* Direction Selector Row */}
      <div className="grid grid-cols-3 gap-2 mb-2">
        <button
          type="button"
          onClick={() => {
            setDirection('java_to_kotlin');
            setSourceCode(JAVA_SAMPLE_CODE);
            setViewMode('editor');
          }}
          className={`py-2 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 ${microClass} ${
            direction === 'java_to_kotlin'
              ? 'border-[#00ff88] bg-[#0b2e26] text-[#00ff88]'
              : 'border-[#00f5d4]/40 bg-[#0a161a] text-slate-200'
          }`}
        >
          {direction === 'java_to_kotlin' && <span>✓</span>}
          <span>Java → Kotlin</span>
        </button>

        <button
          type="button"
          onClick={handleSwap}
          className={`py-2 px-2 rounded-xl border border-[#00f5d4]/60 bg-[#0a161a] text-xs font-bold text-white flex items-center justify-center gap-1 ${microClass}`}
        >
          <span className="text-[#00f5d4]">⇄</span>
          <span>Swap</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setDirection('kotlin_to_java');
            setSourceCode(KOTLIN_SAMPLE_CODE);
            setViewMode('editor');
          }}
          className={`py-2 px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1 ${microClass} ${
            direction === 'kotlin_to_java'
              ? 'border-[#00ff88] bg-[#0b2e26] text-[#00ff88]'
              : 'border-[#00f5d4]/40 bg-[#0a161a] text-slate-200'
          }`}
        >
          {direction === 'kotlin_to_java' && <span>✓</span>}
          <span>Kotlin → Java</span>
        </button>
      </div>

      {/* Mode Row: FAST | BALANCED | STRICT | + Sample */}
      <div className="grid grid-cols-4 gap-2 mb-2.5">
        {(['FAST', 'BALANCED', 'STRICT'] as const).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setCompilerMode(m)}
            className={`py-2 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1 ${microClass} ${
              compilerMode === m
                ? 'border-[#00f5d4] bg-[#0d262e] text-[#00f5d4]'
                : 'border-[#00f5d4]/40 bg-[#0a161a] text-slate-300'
            }`}
          >
            {compilerMode === m && <span>✓</span>}
            <span>{m}</span>
          </button>
        ))}

        <button
          type="button"
          onClick={() => {
            setSourceCode(
              direction === 'java_to_kotlin'
                ? JAVA_SAMPLE_CODE
                : KOTLIN_SAMPLE_CODE
            );
            setViewMode('editor');
            onShowToast('Sample Loaded', `Loaded ${fileName} sample template.`);
          }}
          className={`py-2 rounded-xl border border-[#00f5d4]/60 bg-[#0a161a] text-[11px] font-bold text-[#00ff88] flex items-center justify-center gap-1 ${microClass}`}
        >
          <span>+</span>
          <span>Sample</span>
        </button>
      </div>

      {/* LIVE CONVERSION SHADER VIEW (Video 01:35 & 01:38) */}
      {viewMode === 'converting' && (
        <div className="my-2 space-y-3">
          <div className="rounded-xl border border-[#00f5d4]/60 bg-[#09181d] py-2.5 px-4 text-center">
            <div className="text-[11px] font-mono font-bold text-[#ff2a85]">
              STEP {Math.min(6, Math.max(1, Math.ceil((progress / 100) * 6)))} OF 6
            </div>
            <div className="text-sm font-bold text-white mt-0.5">
              {progress >= 100
                ? 'Conversion Complete'
                : 'Parsing Code Structure...'}
            </div>
          </div>

          <ConversionShaderView
            shaderId={activeShaderId}
            sourceLabel={direction === 'java_to_kotlin' ? 'JAVA' : 'KOTLIN'}
            targetLabel={direction === 'java_to_kotlin' ? 'KOTLIN' : 'JAVA'}
            progress={progress}
          />

          <div className="text-center text-[11px] font-mono text-slate-400">
            AST Parser • Nullable Type Checker • Auto-Fix Verifier
          </div>
        </div>
      )}

      {/* EDITOR OR RESULT VIEW */}
      {viewMode !== 'converting' && (
        <>
          {viewMode === 'editor' ? (
            <>
              {/* Toolbar Row 1: Import | Paste | Copy | Clear */}
              <div className="grid grid-cols-4 gap-2 mb-2">
                <button
                  type="button"
                  onClick={() => {
                    setSourceCode(
                      direction === 'java_to_kotlin'
                        ? JAVA_SAMPLE_CODE
                        : KOTLIN_SAMPLE_CODE
                    );
                    onShowToast('File Imported', `Imported ${fileName}`);
                  }}
                  className={`py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0a161a] text-[11px] font-bold text-white ${microClass}`}
                >
                  📥 Import
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      const t = await navigator.clipboard.readText();
                      if (t) setSourceCode(t);
                    } catch {
                      onShowToast('Paste Ready', 'Use keyboard paste in editor.');
                    }
                  }}
                  className={`py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0a161a] text-[11px] font-bold text-white ${microClass}`}
                >
                  📋 Paste
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(sourceCode);
                    onShowToast('Copied', 'Source code copied to clipboard.');
                  }}
                  className={`py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0a161a] text-[11px] font-bold text-white ${microClass}`}
                >
                  ❐ Copy
                </button>
                <button
                  type="button"
                  onClick={() => setSourceCode('')}
                  className={`py-2 rounded-xl border border-[#ff2a85]/50 bg-[#1a0d14] text-[11px] font-bold text-[#ff2a85] ${microClass}`}
                >
                  ✕ Clear
                </button>
              </div>

              {/* Toolbar Row 2: Undo | Redo | Find | Line# | Line | All */}
              <div className="grid grid-cols-6 gap-1.5 mb-2">
                <button
                  type="button"
                  onClick={() =>
                    setSourceCode(
                      direction === 'java_to_kotlin'
                        ? JAVA_SAMPLE_CODE
                        : KOTLIN_SAMPLE_CODE
                    )
                  }
                  className="py-1.5 rounded-lg border border-[#00f5d4]/40 bg-[#0a161a] text-[10px] font-bold text-slate-200"
                >
                  ↶ Undo
                </button>
                <button
                  type="button"
                  onClick={() => {}}
                  className="py-1.5 rounded-lg border border-[#00f5d4]/40 bg-[#0a161a] text-[10px] font-bold text-slate-200"
                >
                  ↷ Redo
                </button>
                <button
                  type="button"
                  onClick={() =>
                    onShowToast('AST Search', `${lines.length} lines indexed.`)
                  }
                  className="py-1.5 rounded-lg border border-[#00f5d4]/40 bg-[#0a161a] text-[10px] font-bold text-slate-200"
                >
                  🔍 Find
                </button>
                <button
                  type="button"
                  onClick={() => setShowLineNumbers((v) => !v)}
                  className="py-1.5 rounded-lg border border-[#00f5d4]/40 bg-[#0a161a] text-[10px] font-bold text-[#00f5d4]"
                >
                  ↕ Line#
                </button>
                <button
                  type="button"
                  onClick={() => setWordWrap((w) => !w)}
                  className="py-1.5 rounded-lg border border-[#00f5d4]/40 bg-[#0a161a] text-[10px] font-bold text-slate-200"
                >
                  ⇄ Line
                </button>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(sourceCode);
                    onShowToast('Selected All', 'All lines copied.');
                  }}
                  className="py-1.5 rounded-lg border border-[#00f5d4]/40 bg-[#0a161a] text-[10px] font-bold text-slate-200"
                >
                  ✓ All
                </button>
              </div>
            </>
          ) : (
            /* Result Banner matching Video 01:36 */
            <div className="mb-2.5 space-y-2">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-[#00ff88] flex items-center gap-1.5">
                  <span>✓</span>
                  <span>Conversion Complete</span>
                </div>
                <button
                  type="button"
                  onClick={() => setViewMode('editor')}
                  className="px-3 py-1.5 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white"
                >
                  ← Source
                </button>
              </div>

              <div className="rounded-xl border border-[#00f5d4]/50 bg-[#09161a] p-2.5">
                <div className="text-xs font-bold text-white">
                  Source: {direction === 'java_to_kotlin' ? 'Java' : 'Kotlin'} →
                  Converted: {direction === 'java_to_kotlin' ? 'Kotlin' : 'Java'}{' '}
                  • <span className="text-[#00ff88]">✓ Validated</span>
                </div>
                <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                  {sourceCode.split('\n').length} lines processed •{' '}
                  {lines.length} lines generated • 0 warnings • 381 ms
                </div>
              </div>
            </div>
          )}

          {/* Code Editor / Viewer Box */}
          <div
            className={`rounded-2xl border-2 bg-[#060f12] overflow-hidden mb-3 ${glowClass}`}
          >
            <div className="flex items-center justify-between px-3 py-2 bg-[#0a181d] border-b border-[#00f5d4]/30 text-[11px] font-mono">
              <span className="text-slate-300 font-semibold">
                File: <span className="text-white">{fileName}</span>
              </span>
              <span className="text-slate-400">
                Chars: {activeText.length.toLocaleString()} &nbsp; Lines:{' '}
                {lines.length}
              </span>
            </div>

            {viewMode === 'editor' ? (
              <div className="relative flex max-h-[340px] overflow-y-auto">
                {showLineNumbers && (
                  <div className="select-none py-3 px-2 text-right font-mono text-[11px] leading-5 text-slate-500 bg-[#050c0f] border-r border-[#00f5d4]/20">
                    {lines.map((_, i) => (
                      <div key={i}>{i + 1}</div>
                    ))}
                  </div>
                )}
                <textarea
                  value={sourceCode}
                  onChange={(e) => setSourceCode(e.target.value)}
                  rows={16}
                  className={`flex-1 bg-transparent p-3 font-mono text-xs leading-5 text-[#98f5e1] focus:outline-none ${
                    wordWrap ? 'whitespace-pre-wrap' : 'whitespace-pre'
                  }`}
                />
              </div>
            ) : (
              <div className="flex max-h-[320px] overflow-y-auto p-2 font-mono text-xs leading-5">
                {showLineNumbers && (
                  <div className="select-none pr-2.5 text-right text-slate-500 border-r border-[#00f5d4]/20 mr-2.5">
                    {lines.map((_, i) => (
                      <div key={i}>{i + 1}</div>
                    ))}
                  </div>
                )}
                <pre className="flex-1 text-[#00f5d4] overflow-x-auto">
                  {convertedCode}
                </pre>
              </div>
            )}
          </div>

          {/* Bottom CTA or Result Actions */}
          {viewMode === 'editor' ? (
            <button
              type="button"
              onClick={handleStartConversion}
              disabled={isConverting}
              className={`w-full py-3.5 rounded-2xl border-2 border-[#00f5d4] bg-gradient-to-r from-[#0d2b33] via-[#103842] to-[#0d2b33] text-sm font-extrabold text-white tracking-wider uppercase shadow-[0_0_20px_rgba(0,245,212,0.3)] flex items-center justify-center gap-2 ${microClass}`}
            >
              <span className="text-[#00ff88]">⚡</span>
              <AnimatedText text="CONVERT CODE" config={typingConfig} />
            </button>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(convertedCode);
                  onShowToast('Copied!', `Converted ${fileName} copied.`);
                }}
                className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
              >
                ❐ Copy
              </button>
              <button
                type="button"
                onClick={() => {
                  setSourceCode(convertedCode);
                  setViewMode('editor');
                }}
                className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
              >
                ✎ Edit
              </button>
              <button
                type="button"
                onClick={() => {
                  onSaveHistory(`Converted ${fileName}`, convertedCode);
                  onShowToast('Saved!', 'Added to conversion history.');
                }}
                className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
              >
                💾 Save
              </button>
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([convertedCode], { type: 'text/plain' });
                  triggerBlobDownload(blob, fileName);
                  onShowToast('Exported File', `Downloaded ${fileName}`);
                }}
                className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
              >
                📤 Export
              </button>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(convertedCode);
                  onShowToast('Share Ready', 'Code copied to clipboard.');
                }}
                className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
              >
                🔗 Share
              </button>
              <button
                type="button"
                onClick={onOpenHistory}
                className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
              >
                🕒 History
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};
