import React, { useEffect, useState } from 'react';
import { XML_PRESETS, XmlPresetItem } from '../data/fxCatalog';
import { DrawableLayer, HistoryEntry } from '../types/appTypes';

interface ColorPickerProps {
  isOpen: boolean;
  initialColor: string;
  onClose: () => void;
  onSelectColor: (hex: string) => void;
}

function parseHexToArgb(hex: string): { a: number; r: number; g: number; b: number } {
  const clean = hex.replace('#', '').trim();
  if (clean.length === 8) {
    return {
      a: parseInt(clean.slice(0, 2), 16) || 255,
      r: parseInt(clean.slice(2, 4), 16) || 0,
      g: parseInt(clean.slice(4, 6), 16) || 180,
      b: parseInt(clean.slice(6, 8), 16) || 255,
    };
  }
  if (clean.length === 6) {
    return {
      a: 255,
      r: parseInt(clean.slice(0, 2), 16) || 0,
      g: parseInt(clean.slice(2, 4), 16) || 180,
      b: parseInt(clean.slice(4, 6), 16) || 255,
    };
  }
  return { a: 255, r: 0, g: 245, b: 212 };
}

function toHexByte(n: number): string {
  return Math.max(0, Math.min(255, Math.round(n)))
    .toString(16)
    .padStart(2, '0')
    .toUpperCase();
}

const QUICK_SWATCHES = [
  '#00F5D4',
  '#FF007F',
  '#0055FF',
  '#00FFFF',
  '#00FF88',
  '#FFD166',
  '#9B5DE5',
  '#FF4800',
  '#FFFFFF',
  '#08161B',
];

export const ColorPickerModal: React.FC<ColorPickerProps> = ({
  isOpen,
  initialColor,
  onClose,
  onSelectColor,
}) => {
  const [argb, setArgb] = useState({ a: 255, r: 0, g: 135, b: 255 });

  useEffect(() => {
    if (isOpen) {
      setArgb(parseHexToArgb(initialColor === 'None' ? '#0085FF' : initialColor));
    }
  }, [isOpen, initialColor]);

  if (!isOpen) return null;

  const computedHex =
    argb.a < 255
      ? `#${toHexByte(argb.a)}${toHexByte(argb.r)}${toHexByte(argb.g)}${toHexByte(argb.b)}`
      : `#${toHexByte(argb.r)}${toHexByte(argb.g)}${toHexByte(argb.b)}`;

  const rgbaCss = `rgba(${argb.r}, ${argb.g}, ${argb.b}, ${(argb.a / 255).toFixed(2)})`;

  const channels: Array<{
    key: 'a' | 'r' | 'g' | 'b';
    label: string;
  }> = [
    { key: 'a', label: 'Alpha' },
    { key: 'r', label: 'Red' },
    { key: 'g', label: 'Green' },
    { key: 'b', label: 'Blue' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-5 shadow-[0_0_30px_rgba(0,245,212,0.28)]"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-center text-base font-bold text-white mb-3">
          Select Color
        </h3>

        {/* Circle Preview */}
        <div className="flex flex-col items-center justify-center mb-4">
          <div
            className="w-16 h-16 rounded-full border-2 border-white/60 shadow-lg mb-2"
            style={{ backgroundColor: rgbaCss }}
          />
          <span className="font-mono text-xs text-[#00f5d4] font-semibold">
            {computedHex}
          </span>
        </div>

        {/* ARGB Sliders with - and + buttons matching Video 02:41 */}
        <div className="space-y-3">
          {channels.map(({ key, label }) => (
            <div key={key}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium">{label}</span>
                <span className="font-mono font-bold text-white">
                  {argb[key]}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() =>
                    setArgb((prev) => ({
                      ...prev,
                      [key]: Math.max(0, prev[key] - 5),
                    }))
                  }
                  className="w-10 h-9 rounded-lg border border-[#00f5d4]/60 bg-[#0d1d22] text-white font-bold flex items-center justify-center active:scale-95"
                >
                  −
                </button>
                <input
                  type="range"
                  min={0}
                  max={255}
                  value={argb[key]}
                  onChange={(e) =>
                    setArgb((prev) => ({
                      ...prev,
                      [key]: Number(e.target.value),
                    }))
                  }
                  className="flex-1"
                />
                <button
                  type="button"
                  onClick={() =>
                    setArgb((prev) => ({
                      ...prev,
                      [key]: Math.min(255, prev[key] + 5),
                    }))
                  }
                  className="w-10 h-9 rounded-lg border border-[#00f5d4]/60 bg-[#0d1d22] text-white font-bold flex items-center justify-center active:scale-95"
                >
                  +
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Swatches */}
        <div className="mt-4 flex items-center justify-between gap-1.5">
          {QUICK_SWATCHES.map((sw) => (
            <button
              key={sw}
              type="button"
              onClick={() => setArgb(parseHexToArgb(sw))}
              className="w-6 h-6 rounded-full border border-white/40 transition-transform active:scale-90"
              style={{ backgroundColor: sw }}
              title={sw}
            />
          ))}
        </div>

        <button
          type="button"
          onClick={() => {
            onSelectColor(computedHex);
            onClose();
          }}
          className="mt-5 w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d2228] text-white font-bold text-sm tracking-wide hover:bg-[#123038] active:scale-[0.98] transition-all"
        >
          Set Color
        </button>
      </div>
    </div>
  );
};

interface StrokeModalProps {
  isOpen: boolean;
  layer: DrawableLayer;
  onClose: () => void;
  onSave: (updates: Partial<DrawableLayer>) => void;
}

export const CustomStrokeModal: React.FC<StrokeModalProps> = ({
  isOpen,
  layer,
  onClose,
  onSave,
}) => {
  const [strokeWidth, setStrokeWidth] = useState(layer.strokeWidth || 2);
  const [dashWidth, setDashWidth] = useState(layer.dashWidth || 0);
  const [dashGap, setDashGap] = useState(layer.dashGap || 0);

  useEffect(() => {
    if (isOpen) {
      setStrokeWidth(layer.strokeWidth || 2);
      setDashWidth(layer.dashWidth || 0);
      setDashGap(layer.dashGap || 0);
    }
  }, [isOpen, layer]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-center text-base font-bold text-white mb-4">
          Set Custom Stroke & Dash
        </h3>

        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Stroke Width (dp)</span>
              <span className="font-mono font-bold text-[#00f5d4]">
                {strokeWidth}dp
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={24}
              value={strokeWidth}
              onChange={(e) => setStrokeWidth(Number(e.target.value))}
              className="w-full"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Dash Width (dp, 0 = Solid)</span>
              <span className="font-mono font-bold text-[#00f5d4]">
                {dashWidth}dp
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={30}
              value={dashWidth}
              onChange={(e) => setDashWidth(Number(e.target.value))}
              className="w-full"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Dash Gap (dp)</span>
              <span className="font-mono font-bold text-[#00f5d4]">
                {dashGap}dp
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={30}
              value={dashGap}
              onChange={(e) => setDashGap(Number(e.target.value))}
              className="w-full"
            />
          </div>
        </div>

        <div className="mt-5 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 rounded-xl border border-slate-600 bg-[#0d181c] text-slate-300 text-xs font-bold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onSave({
                strokeWidth,
                dashWidth,
                dashGap,
                strokeColor:
                  layer.strokeColor === 'None' ? '#00F5D4' : layer.strokeColor,
              });
              onClose();
            }}
            className="py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d282e] text-[#00f5d4] text-xs font-bold"
          >
            Apply Stroke
          </button>
        </div>
      </div>
    </div>
  );
};

interface CornersModalProps {
  isOpen: boolean;
  layer: DrawableLayer;
  onClose: () => void;
  onSave: (updates: Partial<DrawableLayer>) => void;
}

export const CustomCornersModal: React.FC<CornersModalProps> = ({
  isOpen,
  layer,
  onClose,
  onSave,
}) => {
  const [uniform, setUniform] = useState(!layer.useIndividualCorners);
  const [radius, setRadius] = useState(layer.cornerRadius);
  const [tl, setTl] = useState(layer.topLeftRadius);
  const [tr, setTr] = useState(layer.topRightRadius);
  const [bl, setBl] = useState(layer.bottomLeftRadius);
  const [br, setBr] = useState(layer.bottomRightRadius);

  useEffect(() => {
    if (isOpen) {
      setUniform(!layer.useIndividualCorners);
      setRadius(layer.cornerRadius);
      setTl(layer.topLeftRadius);
      setTr(layer.topRightRadius);
      setBl(layer.bottomLeftRadius);
      setBr(layer.bottomRightRadius);
    }
  }, [isOpen, layer]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-center text-base font-bold text-white mb-3">
          Set Custom Corners (dp)
        </h3>

        <label className="flex items-center gap-2 text-xs text-slate-200 mb-4 cursor-pointer">
          <input
            type="checkbox"
            checked={!uniform}
            onChange={(e) => setUniform(!e.target.checked)}
            className="w-4 h-4 accent-[#00f5d4]"
          />
          <span>Use Individual 4-Corner Radii</span>
        </label>

        {uniform ? (
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">All Corners Radius</span>
              <span className="font-mono font-bold text-[#00f5d4]">
                {radius}dp
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={60}
              value={radius}
              onChange={(e) => setRadius(Number(e.target.value))}
              className="w-full"
            />
          </div>
        ) : (
          <div className="space-y-3">
            {[
              { label: 'Top-Left Radius', val: tl, set: setTl },
              { label: 'Top-Right Radius', val: tr, set: setTr },
              { label: 'Bottom-Left Radius', val: bl, set: setBl },
              { label: 'Bottom-Right Radius', val: br, set: setBr },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">{item.label}</span>
                  <span className="font-mono font-bold text-[#00f5d4]">
                    {item.val}dp
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={60}
                  value={item.val}
                  onChange={(e) => item.set(Number(e.target.value))}
                  className="w-full"
                />
              </div>
            ))}
          </div>
        )}

        <div className="mt-5 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 rounded-xl border border-slate-600 bg-[#0d181c] text-slate-300 text-xs font-bold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onSave({
                useIndividualCorners: !uniform,
                cornerRadius: radius,
                topLeftRadius: tl,
                topRightRadius: tr,
                bottomLeftRadius: bl,
                bottomRightRadius: br,
              });
              onClose();
            }}
            className="py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d282e] text-[#00f5d4] text-xs font-bold"
          >
            Apply Corners
          </button>
        </div>
      </div>
    </div>
  );
};

export const CustomInsetsModal: React.FC<CornersModalProps> = ({
  isOpen,
  layer,
  onClose,
  onSave,
}) => {
  const [left, setLeft] = useState(layer.insetLeft);
  const [top, setTop] = useState(layer.insetTop);
  const [right, setRight] = useState(layer.insetRight);
  const [bottom, setBottom] = useState(layer.insetBottom);

  useEffect(() => {
    if (isOpen) {
      setLeft(layer.insetLeft);
      setTop(layer.insetTop);
      setRight(layer.insetRight);
      setBottom(layer.insetBottom);
    }
  }, [isOpen, layer]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-center text-base font-bold text-white mb-3">
          Set Custom 3D Layer Insets (dp)
        </h3>
        <div className="space-y-3">
          {[
            { label: 'Left Inset', val: left, set: setLeft },
            { label: 'Top Inset', val: top, set: setTop },
            { label: 'Right Inset', val: right, set: setRight },
            { label: 'Bottom Inset (3D Depth)', val: bottom, set: setBottom },
          ].map((item) => (
            <div key={item.label}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">{item.label}</span>
                <span className="font-mono font-bold text-[#00f5d4]">
                  {item.val}dp
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={32}
                value={item.val}
                onChange={(e) => item.set(Number(e.target.value))}
                className="w-full"
              />
            </div>
          ))}
        </div>

        <div className="mt-5 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 rounded-xl border border-slate-600 bg-[#0d181c] text-slate-300 text-xs font-bold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onSave({
                insetLeft: left,
                insetTop: top,
                insetRight: right,
                insetBottom: bottom,
              });
              onClose();
            }}
            className="py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d282e] text-[#00f5d4] text-xs font-bold"
          >
            Apply Insets
          </button>
        </div>
      </div>
    </div>
  );
};

interface ImportXmlModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (xmlText: string) => void;
}

export const ImportXmlModal: React.FC<ImportXmlModalProps> = ({
  isOpen,
  onClose,
  onImport,
}) => {
  const [xmlText, setXmlText] = useState('');

  if (!isOpen) return null;

  const handlePasteClipboard = async () => {
    try {
      const clip = await navigator.clipboard.readText();
      if (clip) setXmlText(clip);
    } catch {
      // Fallback sample if clipboard read is blocked by iframe permissions
      setXmlText(
        `<?xml version="1.0" encoding="utf-8"?>\n<selector xmlns:android="http://schemas.android.com/apk/res/android">\n    <item>\n        <layer-list>\n            <item>\n                <shape android:shape="rectangle">\n                    <gradient android:type="linear" android:startColor="#00FFFF" android:endColor="#FF00AA" android:angle="270" />\n                    <stroke android:width="1dp" android:color="#00FFFF" />\n                    <corners android:radius="10dp" />\n                </shape>\n            </item>\n        </layer-list>\n    </item>\n</selector>`
      );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-5 shadow-[0_0_30px_rgba(0,245,212,0.25)]"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-center text-lg font-bold text-white">
          Import Android XML
        </h3>
        <p className="text-center text-xs text-slate-400 mt-1 mb-3">
          Paste your &lt;shape&gt;, &lt;gradient&gt;, &lt;layer-list&gt; or &lt;selector&gt; XML below:
        </p>

        <button
          type="button"
          onClick={handlePasteClipboard}
          className="w-full py-2.5 mb-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f24] text-white text-xs font-bold flex items-center justify-center gap-2 active:scale-[0.98]"
        >
          <span>❐</span>
          <span>PASTE FROM CLIPBOARD</span>
        </button>

        <textarea
          value={xmlText}
          onChange={(e) => setXmlText(e.target.value)}
          placeholder={`<shape xmlns:android=...>\n  <gradient ... />\n</shape>`}
          rows={6}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060e11] p-3 font-mono text-xs text-[#00f5d4] focus:outline-none focus:border-[#00f5d4]"
        />

        <div className="mt-4 grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 rounded-xl border border-slate-600 bg-[#0d181c] text-white text-xs font-bold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              if (xmlText.trim()) {
                onImport(xmlText);
                onClose();
              }
            }}
            className="py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d262c] text-[#00f5d4] text-xs font-bold"
          >
            REVIEW & OPEN
          </button>
        </div>
      </div>
    </div>
  );
};

interface PresetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPreset: (preset: XmlPresetItem) => void;
}

export const PresetsModal: React.FC<PresetsModalProps> = ({
  isOpen,
  onClose,
  onSelectPreset,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-4 max-h-[82vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#00f5d4]/30">
          <h3 className="text-base font-bold text-[#00f5d4]">
            ↻ Ready-Made XML Presets
          </h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-sm px-2 py-1"
          >
            ✕
          </button>
        </div>

        <div className="space-y-2.5 overflow-y-auto pr-1 flex-1">
          {XML_PRESETS.map((preset) => (
            <div
              key={preset.id}
              className="rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] p-3 flex items-center justify-between gap-3"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-white">
                    {preset.name}
                  </span>
                  <span className="text-[10px] font-mono text-[#00f5d4]">
                    · {preset.category}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {preset.description}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  onSelectPreset(preset);
                  onClose();
                }}
                className="px-3 py-2 rounded-lg border border-[#00f5d4] bg-[#0d282e] text-xs font-bold text-[#00f5d4] shrink-0 active:scale-95"
              >
                LOAD
              </button>
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4]/50 bg-[#0d1b20] text-white text-xs font-bold"
        >
          Close
        </button>
      </div>
    </div>
  );
};

interface HistoryModalProps {
  isOpen: boolean;
  history: HistoryEntry[];
  onClose: () => void;
  onCopy: (code: string) => void;
  onClearHistory: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  history,
  onClose,
  onCopy,
  onClearHistory,
}) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border-2 border-[#00f5d4] bg-[#091417] p-4 max-h-[82vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#00f5d4]/30">
          <h3 className="text-base font-bold text-[#00f5d4]">
            ❐ Saved Workspace History ({history.length})
          </h3>
          {history.length > 0 && (
            <button
              onClick={onClearHistory}
              className="text-xs text-[#ff2a85] font-semibold hover:underline"
            >
              Clear All
            </button>
          )}
        </div>

        <div className="space-y-2.5 overflow-y-auto pr-1 flex-1">
          {history.length === 0 ? (
            <div className="py-10 text-center text-xs text-slate-400">
              No saved items yet. Generate XML, convert Java/Kotlin code, or build a DEX package and tap &ldquo;Save History&rdquo;.
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                className="rounded-xl border border-[#00f5d4]/40 bg-[#0c1a1f] p-3"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-white">
                    {item.title}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    {item.timestamp}
                  </span>
                </div>
                <pre className="max-h-24 overflow-y-auto rounded bg-[#060d10] p-2 text-[10px] font-mono text-[#00f5d4] mb-2">
                  {item.code}
                </pre>
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => onCopy(item.code)}
                    className="px-3 py-1 rounded-lg border border-[#00f5d4] bg-[#0d282e] text-[11px] font-bold text-[#00f5d4]"
                  >
                    ❐ Copy Code
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-3 w-full py-2.5 rounded-xl border border-[#00f5d4]/50 bg-[#0d1b20] text-white text-xs font-bold"
        >
          Close
        </button>
      </div>
    </div>
  );
};
