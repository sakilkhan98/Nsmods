import React, { useState } from 'react';
import { createInitialDrawableConfig } from '../data/fxCatalog';
import {
  DrawableLayer,
  StateDrawableConfig,
  TypingConfig,
} from '../types/appTypes';
import {
  generateDrawableDexPackage,
  generateDrawableXml,
  generateLayoutDexPackage,
  isLayerConfigured,
  isStateConfigured,
  triggerBlobDownload,
} from '../utils/packageGenerator';
import { AnimatedText } from './AnimatedText';
import { ConversionShaderView } from './ConversionShaderView';
import {
  ColorPickerModal,
  CustomCornersModal,
  CustomInsetsModal,
  CustomStrokeModal,
} from './XmlCustomModals';

interface XmlCreatorProps {
  mode: '3d' | 'gradient' | 'normal' | 'ripple';
  config: StateDrawableConfig;
  setConfig: React.Dispatch<React.SetStateAction<StateDrawableConfig>>;
  xmlIndentation: '4 Spaces' | '2 Spaces' | 'Tabs';
  typingConfig: TypingConfig;
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onSaveHistory: (title: string, code: string) => void;
  onShowToast: (title: string, subtitle: string) => void;
}

function renderLayerCss(layer: DrawableLayer): React.CSSProperties {
  const hasStart = layer.startColor !== 'None';
  const hasEnd = layer.endColor !== 'None';
  const hasCenter = layer.useCenterColor && layer.centerColor !== 'None';

  let background = 'transparent';
  if (hasStart && hasEnd) {
    const stops = hasCenter
      ? `${layer.startColor}, ${layer.centerColor}, ${layer.endColor}`
      : `${layer.startColor}, ${layer.endColor}`;
    if (layer.gradientType === 'Radial') {
      background = `radial-gradient(circle, ${stops})`;
    } else if (layer.gradientType === 'Sweep') {
      background = `conic-gradient(from ${layer.angle}deg, ${stops})`;
    } else {
      background = `linear-gradient(${layer.angle}deg, ${stops})`;
    }
  } else if (hasStart || hasEnd) {
    background = hasStart ? layer.startColor : layer.endColor;
  }

  const borderRadius = layer.useIndividualCorners
    ? `${layer.topLeftRadius}px ${layer.topRightRadius}px ${layer.bottomRightRadius}px ${layer.bottomLeftRadius}px`
    : `${layer.cornerRadius}px`;

  const border =
    layer.strokeColor !== 'None' && layer.strokeWidth > 0
      ? `${Math.min(6, layer.strokeWidth)}px ${
          layer.dashWidth > 0 ? 'dashed' : 'solid'
        } ${layer.strokeColor}`
      : undefined;

  return {
    background,
    borderRadius,
    border,
  };
}

export const XmlDrawableCreatorScreen: React.FC<XmlCreatorProps> = ({
  mode,
  config,
  setConfig,
  xmlIndentation,
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [activeState, setActiveState] = useState<'normal' | 'checked' | 'pressed'>('normal');
  const [activeLayerIdx, setActiveLayerIdx] = useState(0);
  const [buttonLabelText, setButtonLabelText] = useState('CUSTOM STYLED BUTTON');

  const [colorPickerTarget, setColorPickerTarget] = useState<
    null | 'start' | 'center' | 'end' | 'stroke' | 'ripple'
  >(null);
  const [showStrokeModal, setShowStrokeModal] = useState(false);
  const [showCornersModal, setShowCornersModal] = useState(false);
  const [showInsetsModal, setShowInsetsModal] = useState(false);

  // DEX & Guide Compiler State
  const [compiling, setCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [packageReady, setPackageReady] = useState(false);
  const [showSmaliPreview, setShowSmaliPreview] = useState(false);
  const [showGuidePreview, setShowGuidePreview] = useState(false);
  const [compiledInfo, setCompiledInfo] = useState<{
    smaliPreview: string;
    guideText: string;
    primaryHook: string;
    secondaryHook: string;
  } | null>(null);

  const currentLayers = config[activeState];
  const currentLayer = currentLayers[activeLayerIdx] || currentLayers[0];

  const updateCurrentLayer = (updates: Partial<DrawableLayer>) => {
    setConfig((prev) => {
      const stateLayers = [...prev[activeState]];
      stateLayers[activeLayerIdx] = {
        ...stateLayers[activeLayerIdx],
        enabled: true,
        ...updates,
      };
      return {
        ...prev,
        [activeState]: stateLayers,
      };
    });
  };

  const handleReset = () => {
    setConfig(createInitialDrawableConfig());
    setActiveLayerIdx(0);
    setPackageReady(false);
    onShowToast(
      'Reset Complete',
      'All layers and colors reset to blank state.'
    );
  };

  const generatedXml = generateDrawableXml(config, mode, xmlIndentation);

  const screenTitle =
    mode === '3d'
      ? '3D XML Creator'
      : mode === 'gradient'
      ? 'Gradient XML Creator'
      : mode === 'normal'
      ? 'Normal XML Creator'
      : 'Ripple XML Creator';

  const getInitialColorForTarget = () => {
    if (colorPickerTarget === 'start') return currentLayer.startColor;
    if (colorPickerTarget === 'center') return currentLayer.centerColor;
    if (colorPickerTarget === 'end') return currentLayer.endColor;
    if (colorPickerTarget === 'stroke') return currentLayer.strokeColor;
    if (colorPickerTarget === 'ripple') return config.rippleColor;
    return '#00F5D4';
  };

  const handleColorSelected = (hex: string) => {
    if (colorPickerTarget === 'start') {
      if (mode === 'normal' || mode === 'ripple') {
        updateCurrentLayer({ startColor: hex, endColor: hex });
      } else {
        updateCurrentLayer({
          startColor: hex,
          endColor:
            currentLayer.endColor === 'None' ? hex : currentLayer.endColor,
        });
      }
    } else if (colorPickerTarget === 'center') {
      updateCurrentLayer({ centerColor: hex, useCenterColor: true });
    } else if (colorPickerTarget === 'end') {
      updateCurrentLayer({
        endColor: hex,
        startColor:
          currentLayer.startColor === 'None' ? hex : currentLayer.startColor,
      });
    } else if (colorPickerTarget === 'stroke') {
      updateCurrentLayer({
        strokeColor: hex,
        strokeWidth: currentLayer.strokeWidth > 0 ? currentLayer.strokeWidth : 2,
      });
    } else if (colorPickerTarget === 'ripple') {
      setConfig((prev) => ({ ...prev, rippleColor: hex }));
    }
  };

  const handleCompileDexPackage = async () => {
    setCompiling(true);
    setPackageReady(false);
    setCompileProgress(12);
    const pkg = await generateDrawableDexPackage(
      config,
      mode,
      generatedXml,
      buttonLabelText
    );
    setCompiledInfo({
      smaliPreview: pkg.smaliPreview,
      guideText: pkg.guideText,
      primaryHook: pkg.primaryHook,
      secondaryHook: pkg.secondaryHook,
    });

    let p = 12;
    const id = window.setInterval(() => {
      p += 18;
      if (p >= 100) {
        p = 100;
        setCompileProgress(100);
        clearInterval(id);
        setCompiling(false);
        setPackageReady(true);
        onShowToast(
          'Pure Drawable DEX Ready!',
          'Compiled inside classes2.dex & classes.dex (No Popup Dialog, No res/ folder!)'
        );
      } else {
        setCompileProgress(p);
      }
    }, 90);
  };

  const handleDownloadDex2Only = async () => {
    const pkg = await generateDrawableDexPackage(
      config,
      mode,
      generatedXml,
      buttonLabelText
    );
    triggerBlobDownload(
      new Blob([pkg.dexBytes.buffer as ArrayBuffer], {
        type: 'application/octet-stream',
      }),
      'classes2.dex'
    );
    onShowToast(
      'Downloaded classes2.dex',
      'Add classes2.dex directly to your APK in MT Manager -> Merge DEX!'
    );
  };

  const handleDownloadDexOnly = async () => {
    const pkg = await generateDrawableDexPackage(
      config,
      mode,
      generatedXml,
      buttonLabelText
    );
    triggerBlobDownload(
      new Blob([pkg.dexBytes.buffer as ArrayBuffer], {
        type: 'application/octet-stream',
      }),
      'classes.dex'
    );
    onShowToast(
      'Downloaded classes.dex',
      'Open in MT Manager -> Dex Editor Plus to view Smali!'
    );
  };

  const handleDownloadCompleteZip = async () => {
    const pkg = await generateDrawableDexPackage(
      config,
      mode,
      generatedXml,
      buttonLabelText
    );
    triggerBlobDownload(pkg.zipBlob, pkg.fileName);
    onSaveHistory(`${screenTitle} (classes2.dex)`, pkg.secondaryHook);
    onShowToast(
      'Complete ZIP Downloaded',
      'Contains classes2.dex + classes.dex + GUIDE.txt (Pure Drawable — No Popup!)'
    );
  };

  const handleDownloadGuideOnly = async () => {
    const pkg = await generateDrawableDexPackage(
      config,
      mode,
      generatedXml,
      buttonLabelText
    );
    triggerBlobDownload(
      new Blob([pkg.guideText], { type: 'text/plain;charset=utf-8' }),
      'GUIDE.txt'
    );
    onShowToast('GUIDE.txt Downloaded', 'Step-by-step Bangla & English guide saved!');
  };

  return (
    <div className="flex flex-col pb-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white flex items-center gap-1.5 ${microClass}`}
        >
          <span>←</span>
          <AnimatedText text="Back" config={typingConfig} />
        </button>

        <h1 className="text-base font-extrabold text-center text-white tracking-wide truncate">
          <AnimatedText text={screenTitle} config={typingConfig} />
        </h1>

        <button
          type="button"
          onClick={handleReset}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white flex items-center gap-1.5 ${microClass}`}
        >
          <span className="text-[#00f5d4]">↻</span>
          <AnimatedText text="Reset" config={typingConfig} />
        </button>
      </div>

      {/* Live 3-State Preview Panel */}
      <div
        className={`sticky top-2 z-20 rounded-2xl border-2 bg-[#081317]/95 backdrop-blur-md p-3 mb-3.5 ${glowClass}`}
      >
        <div className="grid grid-cols-3 gap-2.5 mb-2.5">
          {(['normal', 'checked', 'pressed'] as const).map((st) => {
            const layers = config[st];
            const configured = isStateConfigured(layers);
            const label =
              st === 'normal'
                ? 'Normal'
                : st === 'checked'
                ? 'Checked'
                : 'Pressed';
            const isSelected = activeState === st;

            return (
              <div
                key={st}
                onClick={() => setActiveState(st)}
                className={`relative h-16 rounded-xl border-2 flex items-center justify-center overflow-hidden cursor-pointer transition-all ${
                  isSelected
                    ? 'border-[#00f5d4] shadow-[0_0_12px_rgba(0,245,212,0.35)]'
                    : 'border-[#00f5d4]/40'
                } bg-[#0c1a1f]`}
              >
                {configured ? (
                  <div className="relative w-full h-full flex items-center justify-center p-1.5">
                    {layers
                      .filter(isLayerConfigured)
                      .map((layer, idx) => (
                        <div
                          key={layer.id}
                          className="absolute transition-all"
                          style={{
                            top: `${Math.min(18, idx * 3 + layer.insetTop * 0.5)}px`,
                            bottom: `${Math.min(18, idx * 3 + layer.insetBottom * 0.5)}px`,
                            left: `${Math.min(18, idx * 3 + layer.insetLeft * 0.5)}px`,
                            right: `${Math.min(18, idx * 3 + layer.insetRight * 0.5)}px`,
                            ...renderLayerCss(layer),
                          }}
                        />
                      ))}
                    <span className="relative z-10 text-xs font-bold text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
                      {label}
                    </span>
                  </div>
                ) : (
                  <div className="text-center leading-tight px-1">
                    <div className="text-xs font-bold text-white">
                      <AnimatedText text={label} config={typingConfig} />
                    </div>
                    <div className="text-[11px] font-semibold text-slate-300">
                      <AnimatedText text="(Not Set)" config={typingConfig} />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          {(['normal', 'checked', 'pressed'] as const).map((st) => {
            const active = activeState === st;
            const title =
              st === 'normal'
                ? 'Edit Normal'
                : st === 'checked'
                ? 'Edit Checked'
                : 'Edit Pressed';
            return (
              <button
                key={st}
                type="button"
                onClick={() => setActiveState(st)}
                className={`py-2 px-2 rounded-xl border text-xs font-bold leading-tight transition-all ${microClass} ${
                  active
                    ? 'border-[#00ff88] bg-gradient-to-b from-[#0eab5c] via-[#12664f] to-[#9e1946] text-white shadow-[0_0_12px_rgba(0,255,136,0.35)]'
                    : 'border-[#00f5d4]/50 bg-[#0d1c21] text-slate-200'
                }`}
              >
                <AnimatedText text={title} config={typingConfig} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Select Layer to Edit (Shown in 3D XML Creator) */}
      {mode === '3d' && (
        <div
          className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}
        >
          <div className="text-xs font-bold text-white mb-2.5">
            <AnimatedText text="Select Layer to Edit" config={typingConfig} />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[0, 1, 2, 3].map((idx) => {
              const active = activeLayerIdx === idx;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveLayerIdx(idx)}
                  className={`py-2.5 rounded-xl border text-xs font-bold transition-all ${microClass} ${
                    active
                      ? 'border-[#00ff88] bg-gradient-to-r from-[#0ea55c] to-[#0b7261] text-white'
                      : 'border-[#00f5d4]/50 bg-[#0d1c21] text-slate-200'
                  }`}
                >
                  <AnimatedText
                    text={`Layer ${idx + 1}`}
                    config={typingConfig}
                  />
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Layer Properties Card */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="text-xs font-bold text-white mb-3">
          <AnimatedText
            text={
              mode === '3d'
                ? `${activeState.toUpperCase()} • Layer ${activeLayerIdx + 1}`
                : 'Layer Properties'
            }
            config={typingConfig}
          />
        </div>

        {mode === 'normal' || mode === 'ripple' ? (
          <div className="space-y-3">
            <div className="text-center text-xs font-bold text-slate-200">
              Background Color
            </div>
            <div className="py-2.5 px-3 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-center font-mono text-xs text-white flex items-center justify-center gap-2">
              {currentLayer.startColor !== 'None' && (
                <span
                  className="w-3.5 h-3.5 rounded-full border border-white/50"
                  style={{ backgroundColor: currentLayer.startColor }}
                />
              )}
              <span>{currentLayer.startColor}</span>
            </div>
            <button
              type="button"
              onClick={() => setColorPickerTarget('start')}
              className={`w-full py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f24] text-xs font-bold text-white uppercase tracking-wider ${microClass}`}
            >
              PICK COLOR
            </button>

            {mode === 'ripple' && (
              <>
                <div className="text-center text-xs font-bold text-slate-200 pt-2">
                  Ripple Wave Effect Color
                </div>
                <div className="py-2.5 px-3 rounded-xl border border-[#00f5d4]/50 bg-[#0c1a1f] text-center font-mono text-xs text-white flex items-center justify-center gap-2">
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-white/50"
                    style={{ backgroundColor: config.rippleColor }}
                  />
                  <span>{config.rippleColor}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setColorPickerTarget('ripple')}
                  className={`w-full py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f24] text-xs font-bold text-white uppercase tracking-wider ${microClass}`}
                >
                  PICK RIPPLE COLOR
                </button>
              </>
            )}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-2.5 text-center mb-3">
              {/* Start Color */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[11px] font-semibold text-slate-200">
                  <AnimatedText text="Start Color" config={typingConfig} />
                </span>
                <div className="py-2 px-1.5 rounded-xl border border-[#00f5d4]/50 bg-[#0c1b20] text-[11px] font-mono text-white truncate flex items-center justify-center gap-1">
                  {currentLayer.startColor !== 'None' && (
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: currentLayer.startColor }}
                    />
                  )}
                  <span>{currentLayer.startColor}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setColorPickerTarget('start')}
                  className={`py-2 px-2 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white leading-tight ${microClass}`}
                >
                  PICK
                  <br />
                  COLOR
                </button>
              </div>

              {/* Center Color */}
              <div
                className={`flex flex-col gap-1.5 ${
                  !currentLayer.useCenterColor ? 'opacity-45' : ''
                }`}
              >
                <span className="text-[11px] font-semibold text-slate-200">
                  <AnimatedText text="Center Color" config={typingConfig} />
                </span>
                <div className="py-2 px-1.5 rounded-xl border border-[#00f5d4]/50 bg-[#0c1b20] text-[11px] font-mono text-white truncate flex items-center justify-center gap-1">
                  {currentLayer.useCenterColor &&
                    currentLayer.centerColor !== 'None' && (
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: currentLayer.centerColor }}
                      />
                    )}
                  <span>
                    {currentLayer.useCenterColor
                      ? currentLayer.centerColor
                      : 'Disabled'}
                  </span>
                </div>
                <button
                  type="button"
                  disabled={!currentLayer.useCenterColor}
                  onClick={() => setColorPickerTarget('center')}
                  className={`py-2 px-2 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white leading-tight ${microClass}`}
                >
                  {currentLayer.useCenterColor ? (
                    <>
                      PICK
                      <br />
                      COLOR
                    </>
                  ) : (
                    <span className="py-1 inline-block">DISABLED</span>
                  )}
                </button>
              </div>

              {/* End Color */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[11px] font-semibold text-slate-200">
                  <AnimatedText text="End Color" config={typingConfig} />
                </span>
                <div className="py-2 px-1.5 rounded-xl border border-[#00f5d4]/50 bg-[#0c1b20] text-[11px] font-mono text-white truncate flex items-center justify-center gap-1">
                  {currentLayer.endColor !== 'None' && (
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: currentLayer.endColor }}
                    />
                  )}
                  <span>{currentLayer.endColor}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setColorPickerTarget('end')}
                  className={`py-2 px-2 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white leading-tight ${microClass}`}
                >
                  PICK
                  <br />
                  COLOR
                </button>
              </div>
            </div>

            <label className="flex items-center gap-2.5 py-1.5 text-xs font-semibold text-white cursor-pointer select-none mb-2">
              <input
                type="checkbox"
                checked={currentLayer.useCenterColor}
                onChange={(e) =>
                  updateCurrentLayer({
                    useCenterColor: e.target.checked,
                    centerColor:
                      e.target.checked && currentLayer.centerColor === 'None'
                        ? '#0055FF'
                        : currentLayer.centerColor,
                  })
                }
                className="w-4 h-4 rounded accent-[#00f5d4]"
              />
              <AnimatedText
                text="3-Color Gradient (Center Color Active)"
                config={typingConfig}
              />
            </label>

            <div className="text-xs font-bold text-white mb-2">
              <AnimatedText text="Gradient Type" config={typingConfig} />
            </div>
            <div className="grid grid-cols-3 gap-2.5 mb-3">
              {(['Linear', 'Radial', 'Sweep'] as const).map((gType) => {
                const active = currentLayer.gradientType === gType;
                return (
                  <button
                    key={gType}
                    type="button"
                    onClick={() => updateCurrentLayer({ gradientType: gType })}
                    className={`py-2.5 rounded-xl border text-xs font-bold transition-all ${microClass} ${
                      active
                        ? 'border-[#00ff88] bg-gradient-to-r from-[#0ea55c] to-[#0b7261] text-white'
                        : 'border-[#00f5d4]/50 bg-[#0d1c21] text-slate-200'
                    }`}
                  >
                    <AnimatedText text={gType} config={typingConfig} />
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between text-xs font-bold mb-1.5">
              <span className="text-white">
                <AnimatedText text="Angle (degrees)" config={typingConfig} />
              </span>
              <span className="font-mono text-[#ff2a85]">
                {currentLayer.angle}°
              </span>
            </div>
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() =>
                  updateCurrentLayer({
                    angle: (currentLayer.angle - 45 + 360) % 360,
                  })
                }
                className={`w-10 h-9 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f24] text-white font-bold flex items-center justify-center ${microClass}`}
              >
                −
              </button>
              <input
                type="range"
                min={0}
                max={315}
                step={45}
                value={currentLayer.angle}
                onChange={(e) =>
                  updateCurrentLayer({ angle: Number(e.target.value) })
                }
                className="flex-1"
              />
              <button
                type="button"
                onClick={() =>
                  updateCurrentLayer({
                    angle: (currentLayer.angle + 45) % 360,
                  })
                }
                className={`w-10 h-9 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f24] text-white font-bold flex items-center justify-center ${microClass}`}
              >
                +
              </button>
            </div>
          </>
        )}
      </div>

      {/* Stroke Color & Outline Card */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-2.5 ${glowClass}`}
      >
        <div className="text-center text-xs font-bold text-white">
          <AnimatedText text="Stroke Color & Outline" config={typingConfig} />
        </div>

        <div className="py-2.5 px-3 rounded-xl border border-[#00f5d4]/50 bg-[#0c1b20] text-center font-mono text-xs text-white">
          {currentLayer.strokeColor === 'None' || currentLayer.strokeWidth === 0
            ? 'None (0dp)'
            : `${currentLayer.strokeColor} (${currentLayer.strokeWidth}dp)`}
        </div>

        <button
          type="button"
          onClick={() => setColorPickerTarget('stroke')}
          className={`w-full py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase tracking-wider ${microClass}`}
        >
          <AnimatedText text="PICK COLOR" config={typingConfig} />
        </button>

        <button
          type="button"
          onClick={() => setShowStrokeModal(true)}
          className={`w-full py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase tracking-wider ${microClass}`}
        >
          <AnimatedText text="SET CUSTOM STROKE" config={typingConfig} />
        </button>

        <button
          type="button"
          onClick={() => setShowCornersModal(true)}
          className={`w-full py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase tracking-wider ${microClass}`}
        >
          <AnimatedText text="SET CUSTOM CORNERS" config={typingConfig} />
        </button>

        {mode === '3d' && (
          <button
            type="button"
            onClick={() => setShowInsetsModal(true)}
            className={`w-full py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase tracking-wider ${microClass}`}
          >
            <AnimatedText
              text="SET CUSTOM INSETS (SIZE/POS)"
              config={typingConfig}
            />
          </button>
        )}
      </div>

      {/* Build & Export Package (Pure Drawable / Button View inside classes2.dex + classes.dex) */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-white">
            ⚡ Build Pure Drawable DEX Package
          </span>
          <span className="text-[10px] font-mono text-[#00ff88]">
            No Popup Dialog!
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mb-2.5">
          Compiles your {screenTitle} as a pure Android{' '}
          <span className="text-[#00f5d4] font-mono">GradientDrawable</span>{' '}
          inside <span className="text-white font-mono">classes2.dex</span> &amp;{' '}
          <span className="text-white font-mono">classes.dex</span> — applies to
          any View/Button or renders as a pure Button layout (NO popup dialog,
          NO Join Telegram / Continue buttons!).
        </p>

        <div className="mb-3">
          <label className="text-[11px] font-semibold text-slate-300 block mb-1">
            Button Label Text (if rendered directly on screen)
          </label>
          <input
            type="text"
            value={buttonLabelText}
            onChange={(e) => {
              setButtonLabelText(e.target.value);
              setPackageReady(false);
            }}
            className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-bold text-white"
            placeholder="e.g. ACTIVATE VIP MOD"
          />
        </div>

        <button
          type="button"
          onClick={handleCompileDexPackage}
          className={`w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d262e] text-xs font-extrabold text-white uppercase tracking-wider mb-3 flex items-center justify-center gap-2 ${microClass}`}
        >
          <span className="text-[#ffd166]">⚡</span>
          <span>Generate Package (classes2.dex + GUIDE.txt)</span>
        </button>

        {(compiling || packageReady) && (
          <div className="space-y-3">
            <ConversionShaderView
              shaderId={1}
              sourceLabel="DRAWABLE XML"
              targetLabel="CLASSES2.DEX"
              progress={compileProgress}
              compact
            />

            {packageReady && compiledInfo && (
              <div className="rounded-xl border border-[#00ff88]/60 bg-[#071915] p-3.5 space-y-2.5">
                <div className="text-center text-xs font-bold text-[#00ff88]">
                  ✓ Pure {screenTitle} Compiled Inside classes2.dex!
                </div>
                <div className="text-center text-[11px] font-mono text-slate-300">
                  • Pure Drawable &amp; Button View (No Popup Dialog!) • GUIDE.txt
                </div>

                <button
                  type="button"
                  onClick={handleDownloadDex2Only}
                  className={`w-full py-3 rounded-xl border-2 border-[#00ff88] bg-[#0b2e25] text-xs font-extrabold text-[#00ff88] flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>⚡</span>
                  <span>Download classes2.dex (Direct APK Add — No Conflict!)</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadCompleteZip}
                  className={`w-full py-3 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>📦</span>
                  <span>Download Complete ZIP (classes2.dex + classes.dex + GUIDE)</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handleDownloadDexOnly}
                    className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white ${microClass}`}
                  >
                    ⬇ classes.dex
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadGuideOnly}
                    className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white ${microClass}`}
                  >
                    📄 GUIDE.txt
                  </button>
                </div>

                {/* 1-Line Smali Hooks */}
                <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-2.5 space-y-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00f5d4]">
                        1) APPLY TO ANY VIEW / BUTTON (Register v0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(compiledInfo.secondaryHook);
                          onShowToast('Hook Copied!', 'View background hook copied.');
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00f5d4]/60 text-[10px] font-bold text-[#00f5d4]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {compiledInfo.secondaryHook}
                    </code>
                  </div>

                  <div className="pt-1 border-t border-[#00f5d4]/20">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00ff88]">
                        2) INJECT PURE STYLED BUTTON ON SCREEN (Register p0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(compiledInfo.primaryHook);
                          onShowToast('Hook Copied!', 'MainActivity hook copied.');
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00ff88]/60 text-[10px] font-bold text-[#00ff88]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {compiledInfo.primaryHook}
                    </code>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSmaliPreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00f5d4]/40 bg-[#0a181d] text-[11px] font-bold text-[#00f5d4]"
                  >
                    {showSmaliPreview ? '▲ Hide Smali Code' : '▼ View Smali in DEX'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGuidePreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00ff88]/40 bg-[#0a181d] text-[11px] font-bold text-[#00ff88]"
                  >
                    {showGuidePreview ? '▲ Hide Guide Text' : '📖 View GUIDE.txt'}
                  </button>
                </div>

                {showSmaliPreview && (
                  <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00f5d4]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-[#00ff88] leading-relaxed select-all">
                    {compiledInfo.smaliPreview}
                  </pre>
                )}

                {showGuidePreview && (
                  <pre className="max-h-60 overflow-y-auto rounded-xl border border-[#00ff88]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-slate-200 leading-relaxed select-all whitespace-pre-wrap">
                    {compiledInfo.guideText}
                  </pre>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Generated XML Code Card */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 ${glowClass}`}
      >
        <div className="text-xs font-bold text-white mb-2">
          <AnimatedText text="Generated XML Code" config={typingConfig} />
        </div>

        <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00f5d4]/50 bg-[#050d10] p-3 font-mono text-xs text-[#98f5e1] leading-relaxed select-all">
          {generatedXml}
        </pre>

        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(generatedXml);
              onShowToast('XML Copied!', 'Drawable XML copied to clipboard.');
            }}
            className={`py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase ${microClass}`}
          >
            COPY CODE
          </button>

          <button
            type="button"
            onClick={() => {
              onSaveHistory(`${screenTitle} Drawable`, generatedXml);
              onShowToast('Saved to History', 'XML resource saved in local history.');
            }}
            className={`py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase ${microClass}`}
          >
            SAVE HISTORY
          </button>

          <button
            type="button"
            onClick={() => {
              const blob = new Blob([generatedXml], { type: 'application/xml' });
              const fileName = `nsmods_${mode}_${Math.floor(100 + Math.random() * 900)}.xml`;
              triggerBlobDownload(blob, fileName);
              onShowToast('XML Downloaded', `Saved as ${fileName}`);
            }}
            className={`py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white uppercase ${microClass}`}
          >
            DOWNLOAD XML
          </button>

          <button
            type="button"
            onClick={handleDownloadCompleteZip}
            className={`py-3 rounded-xl border border-[#00ff88]/70 bg-[#0b2e25] text-xs font-bold text-[#00ff88] uppercase ${microClass}`}
          >
            DOWNLOAD DEX ZIP
          </button>
        </div>
      </div>

      {/* Modals */}
      <ColorPickerModal
        isOpen={colorPickerTarget !== null}
        initialColor={getInitialColorForTarget()}
        onClose={() => setColorPickerTarget(null)}
        onSelectColor={handleColorSelected}
      />

      <CustomStrokeModal
        isOpen={showStrokeModal}
        layer={currentLayer}
        onClose={() => setShowStrokeModal(false)}
        onSave={updateCurrentLayer}
      />

      <CustomCornersModal
        isOpen={showCornersModal}
        layer={currentLayer}
        onClose={() => setShowCornersModal(false)}
        onSave={updateCurrentLayer}
      />

      <CustomInsetsModal
        isOpen={showInsetsModal}
        layer={currentLayer}
        onClose={() => setShowInsetsModal(false)}
        onSave={updateCurrentLayer}
      />
    </div>
  );
};

/* ============================================================================
   LAYOUT XML CREATOR SCREEN (100% Pure Android Layout — NO Popup Dialog!)
============================================================================ */

export interface LayoutWidget {
  id: string;
  type:
    | 'TextView'
    | 'Button'
    | 'EditText'
    | 'Switch'
    | 'CheckBox'
    | 'RadioButton'
    | 'SeekBar'
    | 'ProgressBar'
    | 'CardView';
  text: string;
  textColor: string;
  bgColor: string;
  paddingDp: number;
  marginDp: number;
  textSizeSp: number;
  cornerRadiusDp: number;
  strokeWidthDp: number;
  strokeColor: string;
  checked: boolean;
  progress: number;
}

interface LayoutPresetTemplate {
  id: string;
  name: string;
  subtitle: string;
  displayMode: 'layout_fullscreen' | 'layout_overlay';
  rootBg: string;
  rootPadding: number;
  widgets: LayoutWidget[];
}

const LAYOUT_TEMPLATES: LayoutPresetTemplate[] = [
  {
    id: 'mod_panel',
    name: '🛠️ VIP Mod Panel',
    subtitle: 'Switches, SeekBar & Action Button',
    displayMode: 'layout_overlay',
    rootBg: '#081418',
    rootPadding: 16,
    widgets: [
      {
        id: 'mp_1',
        type: 'TextView',
        text: '⚡ NS MODS VIP PANEL',
        textColor: '#00F5D4',
        bgColor: 'transparent',
        paddingDp: 8,
        marginDp: 4,
        textSizeSp: 19,
        cornerRadiusDp: 0,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'mp_2',
        type: 'Switch',
        text: 'Unlock 120 FPS Ultra Graphics',
        textColor: '#FFFFFF',
        bgColor: '#0D2229',
        paddingDp: 12,
        marginDp: 5,
        textSizeSp: 14,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'mp_3',
        type: 'CheckBox',
        text: 'Anti-Ban Protection Shield',
        textColor: '#E6FFFA',
        bgColor: '#0D2229',
        paddingDp: 12,
        marginDp: 5,
        textSizeSp: 14,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#00FF88',
        checked: true,
        progress: 100,
      },
      {
        id: 'mp_4',
        type: 'SeekBar',
        text: 'Speed / FOV Range (80%)',
        textColor: '#00F5D4',
        bgColor: '#0B1B20',
        paddingDp: 10,
        marginDp: 5,
        textSizeSp: 13,
        cornerRadiusDp: 10,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 80,
      },
      {
        id: 'mp_5',
        type: 'Button',
        text: 'APPLY MOD SETTINGS',
        textColor: '#041014',
        bgColor: '#00F5D4',
        paddingDp: 14,
        marginDp: 6,
        textSizeSp: 15,
        cornerRadiusDp: 14,
        strokeWidthDp: 0,
        strokeColor: '#FFFFFF',
        checked: true,
        progress: 100,
      },
    ],
  },
  {
    id: 'key_login',
    name: '🔐 Key Login Screen',
    subtitle: 'Full-Screen Auth UI Layout',
    displayMode: 'layout_fullscreen',
    rootBg: '#060F13',
    rootPadding: 20,
    widgets: [
      {
        id: 'kl_1',
        type: 'TextView',
        text: '🔐 VIP LICENSE LOGIN',
        textColor: '#00F5D4',
        bgColor: 'transparent',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 21,
        cornerRadiusDp: 0,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'kl_2',
        type: 'TextView',
        text: 'Enter your license key below to unlock full access',
        textColor: '#A0AEC0',
        bgColor: 'transparent',
        paddingDp: 6,
        marginDp: 4,
        textSizeSp: 13,
        cornerRadiusDp: 0,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'kl_3',
        type: 'EditText',
        text: 'Enter Username / ID...',
        textColor: '#FFFFFF',
        bgColor: '#0C1E24',
        paddingDp: 14,
        marginDp: 6,
        textSizeSp: 14,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'kl_4',
        type: 'EditText',
        text: 'Enter VIP License Key...',
        textColor: '#00FF88',
        bgColor: '#0C1E24',
        paddingDp: 14,
        marginDp: 6,
        textSizeSp: 14,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#00FF88',
        checked: true,
        progress: 100,
      },
      {
        id: 'kl_5',
        type: 'CheckBox',
        text: 'Remember License Key on Device',
        textColor: '#E2E8F0',
        bgColor: 'transparent',
        paddingDp: 8,
        marginDp: 4,
        textSizeSp: 13,
        cornerRadiusDp: 8,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'kl_6',
        type: 'Button',
        text: 'VERIFY & UNLOCK APP',
        textColor: '#041014',
        bgColor: '#00FF88',
        paddingDp: 14,
        marginDp: 8,
        textSizeSp: 15,
        cornerRadiusDp: 14,
        strokeWidthDp: 0,
        strokeColor: '#FFFFFF',
        checked: true,
        progress: 100,
      },
    ],
  },
  {
    id: 'hud_bar',
    name: '📊 Gamer HUD Bar',
    subtitle: 'Compact Top Overlay Banner',
    displayMode: 'layout_overlay',
    rootBg: '#09161B',
    rootPadding: 12,
    widgets: [
      {
        id: 'hb_1',
        type: 'TextView',
        text: '⚡ FPS: 120 | PING: 18ms | ANTIBAN: ACTIVE',
        textColor: '#00FF88',
        bgColor: '#0D242C',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 13,
        cornerRadiusDp: 10,
        strokeWidthDp: 1,
        strokeColor: '#00FF88',
        checked: true,
        progress: 100,
      },
      {
        id: 'hb_2',
        type: 'Switch',
        text: 'ESP Overlay & Touch Boost',
        textColor: '#FFFFFF',
        bgColor: '#0C1E24',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 13,
        cornerRadiusDp: 10,
        strokeWidthDp: 1,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
    ],
  },
  {
    id: 'settings_patcher',
    name: '⚙️ App Settings UI',
    subtitle: 'Full Screen Patcher Layout',
    displayMode: 'layout_fullscreen',
    rootBg: '#081216',
    rootPadding: 18,
    widgets: [
      {
        id: 'sp_1',
        type: 'TextView',
        text: '⚙️ ADVANCED APP CONFIGURATION',
        textColor: '#00F5D4',
        bgColor: 'transparent',
        paddingDp: 10,
        marginDp: 4,
        textSizeSp: 18,
        cornerRadiusDp: 0,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'sp_2',
        type: 'Switch',
        text: 'Force AMOLED Dark Theme',
        textColor: '#FFFFFF',
        bgColor: '#0D2026',
        paddingDp: 12,
        marginDp: 5,
        textSizeSp: 14,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'sp_3',
        type: 'Switch',
        text: 'Block All In-App Ads & Trackers',
        textColor: '#FFFFFF',
        bgColor: '#0D2026',
        paddingDp: 12,
        marginDp: 5,
        textSizeSp: 14,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#00FF88',
        checked: true,
        progress: 100,
      },
      {
        id: 'sp_4',
        type: 'RadioButton',
        text: 'Server Region: Asia Ultra-Low Latency',
        textColor: '#FFD166',
        bgColor: '#0D2026',
        paddingDp: 12,
        marginDp: 5,
        textSizeSp: 13,
        cornerRadiusDp: 12,
        strokeWidthDp: 1,
        strokeColor: '#FFD166',
        checked: true,
        progress: 100,
      },
      {
        id: 'sp_5',
        type: 'Button',
        text: 'SAVE & CONTINUE',
        textColor: '#041014',
        bgColor: '#00F5D4',
        paddingDp: 14,
        marginDp: 8,
        textSizeSp: 15,
        cornerRadiusDp: 14,
        strokeWidthDp: 0,
        strokeColor: '#FFFFFF',
        checked: true,
        progress: 100,
      },
    ],
  },
  {
    id: 'clean_minimal',
    name: '✨ Minimal Layout',
    subtitle: 'Simple Title + Action Button',
    displayMode: 'layout_fullscreen',
    rootBg: '#091417',
    rootPadding: 18,
    widgets: [
      {
        id: 'cm_1',
        type: 'TextView',
        text: 'Welcome to Custom Layout',
        textColor: '#00F5D4',
        bgColor: 'transparent',
        paddingDp: 12,
        marginDp: 6,
        textSizeSp: 20,
        cornerRadiusDp: 0,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
      {
        id: 'cm_2',
        type: 'Button',
        text: 'GET STARTED',
        textColor: '#041014',
        bgColor: '#00F5D4',
        paddingDp: 14,
        marginDp: 8,
        textSizeSp: 15,
        cornerRadiusDp: 12,
        strokeWidthDp: 0,
        strokeColor: '#00F5D4',
        checked: true,
        progress: 100,
      },
    ],
  },
];

const QUICK_SWATCHES = [
  '#00F5D4',
  '#00FF88',
  '#FF2A85',
  '#FFD166',
  '#38BDF8',
  '#A855F7',
  '#FFFFFF',
  '#0D2228',
  '#061014',
];

export const LayoutXmlCreatorScreen: React.FC<{
  typingConfig: TypingConfig;
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onSaveHistory: (title: string, code: string) => void;
  onShowToast: (title: string, subtitle: string) => void;
}> = ({
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [rootContainer, setRootContainer] = useState<
    'LinearLayout' | 'RelativeLayout' | 'FrameLayout' | 'ScrollView'
  >('LinearLayout');
  const [orientation, setOrientation] = useState<'vertical' | 'horizontal'>('vertical');
  const [layoutDisplayMode, setLayoutDisplayMode] = useState<
    'layout_fullscreen' | 'layout_overlay'
  >('layout_fullscreen');
  const [rootPadding, setRootPadding] = useState(16);
  const [rootBg, setRootBg] = useState('#081418');
  const [rootCornerRadius, setRootCornerRadius] = useState(16);
  const [rootStrokeWidth, setRootStrokeWidth] = useState(2);
  const [rootStrokeColor, setRootStrokeColor] = useState('#00F5D4');
  const [enableRainbowText, setEnableRainbowText] = useState(true);
  const [enableTouchParticles, setEnableTouchParticles] = useState(true);
  const [selectedWidgetId, setSelectedWidgetId] = useState<string>('mp_1');

  const [widgets, setWidgets] = useState<LayoutWidget[]>(
    LAYOUT_TEMPLATES[0].widgets
  );

  // DEX & Guide Compiler State
  const [compiling, setCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [packageReady, setPackageReady] = useState(false);
  const [showSmaliPreview, setShowSmaliPreview] = useState(false);
  const [showGuidePreview, setShowGuidePreview] = useState(false);
  const [compiledLayoutPkg, setCompiledLayoutPkg] = useState<{
    smaliPreview: string;
    guideText: string;
    primaryHook: string;
    secondaryHook: string;
    tertiaryHook: string;
  } | null>(null);

  const loadTemplate = (tpl: LayoutPresetTemplate) => {
    const cloned = tpl.widgets.map((w, i) => ({
      ...w,
      id: `${tpl.id}_${Date.now()}_${i}`,
    }));
    setWidgets(cloned);
    setLayoutDisplayMode(tpl.displayMode);
    setRootBg(tpl.rootBg);
    setRootPadding(tpl.rootPadding);
    if (cloned[0]) setSelectedWidgetId(cloned[0].id);
    setPackageReady(false);
    onShowToast(
      `Loaded ${tpl.name}`,
      'Pure Android Layout template loaded (No Popup Dialog!)'
    );
  };

  const addWidget = (type: LayoutWidget['type']) => {
    const newId = `w_${Date.now()}`;
    const newW: LayoutWidget = {
      id: newId,
      type,
      text:
        type === 'Button'
          ? 'ACTION BUTTON'
          : type === 'EditText'
          ? 'Type input here...'
          : type === 'Switch'
          ? 'Toggle Feature Option'
          : type === 'CheckBox'
          ? 'Enable Custom Option'
          : type === 'RadioButton'
          ? 'Select Mode Option'
          : type === 'SeekBar'
          ? 'Slider Value (75%)'
          : type === 'ProgressBar'
          ? 'Loading 75%'
          : type === 'CardView'
          ? 'VIP Feature Card Banner'
          : 'Custom TextView Title',
      textColor: type === 'Button' ? '#041014' : '#00F5D4',
      bgColor:
        type === 'Button'
          ? '#00F5D4'
          : type === 'TextView'
          ? 'transparent'
          : '#0D2228',
      paddingDp: 12,
      marginDp: 6,
      textSizeSp: type === 'TextView' ? 18 : 14,
      cornerRadiusDp: type === 'TextView' ? 0 : 12,
      strokeWidthDp: type === 'Button' || type === 'TextView' ? 0 : 1,
      strokeColor: '#00F5D4',
      checked: true,
      progress: 75,
    };
    setWidgets((prev) => [...prev, newW]);
    setSelectedWidgetId(newId);
    setPackageReady(false);
  };

  const selectedWidget =
    widgets.find((w) => w.id === selectedWidgetId) || widgets[0];

  const updateSelectedWidget = (updates: Partial<LayoutWidget>) => {
    if (!selectedWidget) return;
    setWidgets((prev) =>
      prev.map((w) => (w.id === selectedWidget.id ? { ...w, ...updates } : w))
    );
    setPackageReady(false);
  };

  const moveSelectedWidget = (dir: -1 | 1) => {
    if (!selectedWidget) return;
    const idx = widgets.findIndex((w) => w.id === selectedWidget.id);
    if (idx === -1) return;
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= widgets.length) return;
    const copy = [...widgets];
    const [item] = copy.splice(idx, 1);
    copy.splice(targetIdx, 0, item);
    setWidgets(copy);
    setPackageReady(false);
  };

  const duplicateSelectedWidget = () => {
    if (!selectedWidget) return;
    const copyId = `w_${Date.now()}`;
    const copyItem: LayoutWidget = {
      ...selectedWidget,
      id: copyId,
      text: `${selectedWidget.text} (Copy)`,
    };
    const idx = widgets.findIndex((w) => w.id === selectedWidget.id);
    const next = [...widgets];
    next.splice(idx + 1, 0, copyItem);
    setWidgets(next);
    setSelectedWidgetId(copyId);
    setPackageReady(false);
  };

  const removeSelectedWidget = () => {
    if (!selectedWidget) return;
    setWidgets((prev) => prev.filter((w) => w.id !== selectedWidget.id));
    setPackageReady(false);
  };

  const buildLayoutXml = () => {
    const lines: string[] = [];
    lines.push(`<?xml version="1.0" encoding="utf-8"?>`);
    lines.push(
      `<!-- Generated by Ns mods — Pure Android Layout XML Creator -->`
    );
    lines.push(
      `<${rootContainer} xmlns:android="http://schemas.android.com/apk/res/android"`
    );
    lines.push(`    android:layout_width="match_parent"`);
    lines.push(
      `    android:layout_height="${
        layoutDisplayMode === 'layout_fullscreen'
          ? 'match_parent'
          : 'wrap_content'
      }"`
    );
    if (rootContainer === 'LinearLayout') {
      lines.push(`    android:orientation="${orientation}"`);
    }
    lines.push(`    android:background="${rootBg}"`);
    lines.push(`    android:padding="${rootPadding}dp">`);
    lines.push(``);

    widgets.forEach((w, idx) => {
      lines.push(`    <${w.type}`);
      lines.push(
        `        android:id="@+id/nsmods_${w.type.toLowerCase()}_${idx + 1}"`
      );
      lines.push(`        android:layout_width="match_parent"`);
      lines.push(`        android:layout_height="wrap_content"`);
      lines.push(`        android:layout_margin="${w.marginDp}dp"`);
      lines.push(`        android:padding="${w.paddingDp}dp"`);
      if (w.bgColor !== 'transparent') {
        lines.push(`        android:background="${w.bgColor}"`);
      }
      if (w.type === 'ProgressBar' || w.type === 'SeekBar') {
        if (w.type === 'ProgressBar') {
          lines.push(
            `        style="?android:attr/progressBarStyleHorizontal"`
          );
        }
        lines.push(`        android:max="100"`);
        lines.push(`        android:progress="${w.progress}" />`);
      } else {
        const attr = w.type === 'EditText' ? 'hint' : 'text';
        lines.push(`        android:${attr}="${w.text}"`);
        lines.push(`        android:textColor="${w.textColor}"`);
        if (
          w.type === 'Switch' ||
          w.type === 'CheckBox' ||
          w.type === 'RadioButton'
        ) {
          lines.push(`        android:checked="${w.checked}"`);
        }
        lines.push(`        android:textSize="${w.textSizeSp}sp" />`);
      }
      lines.push(``);
    });

    lines.push(`</${rootContainer}>`);
    return lines.join('\n');
  };

  const xmlCode = buildLayoutXml();

  const getPackageData = async () => {
    return generateLayoutDexPackage({
      rootContainer,
      orientation,
      rootPadding,
      rootBg,
      rootCornerRadius,
      rootStrokeWidth,
      rootStrokeColor,
      layoutDisplayMode,
      enableRainbowText,
      enableTouchParticles,
      widgets: widgets.map((w) => ({
        type: w.type,
        text: w.text,
        textColorHex: w.textColor,
        bgColorHex: w.bgColor,
        paddingDp: w.paddingDp,
        marginDp: w.marginDp,
        textSizeSp: w.textSizeSp,
        cornerRadiusDp: w.cornerRadiusDp,
        strokeWidthDp: w.strokeWidthDp,
        strokeColorHex: w.strokeColor,
        checked: w.checked,
        progress: w.progress,
      })),
      xmlCode,
    });
  };

  const handleCompileLayoutPackage = async () => {
    setCompiling(true);
    setPackageReady(false);
    setCompileProgress(10);
    const pkg = await getPackageData();
    setCompiledLayoutPkg({
      smaliPreview: pkg.smaliPreview,
      guideText: pkg.guideText,
      primaryHook: pkg.primaryHook,
      secondaryHook: pkg.secondaryHook,
      tertiaryHook: pkg.tertiaryHook,
    });

    let p = 10;
    const id = window.setInterval(() => {
      p += 18;
      if (p >= 100) {
        p = 100;
        setCompileProgress(100);
        clearInterval(id);
        setCompiling(false);
        setPackageReady(true);
        onShowToast(
          'Pure Layout classes2.dex Ready!',
          `All ${widgets.length} widgets compiled as a pure Android Layout (No Popup Dialog!)`
        );
      } else {
        setCompileProgress(p);
      }
    }, 90);
  };

  const handleDownloadLayoutDex2 = async () => {
    const pkg = await getPackageData();
    triggerBlobDownload(
      new Blob([pkg.dexBytes.buffer as ArrayBuffer], {
        type: 'application/octet-stream',
      }),
      'classes2.dex'
    );
    onShowToast(
      'Downloaded classes2.dex',
      'Add classes2.dex directly to your APK in MT Manager -> Merge DEX!'
    );
  };

  const handleDownloadLayoutDex = async () => {
    const pkg = await getPackageData();
    triggerBlobDownload(
      new Blob([pkg.dexBytes.buffer as ArrayBuffer], {
        type: 'application/octet-stream',
      }),
      'classes.dex'
    );
    onShowToast(
      'Downloaded classes.dex',
      'Open in MT Manager -> Dex Editor Plus to see Lcom/nsmods/xmlcreator/NsModsLayout;'
    );
  };

  const handleDownloadLayoutZip = async () => {
    const pkg = await getPackageData();
    triggerBlobDownload(pkg.zipBlob, pkg.fileName);
    onSaveHistory(`Pure Layout DEX (${widgets.length} Views)`, pkg.primaryHook);
    onShowToast(
      'Layout ZIP Downloaded',
      'Contains classes2.dex + classes.dex + GUIDE.txt (Pure Layout — No Popup Dialog!)'
    );
  };

  const handleDownloadLayoutGuide = async () => {
    const pkg = await getPackageData();
    triggerBlobDownload(
      new Blob([pkg.guideText], { type: 'text/plain;charset=utf-8' }),
      'GUIDE.txt'
    );
    onShowToast(
      'GUIDE.txt Downloaded',
      'Complete Bangla & English Pure Layout Guide saved!'
    );
  };

  return (
    <div className="flex flex-col pb-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          <AnimatedText text="Layout XML Creator" config={typingConfig} />
        </h1>
        <button
          type="button"
          onClick={() => {
            setWidgets([]);
            setPackageReady(false);
            onShowToast('Layout Cleared', 'All child views removed.');
          }}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ↻ Clear
        </button>
      </div>

      {/* Pure Layout Mode Guarantee Banner */}
      <div className="rounded-xl border border-[#00ff88]/60 bg-[#071f1a] px-3 py-2.5 mb-3 text-[11px] text-[#d8fff3] leading-relaxed">
        <div className="font-extrabold text-[#00ff88] mb-0.5">
          ✨ 100% Pure Android Layout Engine (পপআপ ডায়ালগ নয়!)
        </div>
        <div>
          এই Layout Creator দিয়ে তৈরি করলে কোনো পপআপ ডায়ালগ (AlertDialog) বা
          &quot;JOIN TELEGRAM / CONTINUE&quot; বাটন আসবে না! আপনি নিচে যে যে
          উইজেট যোগ করবেন, ঠিক সেগুলোই সরাসরি অ্যাপের ভেতর আসল Layout হিসেবে
          বসবে।
        </div>
      </div>

      {/* Layout Injection Mode Selector: Full Screen vs Overlay Panel */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3 mb-3.5 ${glowClass}`}
      >
        <div className="text-xs font-bold text-white mb-2">
          1. Select Layout Display Mode in APK
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => {
              setLayoutDisplayMode('layout_fullscreen');
              setPackageReady(false);
            }}
            className={`p-2.5 rounded-xl border text-left transition-all ${microClass} ${
              layoutDisplayMode === 'layout_fullscreen'
                ? 'border-2 border-[#00ff88] bg-[#0b2b22] text-white'
                : 'border-[#00f5d4]/40 bg-[#0d1c21] text-slate-300'
            }`}
          >
            <div className="text-xs font-extrabold text-[#00ff88]">
              📱 Full Screen Layout
            </div>
            <div className="text-[10px] text-slate-300 mt-0.5">
              Uses Activity.setContentView() — Full screen UI layout
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              setLayoutDisplayMode('layout_overlay');
              setPackageReady(false);
            }}
            className={`p-2.5 rounded-xl border text-left transition-all ${microClass} ${
              layoutDisplayMode === 'layout_overlay'
                ? 'border-2 border-[#00f5d4] bg-[#0b252e] text-white'
                : 'border-[#00f5d4]/40 bg-[#0d1c21] text-slate-300'
            }`}
          >
            <div className="text-xs font-extrabold text-[#00f5d4]">
              🪟 Overlay Panel Layout
            </div>
            <div className="text-[10px] text-slate-300 mt-0.5">
              Uses Activity.addContentView() — Floating panel on top of app
            </div>
          </button>
        </div>

        {/* Rainbow Text & Touch Star Toggles for Layout */}
        <div className="grid grid-cols-2 gap-2 mt-2.5 pt-2.5 border-t border-[#00f5d4]/20">
          <button
            type="button"
            onClick={() => {
              setEnableRainbowText((v) => !v);
              setPackageReady(false);
            }}
            className={`p-2 rounded-xl border text-left transition-all ${microClass} ${
              enableRainbowText
                ? 'border-[#00ff88] bg-[#0b2e25] text-[#00ff88]'
                : 'border-slate-700 bg-[#0b1518] text-slate-400'
            }`}
          >
            <div className="text-[11px] font-extrabold">
              🌈 Rainbow Text: {enableRainbowText ? 'ON' : 'OFF'}
            </div>
            <div className="text-[9px] text-slate-300 mt-0.5">
              Flowing 6-color rainbow wave on all text
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              setEnableTouchParticles((v) => !v);
              setPackageReady(false);
            }}
            className={`p-2 rounded-xl border text-left transition-all ${microClass} ${
              enableTouchParticles
                ? 'border-[#00f5d4] bg-[#0b252e] text-[#00f5d4]'
                : 'border-slate-700 bg-[#0b1518] text-slate-400'
            }`}
          >
            <div className="text-[11px] font-extrabold">
              ✨ Touch Stars: {enableTouchParticles ? 'ON' : 'OFF'}
            </div>
            <div className="text-[9px] text-slate-300 mt-0.5">
              Spawns glowing stars on screen tap
            </div>
          </button>
        </div>
      </div>

      {/* Quick Pro Layout Templates */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3 mb-3.5 ${glowClass}`}
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-white">
            2. Quick Pro Layout Templates (1-Tap Load)
          </span>
          <span className="text-[10px] font-mono text-[#00f5d4]">
            {LAYOUT_TEMPLATES.length} Templates
          </span>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {LAYOUT_TEMPLATES.map((tpl) => (
            <button
              key={tpl.id}
              type="button"
              onClick={() => loadTemplate(tpl)}
              className={`shrink-0 px-3 py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0c1d22] text-left hover:border-[#00ff88] transition-all ${microClass}`}
            >
              <div className="text-xs font-extrabold text-white">
                {tpl.name}
              </div>
              <div className="text-[10px] text-slate-400">{tpl.subtitle}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Sticky Live Visual Layout Preview */}
      <div
        className={`rounded-2xl border-2 p-3.5 mb-3.5 transition-all ${glowClass}`}
        style={{
          backgroundColor: rootBg,
          borderRadius: `${Math.max(12, rootCornerRadius)}px`,
          borderWidth: `${Math.max(2, rootStrokeWidth)}px`,
          borderColor: rootStrokeColor,
        }}
      >
        <div className="flex items-center justify-between text-[10px] font-mono text-[#00f5d4] mb-2 pb-1.5 border-b border-[#00f5d4]/20">
          <span>
            ● LIVE ANDROID LAYOUT (
            {layoutDisplayMode === 'layout_fullscreen'
              ? 'FULL SCREEN'
              : 'OVERLAY PANEL'}
            )
          </span>
          <span>{widgets.length} Widgets • Tap any item to edit</span>
        </div>

        <div
          className={`flex ${
            orientation === 'horizontal' && rootContainer === 'LinearLayout'
              ? 'flex-row overflow-x-auto'
              : 'flex-col'
          } gap-1.5`}
          style={{ padding: `${Math.min(24, rootPadding)}px` }}
        >
          {widgets.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              Tap any widget button below (+ TextView, + Button, + Switch, +
              SeekBar) to build your pure Android Layout.
            </div>
          ) : (
            widgets.map((w) => {
              const isSelected = selectedWidget?.id === w.id;
              return (
                <div
                  key={w.id}
                  onClick={() => setSelectedWidgetId(w.id)}
                  className={`flex items-center justify-between cursor-pointer transition-all ${
                    isSelected
                      ? 'ring-2 ring-[#00ff88] shadow-[0_0_14px_rgba(0,255,136,0.35)]'
                      : 'hover:opacity-95'
                  }`}
                  style={{
                    backgroundColor:
                      w.bgColor === 'transparent' ? 'transparent' : w.bgColor,
                    padding: `${w.paddingDp}px`,
                    margin: `${Math.min(10, w.marginDp)}px 0`,
                    borderRadius: `${w.cornerRadiusDp}px`,
                    border:
                      w.strokeWidthDp > 0
                        ? `${w.strokeWidthDp}px solid ${w.strokeColor}`
                        : '1px dashed rgba(0,245,212,0.2)',
                  }}
                >
                  {w.type === 'ProgressBar' || w.type === 'SeekBar' ? (
                    <div className="w-full">
                      <div className="flex justify-between text-[10px] font-mono text-[#00f5d4] mb-1">
                        <span>{w.text}</span>
                        <span>{w.progress}%</span>
                      </div>
                      <div className="h-2.5 w-full rounded-full bg-black/60 overflow-hidden relative flex items-center">
                        <div
                          className="h-full bg-gradient-to-r from-[#00f5d4] to-[#00ff88]"
                          style={{ width: `${w.progress}%` }}
                        />
                      </div>
                    </div>
                  ) : (
                    <span
                      className={`${
                        w.type === 'Button' ? 'w-full text-center' : ''
                      } font-bold truncate`}
                      style={{
                        color: w.textColor,
                        fontSize: `${Math.min(22, w.textSizeSp)}px`,
                      }}
                    >
                      {w.text}
                    </span>
                  )}

                  {w.type === 'Switch' && (
                    <div
                      className={`w-10 h-5 rounded-full border flex items-center px-0.5 shrink-0 ml-2 ${
                        w.checked
                          ? 'bg-[#00f5d4]/30 border-[#00f5d4] justify-end'
                          : 'bg-slate-800 border-slate-600 justify-start'
                      }`}
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full ${
                          w.checked ? 'bg-[#00f5d4]' : 'bg-slate-400'
                        }`}
                      />
                    </div>
                  )}

                  {w.type === 'CheckBox' && (
                    <div
                      className={`w-5 h-5 rounded border flex items-center justify-center text-[11px] font-bold shrink-0 ml-2 ${
                        w.checked
                          ? 'bg-[#00ff88] border-[#00ff88] text-[#041014]'
                          : 'border-slate-500 text-transparent'
                      }`}
                    >
                      ✓
                    </div>
                  )}

                  {w.type === 'RadioButton' && (
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ml-2 ${
                        w.checked ? 'border-[#ffd166]' : 'border-slate-500'
                      }`}
                    >
                      {w.checked && (
                        <div className="w-2.5 h-2.5 rounded-full bg-[#ffd166]" />
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Selected Widget Full Inspector */}
      {selectedWidget && (
        <div
          className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}
        >
          <div className="flex items-center justify-between gap-1 flex-wrap">
            <span className="text-xs font-extrabold text-[#00ff88]">
              ✏️ Editing: {selectedWidget.type}
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => moveSelectedWidget(-1)}
                className="px-2 py-1 rounded-lg border border-[#00f5d4]/50 bg-[#0d1f25] text-[10px] font-bold text-white"
                title="Move Up"
              >
                ↑ Up
              </button>
              <button
                type="button"
                onClick={() => moveSelectedWidget(1)}
                className="px-2 py-1 rounded-lg border border-[#00f5d4]/50 bg-[#0d1f25] text-[10px] font-bold text-white"
                title="Move Down"
              >
                ↓ Down
              </button>
              <button
                type="button"
                onClick={duplicateSelectedWidget}
                className="px-2 py-1 rounded-lg border border-[#00ff88]/50 bg-[#0b2822] text-[10px] font-bold text-[#00ff88]"
              >
                ❐ Copy
              </button>
              <button
                type="button"
                onClick={removeSelectedWidget}
                className="px-2 py-1 rounded-lg border border-[#ff2a85]/60 bg-[#1a0d14] text-[10px] font-bold text-[#ff2a85]"
              >
                ✕ Delete
              </button>
            </div>
          </div>

          <div>
            <label className="text-[11px] text-slate-300 font-semibold block mb-1">
              Widget Text / Label / Hint
            </label>
            <input
              type="text"
              value={selectedWidget.text}
              onChange={(e) => updateSelectedWidget({ text: e.target.value })}
              className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-bold text-white"
            />
          </div>

          {/* Switch / CheckBox / RadioButton Checked Toggle */}
          {(selectedWidget.type === 'Switch' ||
            selectedWidget.type === 'CheckBox' ||
            selectedWidget.type === 'RadioButton') && (
            <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
              <input
                type="checkbox"
                checked={selectedWidget.checked}
                onChange={(e) =>
                  updateSelectedWidget({ checked: e.target.checked })
                }
                className="w-4 h-4 accent-[#00ff88]"
              />
              <span>Default Checked / Enabled (ON)</span>
            </label>
          )}

          {/* SeekBar / ProgressBar Value Slider */}
          {(selectedWidget.type === 'SeekBar' ||
            selectedWidget.type === 'ProgressBar') && (
            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Default Progress / Slider Value ({selectedWidget.progress}%)
              </label>
              <input
                type="range"
                min={0}
                max={100}
                value={selectedWidget.progress}
                onChange={(e) =>
                  updateSelectedWidget({ progress: Number(e.target.value) })
                }
                className="w-full"
              />
            </div>
          )}

          {/* Widget Text Color & Background Color */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Text Color
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={
                    selectedWidget.textColor.startsWith('#')
                      ? selectedWidget.textColor.slice(0, 7)
                      : '#00F5D4'
                  }
                  onChange={(e) =>
                    updateSelectedWidget({
                      textColor: e.target.value.toUpperCase(),
                    })
                  }
                  className="w-8 h-8 rounded cursor-pointer bg-transparent border border-white/30"
                />
                <input
                  type="text"
                  value={selectedWidget.textColor}
                  onChange={(e) =>
                    updateSelectedWidget({ textColor: e.target.value })
                  }
                  className="flex-1 rounded-lg border border-[#00f5d4]/40 bg-[#060f12] px-2 py-1.5 text-[11px] font-mono text-white"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Background Color
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  value={
                    selectedWidget.bgColor.startsWith('#')
                      ? selectedWidget.bgColor.slice(0, 7)
                      : '#0D2228'
                  }
                  onChange={(e) =>
                    updateSelectedWidget({
                      bgColor: e.target.value.toUpperCase(),
                    })
                  }
                  className="w-8 h-8 rounded cursor-pointer bg-transparent border border-white/30"
                />
                <input
                  type="text"
                  value={selectedWidget.bgColor}
                  onChange={(e) =>
                    updateSelectedWidget({ bgColor: e.target.value })
                  }
                  className="flex-1 rounded-lg border border-[#00f5d4]/40 bg-[#060f12] px-2 py-1.5 text-[11px] font-mono text-white"
                />
              </div>
            </div>
          </div>

          {/* Quick Color Swatches for Selected Widget */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[10px] text-slate-400 mr-1">Quick BG:</span>
            <button
              type="button"
              onClick={() => updateSelectedWidget({ bgColor: 'transparent' })}
              className="px-2 py-0.5 rounded border border-slate-600 bg-black/40 text-[10px] font-mono text-slate-300"
            >
              None
            </button>
            {QUICK_SWATCHES.map((hex) => (
              <button
                key={hex}
                type="button"
                onClick={() => updateSelectedWidget({ bgColor: hex })}
                className="w-5 h-5 rounded-full border border-white/40"
                style={{ backgroundColor: hex }}
                title={hex}
              />
            ))}
          </div>

          {/* Sliders: Text Size, Padding, Corner Radius, Border Stroke */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Text Size ({selectedWidget.textSizeSp}sp)
              </label>
              <input
                type="range"
                min={11}
                max={28}
                value={selectedWidget.textSizeSp}
                onChange={(e) =>
                  updateSelectedWidget({ textSizeSp: Number(e.target.value) })
                }
                className="w-full"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Padding ({selectedWidget.paddingDp}dp)
              </label>
              <input
                type="range"
                min={4}
                max={28}
                value={selectedWidget.paddingDp}
                onChange={(e) =>
                  updateSelectedWidget({ paddingDp: Number(e.target.value) })
                }
                className="w-full"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Corner Radius ({selectedWidget.cornerRadiusDp}dp)
              </label>
              <input
                type="range"
                min={0}
                max={30}
                value={selectedWidget.cornerRadiusDp}
                onChange={(e) =>
                  updateSelectedWidget({
                    cornerRadiusDp: Number(e.target.value),
                  })
                }
                className="w-full"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-300 font-semibold block mb-1">
                Border Stroke ({selectedWidget.strokeWidthDp}dp)
              </label>
              <input
                type="range"
                min={0}
                max={6}
                value={selectedWidget.strokeWidthDp}
                onChange={(e) =>
                  updateSelectedWidget({
                    strokeWidthDp: Number(e.target.value),
                  })
                }
                className="w-full"
              />
            </div>
          </div>
        </div>
      )}

      {/* Container & Add Widget Controls */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="text-xs font-bold text-white mb-2">
          3. + Add Android UI Widget to Layout
        </div>
        <div className="grid grid-cols-3 gap-2 mb-3.5">
          {(
            [
              'TextView',
              'Button',
              'EditText',
              'Switch',
              'CheckBox',
              'RadioButton',
              'SeekBar',
              'ProgressBar',
              'CardView',
            ] as const
          ).map((wType) => (
            <button
              key={wType}
              type="button"
              onClick={() => addWidget(wType)}
              className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-[#00f5d4] ${microClass}`}
            >
              + {wType}
            </button>
          ))}
        </div>

        <div className="text-xs font-bold text-white mb-2 pt-2 border-t border-[#00f5d4]/20">
          Root Layout Container &amp; Background
        </div>
        <div className="grid grid-cols-2 gap-2 mb-3">
          {(
            [
              'LinearLayout',
              'RelativeLayout',
              'FrameLayout',
              'ScrollView',
            ] as const
          ).map((container) => (
            <button
              key={container}
              type="button"
              onClick={() => {
                setRootContainer(container);
                setPackageReady(false);
              }}
              className={`py-2 rounded-xl border text-xs font-bold ${microClass} ${
                rootContainer === container
                  ? 'border-[#00ff88] bg-[#0d332a] text-[#00ff88]'
                  : 'border-[#00f5d4]/40 bg-[#0d1c21] text-slate-200'
              }`}
            >
              {container}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <div>
            <label className="text-[11px] text-slate-300 font-semibold block mb-1">
              Layout Background Color
            </label>
            <div className="flex items-center gap-1.5">
              <input
                type="color"
                value={rootBg.startsWith('#') ? rootBg.slice(0, 7) : '#081418'}
                onChange={(e) => {
                  setRootBg(e.target.value.toUpperCase());
                  setPackageReady(false);
                }}
                className="w-8 h-8 rounded cursor-pointer bg-transparent border border-white/30"
              />
              <input
                type="text"
                value={rootBg}
                onChange={(e) => {
                  setRootBg(e.target.value);
                  setPackageReady(false);
                }}
                className="flex-1 rounded-lg border border-[#00f5d4]/40 bg-[#060f12] px-2 py-1.5 text-[11px] font-mono text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] text-slate-300 font-semibold block mb-1">
              Layout Border Color
            </label>
            <div className="flex items-center gap-1.5">
              <input
                type="color"
                value={
                  rootStrokeColor.startsWith('#')
                    ? rootStrokeColor.slice(0, 7)
                    : '#00F5D4'
                }
                onChange={(e) => {
                  setRootStrokeColor(e.target.value.toUpperCase());
                  setPackageReady(false);
                }}
                className="w-8 h-8 rounded cursor-pointer bg-transparent border border-white/30"
              />
              <input
                type="text"
                value={rootStrokeColor}
                onChange={(e) => {
                  setRootStrokeColor(e.target.value);
                  setPackageReady(false);
                }}
                className="flex-1 rounded-lg border border-[#00f5d4]/40 bg-[#060f12] px-2 py-1.5 text-[11px] font-mono text-white"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Build & Export Package (Full Pure Layout Smali Inside classes2.dex + classes.dex + GUIDE.txt) */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-white">
            ⚡ Build Pure Layout DEX Package
          </span>
          <span className="text-[10px] font-mono text-[#00ff88]">
            No Popup Dialog!
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mb-3">
          Compiles your complete {rootContainer} and all {widgets.length} widgets
          as a 100% pure Android Layout inside{' '}
          <span className="text-[#00f5d4] font-mono">classes2.dex</span> &amp;{' '}
          <span className="text-white font-mono">classes.dex</span> (
          <span className="text-white font-mono">
            Lcom/nsmods/xmlcreator/NsModsLayout;
          </span>
          ) + Bangla &amp; English{' '}
          <span className="text-[#00ff88] font-mono">GUIDE.txt</span>. Zero
          AlertDialog popup, zero Join Telegram / Continue buttons!
        </p>

        <button
          type="button"
          onClick={handleCompileLayoutPackage}
          className={`w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d262e] text-xs font-extrabold text-white uppercase tracking-wider mb-3 flex items-center justify-center gap-2 ${microClass}`}
        >
          <span className="text-[#ffd166]">⚡</span>
          <span>Generate Pure Layout Package (classes2.dex + GUIDE)</span>
        </button>

        {(compiling || packageReady) && (
          <div className="space-y-3">
            <ConversionShaderView
              shaderId={1}
              sourceLabel="PURE LAYOUT AST"
              targetLabel="CLASSES2.DEX"
              progress={compileProgress}
              compact
            />

            {packageReady && compiledLayoutPkg && (
              <div className="rounded-xl border border-[#00ff88]/60 bg-[#071915] p-3.5 space-y-2.5">
                <div className="text-center text-xs font-bold text-[#00ff88]">
                  ✓ Pure Layout classes2.dex Ready ({widgets.length} Widgets
                  Compiled Inside!)
                </div>
                <div className="text-center text-[11px] font-mono text-slate-300">
                  • Pure Layout (No Popup Dialog, No Join Telegram!) • GUIDE.txt
                </div>

                <button
                  type="button"
                  onClick={handleDownloadLayoutDex2}
                  className={`w-full py-3 rounded-xl border-2 border-[#00ff88] bg-[#0b2e25] text-xs font-extrabold text-[#00ff88] flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>⚡</span>
                  <span>Download classes2.dex (Direct APK Add — No Conflict!)</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadLayoutZip}
                  className={`w-full py-3 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>📦</span>
                  <span>
                    Download Complete ZIP (classes2.dex + classes.dex + GUIDE)
                  </span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handleDownloadLayoutDex}
                    className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white ${microClass}`}
                  >
                    ⬇ classes.dex
                  </button>
                  <button
                    type="button"
                    onClick={handleDownloadLayoutGuide}
                    className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white ${microClass}`}
                  >
                    📄 GUIDE.txt
                  </button>
                </div>

                {/* 1-Line Smali Hooks */}
                <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-2.5 space-y-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00ff88]">
                        1) RECOMMENDED 1-LINE HOOK IN MAINACTIVITY-&gt;ONCREATE:
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(
                            compiledLayoutPkg.primaryHook
                          );
                          onShowToast(
                            'Hook Copied!',
                            'Paste inside MainActivity->onCreate'
                          );
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00ff88]/60 text-[10px] font-bold text-[#00ff88]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {compiledLayoutPkg.primaryHook}
                    </code>
                  </div>

                  <div className="pt-1 border-t border-[#00f5d4]/20">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00f5d4]">
                        2) DIRECT SYNCHRONOUS ACTIVITY INJECTION (Register p0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(
                            compiledLayoutPkg.tertiaryHook
                          );
                          onShowToast(
                            'Hook Copied!',
                            'Activity layout hook copied.'
                          );
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00f5d4]/60 text-[10px] font-bold text-[#00f5d4]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {compiledLayoutPkg.tertiaryHook}
                    </code>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSmaliPreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00f5d4]/40 bg-[#0a181d] text-[11px] font-bold text-[#00f5d4]"
                  >
                    {showSmaliPreview
                      ? '▲ Hide Smali Code'
                      : '▼ View Smali in DEX'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGuidePreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00ff88]/40 bg-[#0a181d] text-[11px] font-bold text-[#00ff88]"
                  >
                    {showGuidePreview
                      ? '▲ Hide Guide Text'
                      : '📖 View GUIDE.txt'}
                  </button>
                </div>

                {showSmaliPreview && (
                  <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00f5d4]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-[#00ff88] leading-relaxed select-all">
                    {compiledLayoutPkg.smaliPreview}
                  </pre>
                )}

                {showGuidePreview && (
                  <pre className="max-h-60 overflow-y-auto rounded-xl border border-[#00ff88]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-slate-200 leading-relaxed select-all whitespace-pre-wrap">
                    {compiledLayoutPkg.guideText}
                  </pre>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Generated Layout XML */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 ${glowClass}`}>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-bold text-white">
            Generated Layout XML Code
          </span>
          <span className="text-[10px] font-mono text-[#00ff88]">
            💡 For MT Manager, use classes2.dex above!
          </span>
        </div>
        <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00f5d4]/50 bg-[#050d10] p-3 font-mono text-xs text-[#98f5e1]">
          {xmlCode}
        </pre>

        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(xmlCode);
              onShowToast('Layout XML Copied!', 'Copied to clipboard.');
            }}
            className={`py-3 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            COPY XML CODE
          </button>
          <button
            type="button"
            onClick={handleDownloadLayoutZip}
            className={`py-3 rounded-xl border border-[#00ff88]/70 bg-[#0b2e25] text-xs font-bold text-[#00ff88] ${microClass}`}
          >
            DOWNLOAD DEX ZIP
          </button>
        </div>
      </div>
    </div>
  );
};
