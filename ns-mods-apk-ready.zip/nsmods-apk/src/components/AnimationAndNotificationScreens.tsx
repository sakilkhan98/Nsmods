import JSZip from 'jszip';
import React, { useEffect, useMemo, useState } from 'react';
import { TypingConfig } from '../types/appTypes';
import {
  DexDialogConfig,
  compileRealDalvikDex,
  generateDisassembledSmaliText,
  normalizeMediaUrl,
  normalizeRemoteJsonUrl,
} from '../utils/dexCompiler';
import {
  buildUniversalModdingGuide,
  generateRemoteUpdateJsonConfig,
  generateTextAnimationZip,
  triggerBlobDownload,
} from '../utils/packageGenerator';
import { AnimatedText } from './AnimatedText';
import { ConversionShaderView } from './ConversionShaderView';
import { ColorPickerModal } from './XmlCustomModals';

interface CommonToolProps {
  activeShaderId: number;
  typingConfig: TypingConfig;
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onSaveHistory: (title: string, code: string) => void;
  onShowToast: (title: string, subtitle: string) => void;
}

/* ============================================================================
   1. ANDROID ANIMATION MAKER
============================================================================ */

const ANDROID_ANIM_TYPES = [
  'Fade',
  'Slide',
  'Scale',
  'Zoom',
  'Rotate',
  'Bounce',
  'Shake',
  'Pulse',
  'Blink',
  'Flip',
  'Swing',
  'Elastic',
] as const;

export const AndroidAnimationMakerScreen: React.FC<CommonToolProps> = ({
  activeShaderId,
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [animType, setAnimType] = useState<(typeof ANDROID_ANIM_TYPES)[number]>('Bounce');
  const [duration, setDuration] = useState(500);
  const [startDelay, setStartDelay] = useState(0);
  const [intensity, setIntensity] = useState(100);
  const [direction, setDirection] = useState<'IN / UP' | 'OUT / DOWN' | 'LEFT' | 'RIGHT'>('IN / UP');
  const [easing, setEasing] = useState<'OVERSHOOT' | 'BOUNCE' | 'LINEAR' | 'ACCELERATE'>('OVERSHOOT');
  const [repeat, setRepeat] = useState<'NONE' | 'INFINITE' | '2 TIMES'>('NONE');
  const [repeatMode, setRepeatMode] = useState<'REVERSE' | 'RESTART'>('REVERSE');

  const [chain, setChain] = useState<Array<{ type: string; duration: number }>>([
    { type: 'Fade', duration: 400 },
    { type: 'Scale', duration: 450 },
    { type: 'Rotate', duration: 500 },
    { type: 'Bounce', duration: 550 },
  ]);

  const [animTick, setAnimTick] = useState(0);
  const [isPlayingChain, setIsPlayingChain] = useState(false);

  // Package compiler state
  const [compiling, setCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [packageReady, setPackageReady] = useState(false);
  const [showSmaliPreview, setShowSmaliPreview] = useState(false);
  const [showGuidePreview, setShowGuidePreview] = useState(false);

  useEffect(() => {
    setAnimTick((t) => t + 1);
  }, [animType, duration]);

  const handlePlayChain = () => {
    if (chain.length === 0) return;
    setIsPlayingChain(true);
    let idx = 0;
    const step = () => {
      if (idx >= chain.length) {
        setIsPlayingChain(false);
        return;
      }
      setAnimType(chain[idx].type as (typeof ANDROID_ANIM_TYPES)[number]);
      setDuration(chain[idx].duration);
      setAnimTick((t) => t + 1);
      idx++;
      setTimeout(step, 520);
    };
    step();
  };

  const getPreviewTransform = (): React.CSSProperties => {
    const scaleFactor = intensity / 100;
    switch (animType) {
      case 'Fade':
        return { opacity: animTick % 2 === 0 ? 1 : 0.72 };
      case 'Slide':
        return { transform: `translateY(${animTick % 2 === 0 ? 0 : -8 * scaleFactor}px)` };
      case 'Scale':
      case 'Zoom':
        return { transform: `scale(${animTick % 2 === 0 ? 1 : 1.08 * scaleFactor})` };
      case 'Rotate':
        return { transform: `rotate(${animTick % 2 === 0 ? 0 : 8 * scaleFactor}deg)` };
      case 'Bounce':
      case 'Elastic':
        return { transform: `translateY(${animTick % 2 === 0 ? 0 : -10}px) scale(1.03)` };
      case 'Shake':
        return { transform: `translateX(${animTick % 2 === 0 ? -6 : 6}px)` };
      case 'Flip':
        return { transform: `rotateX(${animTick % 2 === 0 ? 0 : 35}deg)` };
      case 'Swing':
        return { transform: `rotate(${animTick % 2 === 0 ? -5 : 5}deg)` };
      default:
        return {};
    }
  };

  const buildAnimPackageData = () => {
    const className = 'NsModsAnimationHelper';
    const dexCfg: DexDialogConfig = {
      className,
      entryMethodName: 'animateView',
      title: `${animType} Animation (${duration}ms)`,
      message: '',
      positiveBtnText: '',
      negativeBtnText: '',
      telegramUrl: 'https://t.me/Sharechat_ns_098',
      bgColorHex: '#091519',
      accentColorHex: '#00F5D4',
      textColorHex: '#E6FFFA',
      cornerRadiusDp: 16,
      strokeWidthDp: 2,
      extraConfigTag: `ANDROID_ANIM_${animType}`,
      animDurationMs: duration,
      animStartDelayMs: startDelay,
      executionMode: 'layout_overlay',
    };

    const dexBytes = compileRealDalvikDex(dexCfg);
    const smaliPreview = generateDisassembledSmaliText(dexCfg);
    const primaryHook = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsAnimationHelper;->show(Landroid/content/Context;)V`;
    const secondaryHook = `invoke-static {v0}, Lcom/nsmods/xmlcreator/NsModsAnimationHelper;->animateView(Landroid/view/View;)V`;

    const guideText = buildUniversalModdingGuide({
      toolTitle: `Android Animation Maker (${animType} • ${duration}ms)`,
      className,
      primaryHook,
      secondaryHook,
      descriptionEn: 'Animate Any View in Register v0 OR Inject Animated Layout View',
      descriptionBn: 'যেকোনো View/Button (v0) অথবা স্ক্রিনে অ্যানিমেশন যুক্ত করা (কোনো পপআপ ডায়ালগ ছাড়া!)',
      compiledSmaliPreview: smaliPreview,
      isPureLayout: true,
    });

    return { dexBytes, smaliPreview, guideText, primaryHook, secondaryHook };
  };

  const handleGeneratePackage = () => {
    setCompiling(true);
    setPackageReady(false);
    setCompileProgress(5);
    let p = 5;
    const id = window.setInterval(() => {
      p += 16;
      if (p >= 100) {
        p = 100;
        setCompileProgress(100);
        clearInterval(id);
        setPackageReady(true);
        setCompiling(false);
        onShowToast(
          '100% Crash-Free Package Ready',
          'classes.dex (Full Smali inside — No res/ folder!) & GUIDE.txt ready!'
        );
      } else {
        setCompileProgress(p);
      }
    }, 95);
  };

  const handleDownloadAnimZip = async () => {
    const { dexBytes, guideText, secondaryHook } = buildAnimPackageData();
    const zip = new JSZip();
    zip.file('classes2.dex', dexBytes);
    zip.file('classes.dex', dexBytes);
    zip.file('GUIDE.txt', guideText);
    const blob = await zip.generateAsync({ type: 'blob' });
    triggerBlobDownload(blob, 'NsMods_AndroidAnimation_Package.zip');
    onSaveHistory(`Android Animation (${animType})`, secondaryHook);
    onShowToast(
      'ZIP Downloaded',
      'Saved NsMods_AndroidAnimation_Package.zip (classes2.dex + classes.dex + GUIDE.txt)'
    );
  };

  const pkgPreview = useMemo(
    () => buildAnimPackageData(),
    [animType, duration, startDelay, intensity, direction, easing, repeat, repeatMode, chain]
  );

  return (
    <div className="flex flex-col pb-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-sm font-extrabold text-center text-white leading-tight">
          <AnimatedText text="Android Animation Maker" config={typingConfig} />
        </h1>
        <button
          type="button"
          onClick={() => {
            setAnimType('Fade');
            setDuration(500);
            setStartDelay(0);
            setIntensity(100);
            setPackageReady(false);
            onShowToast('Reset Complete', 'Animation parameters reset.');
          }}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ↻ Reset
        </button>
      </div>

      {/* Sticky Live Preview Stage */}
      <div
        className={`sticky top-2 z-20 rounded-2xl border-2 bg-[#081317]/95 backdrop-blur-md p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="h-24 rounded-xl border border-[#00f5d4]/30 bg-[#050d10] flex items-center justify-center overflow-hidden mb-3">
          <div
            key={animTick}
            className="px-7 py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0b2229] text-center shadow-[0_0_20px_rgba(0,245,212,0.3)] transition-all duration-300"
            style={getPreviewTransform()}
          >
            <div className="text-sm font-extrabold text-[#00f5d4] tracking-wider">
              NS MODS UI
            </div>
            <div className="text-[11px] font-mono text-slate-300 mt-0.5">
              {animType} • {duration}ms
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => setAnimTick((t) => t + 1)}
            className={`py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d242b] text-xs font-bold text-white ${microClass}`}
          >
            PLAY STEP
          </button>
          <button
            type="button"
            onClick={handlePlayChain}
            className={`py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d242b] text-xs font-bold text-white ${microClass}`}
          >
            {isPlayingChain ? 'PLAYING...' : 'PLAY CHAIN'}
          </button>
          <button
            type="button"
            onClick={() => setIsPlayingChain(false)}
            className={`py-2.5 rounded-xl border border-[#ff2a85]/70 bg-[#1a0d14] text-xs font-bold text-[#ff2a85] ${microClass}`}
          >
            STOP
          </button>
        </div>
      </div>

      {/* Select Animation Type */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-2.5">
          <AnimatedText text="Select Animation Type" config={typingConfig} />
        </div>
        <div className="grid grid-cols-4 gap-2">
          {ANDROID_ANIM_TYPES.map((t) => {
            const active = animType === t;
            return (
              <button
                key={t}
                type="button"
                onClick={() => {
                  setAnimType(t);
                  setAnimTick((x) => x + 1);
                }}
                className={`py-2.5 rounded-xl border text-xs font-bold transition-all ${microClass} ${
                  active
                    ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4] shadow-[0_0_10px_rgba(0,245,212,0.3)]'
                    : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
                }`}
              >
                {t}
              </button>
            );
          })}
        </div>
      </div>

      {/* Animation Parameters Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}>
        <div className="text-xs font-bold text-white">
          <AnimatedText text="Animation Parameters" config={typingConfig} />
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Duration</span>
            <span className="font-mono font-bold text-[#00f5d4]">{duration} ms</span>
          </div>
          <input
            type="range"
            min={100}
            max={2500}
            step={50}
            value={duration}
            onChange={(e) => setDuration(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Start Delay</span>
            <span className="font-mono font-bold text-[#00f5d4]">{startDelay} ms</span>
          </div>
          <input
            type="range"
            min={0}
            max={1500}
            step={50}
            value={startDelay}
            onChange={(e) => setStartDelay(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Intensity / Range</span>
            <span className="font-mono font-bold text-[#00f5d4]">{intensity}%</span>
          </div>
          <input
            type="range"
            min={20}
            max={200}
            step={10}
            value={intensity}
            onChange={(e) => setIntensity(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            type="button"
            onClick={() =>
              setDirection((d) =>
                d === 'IN / UP'
                  ? 'OUT / DOWN'
                  : d === 'OUT / DOWN'
                  ? 'LEFT'
                  : d === 'LEFT'
                  ? 'RIGHT'
                  : 'IN / UP'
              )
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            DIR: {direction}
          </button>
          <button
            type="button"
            onClick={() =>
              setEasing((e) =>
                e === 'OVERSHOOT'
                  ? 'BOUNCE'
                  : e === 'BOUNCE'
                  ? 'LINEAR'
                  : e === 'LINEAR'
                  ? 'ACCELERATE'
                  : 'OVERSHOOT'
              )
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            EASE: {easing}
          </button>
          <button
            type="button"
            onClick={() =>
              setRepeat((r) =>
                r === 'NONE' ? 'INFINITE' : r === 'INFINITE' ? '2 TIMES' : 'NONE'
              )
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            REPEAT: {repeat}
          </button>
          <button
            type="button"
            onClick={() =>
              setRepeatMode((m) => (m === 'REVERSE' ? 'RESTART' : 'REVERSE'))
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            MODE: {repeatMode}
          </button>
        </div>
      </div>

      {/* Animation Sequence / Chain Builder Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-2">
          <AnimatedText
            text="Animation Sequence / Chain Builder"
            config={typingConfig}
          />
        </div>

        <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-3 font-mono text-xs text-[#98f5e1] mb-3">
          {chain.length === 0
            ? 'Chain is empty. Tap + ADD TO CHAIN.'
            : chain.map((c) => `${c.type} (${c.duration}ms)`).join(' → ')}
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() =>
              setChain((prev) => [...prev, { type: animType, duration }])
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            + ADD TO CHAIN
          </button>
          <button
            type="button"
            onClick={() =>
              setChain([
                { type: 'Fade', duration: 400 },
                { type: 'Scale', duration: 450 },
                { type: 'Rotate', duration: 500 },
                { type: 'Bounce', duration: 550 },
              ])
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            PRESET COMBO
          </button>
          <button
            type="button"
            onClick={() => setChain((prev) => prev.slice(0, -1))}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            REMOVE LAST
          </button>
          <button
            type="button"
            onClick={() => setChain([])}
            className={`py-2.5 rounded-xl border border-[#ff2a85]/60 bg-[#1a0d14] text-xs font-bold text-[#ff2a85] ${microClass}`}
          >
            CLEAR CHAIN
          </button>
        </div>
      </div>

      {/* Build & Export Package Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-1">
          Build &amp; Export Package (100% Crash-Free classes.dex + GUIDE.txt)
        </div>
        <p className="text-[11px] text-slate-400 mb-3">
          Compiles your Android Animation directly as Dalvik Smali bytecode
          inside <span className="text-[#00f5d4] font-mono">classes.dex</span>{' '}
          + step-by-step Bangla &amp; English{' '}
          <span className="text-[#00ff88] font-mono">GUIDE.txt</span> (No{' '}
          <span className="text-[#ff2a85] font-mono">res/</span> folder needed!).
        </p>

        <button
          type="button"
          onClick={handleGeneratePackage}
          className={`w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d262e] text-xs font-extrabold text-white uppercase tracking-wider mb-3 ${microClass}`}
        >
          ⚡ GENERATE PACKAGE (CLASSES.DEX + GUIDE.TXT)
        </button>

        {(compiling || packageReady) && (
          <div className="space-y-3">
            <ConversionShaderView
              shaderId={activeShaderId}
              sourceLabel="ANIMATION AST"
              targetLabel="CLASSES.DEX"
              progress={compileProgress}
              compact
            />

            {packageReady && (
              <div className="rounded-xl border border-[#00ff88]/60 bg-[#071915] p-3.5 space-y-2.5">
                <div className="text-center text-xs font-bold text-[#00ff88]">
                  ✓ 100% Crash-Free Animation Package Ready!
                </div>
                <div className="text-center text-[11px] font-mono text-slate-300">
                  • classes.dex (Lcom/nsmods/xmlcreator/NsModsAnimationHelper;) • GUIDE.txt
                </div>

                <button
                  type="button"
                  onClick={() => {
                    triggerBlobDownload(
                      new Blob([pkgPreview.dexBytes.buffer as ArrayBuffer], {
                        type: 'application/octet-stream',
                      }),
                      'classes.dex'
                    );
                    onShowToast(
                      'Downloaded classes.dex',
                      'Open in MT Manager Dex Editor Plus to view Smali!'
                    );
                  }}
                  className="w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d242b] text-xs font-bold text-white"
                >
                  ⚡ Download classes.dex (Full Smali Inside)
                </button>
                <button
                  type="button"
                  onClick={handleDownloadAnimZip}
                  className="w-full py-2.5 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-xs font-bold text-[#00ff88]"
                >
                  📦 Download Complete ZIP (classes.dex + GUIDE.txt)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    triggerBlobDownload(
                      new Blob([pkgPreview.guideText], {
                        type: 'text/plain;charset=utf-8',
                      }),
                      'GUIDE.txt'
                    );
                    onShowToast('GUIDE.txt Downloaded', 'Bangla & English guide saved!');
                  }}
                  className="w-full py-2 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-white"
                >
                  📄 Download GUIDE.txt
                </button>

                {/* 1-Line Smali Hooks */}
                <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-2.5 space-y-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00f5d4]">
                        1) SHOW ANIMATED DIALOG IN MAINACTIVITY (Register p0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(pkgPreview.primaryHook);
                          onShowToast('Hook Copied!', 'Paste inside MainActivity->onCreate');
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00f5d4]/60 text-[10px] font-bold text-[#00f5d4]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {pkgPreview.primaryHook}
                    </code>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00ff88]">
                        2) ANIMATE ANY VIEW / BUTTON (Register v0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(pkgPreview.secondaryHook);
                          onShowToast('Hook Copied!', 'Paste on any View in Smali.');
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00ff88]/60 text-[10px] font-bold text-[#00ff88]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {pkgPreview.secondaryHook}
                    </code>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSmaliPreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00f5d4]/40 bg-[#0a181d] text-[11px] font-bold text-[#00f5d4]"
                  >
                    {showSmaliPreview ? '▲ Hide Smali' : '▼ View Smali in DEX'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGuidePreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00ff88]/40 bg-[#0a181d] text-[11px] font-bold text-[#00ff88]"
                  >
                    {showGuidePreview ? '▲ Hide Guide' : '📖 View GUIDE.txt'}
                  </button>
                </div>

                {showSmaliPreview && (
                  <pre className="max-h-52 overflow-y-auto rounded-xl border border-[#00f5d4]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-[#00ff88] leading-relaxed select-all">
                    {pkgPreview.smaliPreview}
                  </pre>
                )}

                {showGuidePreview && (
                  <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00ff88]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-slate-200 leading-relaxed select-all whitespace-pre-wrap">
                    {pkgPreview.guideText}
                  </pre>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
   2. TEXT ANIMATION MAKER
============================================================================ */

const TEXT_ANIM_EFFECTS = [
  'Typing',
  'Letters',
  'Fade',
  'Wave',
  'Bounce',
  'Shake',
  'Flicker',
  'Glow',
  'Neon',
  'RGB',
  'Gradient',
  'Zoom',
  'Rotate',
  'Slide',
  'Char Rev',
  'Word Rev',
] as const;

export const TextAnimationMakerScreen: React.FC<CommonToolProps> = ({
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [customText, setCustomText] = useState('NS MODS XML CREATOR');
  const [effect, setEffect] = useState<(typeof TEXT_ANIM_EFFECTS)[number]>('Wave');
  const [fontStyle, setFontStyle] = useState<'BOLD' | 'NORMAL' | 'ITALIC'>('BOLD');
  const [paused, setPaused] = useState(false);
  const [replayCount, setReplayCount] = useState(0);

  const [textSizeSp, setTextSizeSp] = useState(22);
  const [cycleDurationMs, setCycleDurationMs] = useState(1600);
  const [strokeWidthPx, setStrokeWidthPx] = useState(0);
  const [glowRadiusPx, setGlowRadiusPx] = useState(12);

  const [textColor, setTextColor] = useState('#00E500');
  const [gradientColor, setGradientColor] = useState('#FF0055');
  const [strokeColor, setStrokeColor] = useState('#FFFFFF');
  const [glowColor, setGlowColor] = useState('#00F5D4');
  const [gradientShaderOn, setGradientShaderOn] = useState(true);

  const [colorModalKey, setColorModalKey] = useState<
    null | 'text' | 'gradient' | 'stroke' | 'glow'
  >(null);

  const [compiling, setCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [packageReady, setPackageReady] = useState(false);
  const [showSmaliPreview, setShowSmaliPreview] = useState(false);
  const [showGuidePreview, setShowGuidePreview] = useState(false);
  const [compiledTextPkg, setCompiledTextPkg] = useState<{
    smaliPreview: string;
    guideText: string;
    primaryHook: string;
    secondaryHook: string;
  } | null>(null);

  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (paused) return;
    const id = window.setInterval(() => {
      setTick((t) => (t + 1) % 100);
    }, Math.max(45, Math.floor(cycleDurationMs / 24)));
    return () => clearInterval(id);
  }, [paused, cycleDurationMs, replayCount]);

  const buildCurrentPkg = () =>
    generateTextAnimationZip({
      text: customText || 'NS MODS XML CREATOR',
      effect,
      fontStyle,
      textSizeSp,
      durationMs: cycleDurationMs,
      strokeWidthPx,
      glowRadiusPx,
      textColor,
      gradientColor,
      strokeColor,
      glowColor,
      useGradientShader: gradientShaderOn,
    });

  const handleCompilePackage = async () => {
    setCompiling(true);
    setPackageReady(false);
    setCompileProgress(8);
    const pkg = await buildCurrentPkg();
    setCompiledTextPkg({
      smaliPreview: pkg.smaliPreview,
      guideText: pkg.guideText,
      primaryHook: pkg.primaryHook,
      secondaryHook: pkg.secondaryHook,
    });
    let p = 8;
    const id = window.setInterval(() => {
      p += 16;
      if (p >= 100) {
        p = 100;
        setCompileProgress(100);
        clearInterval(id);
        setCompiling(false);
        setPackageReady(true);
        onShowToast(
          '100% Crash-Free Package Ready',
          'classes.dex (Full Smali inside — No res/ folder!) & GUIDE.txt ready!'
        );
      } else {
        setCompileProgress(p);
      }
    }, 95);
  };

  const handleDownloadZip = async () => {
    const { zipBlob, fileName, secondaryHook } = await buildCurrentPkg();
    triggerBlobDownload(zipBlob, fileName);
    onSaveHistory(`Text Animation (${effect})`, secondaryHook);
    onShowToast(
      'ZIP Package Downloaded',
      `Saved ${fileName} (classes.dex + GUIDE.txt)`
    );
  };

  const handleDownloadDex = async () => {
    const { dexBlob } = await buildCurrentPkg();
    triggerBlobDownload(dexBlob, 'classes.dex');
    onShowToast(
      'classes.dex Downloaded',
      'Full Smali code is compiled inside classes.dex!'
    );
  };

  const handleDownloadGuide = async () => {
    const { guideText } = await buildCurrentPkg();
    triggerBlobDownload(
      new Blob([guideText], { type: 'text/plain;charset=utf-8' }),
      'GUIDE.txt'
    );
    onShowToast('GUIDE.txt Downloaded', 'Step-by-step Bangla & English guide saved!');
  };

  const displayChars = (customText || 'NS MODS XML CREATOR').split('');

  return (
    <div className="flex flex-col pb-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          <AnimatedText text="Text Animation Maker" config={typingConfig} />
        </h1>
        <button
          type="button"
          onClick={() => {
            setCustomText('NS MODS XML CREATOR');
            setEffect('Wave');
            setTextSizeSp(22);
            setCycleDurationMs(1600);
            setPackageReady(false);
            onShowToast('Reset Complete', 'Text animation settings reset.');
          }}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ↻ Reset
        </button>
      </div>

      {/* Sticky Live Preview Box */}
      <div
        className={`sticky top-2 z-20 rounded-2xl border-2 bg-[#081317]/95 backdrop-blur-md p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="h-24 rounded-xl border border-[#00f5d4]/40 bg-[#050d10] flex items-center justify-center overflow-hidden px-3 mb-3">
          <div
            className="flex flex-wrap items-center justify-center select-none"
            style={{
              fontSize: `${Math.min(30, textSizeSp)}px`,
              fontWeight: fontStyle === 'NORMAL' ? 500 : 800,
              fontStyle: fontStyle === 'ITALIC' ? 'italic' : 'normal',
            }}
          >
            {displayChars.map((ch, idx) => {
              if (
                effect === 'Typing' &&
                idx > (tick % (displayChars.length + 4))
              ) {
                return null;
              }
              const waveY =
                effect === 'Wave' || effect === 'Bounce'
                  ? Math.sin((tick + idx * 2) * 0.35) * 6
                  : 0;
              const shakeX =
                effect === 'Shake' ? ((tick + idx) % 2 === 0 ? -2 : 2) : 0;
              const scaleVal =
                effect === 'Zoom'
                  ? 1 + Math.sin((tick + idx) * 0.3) * 0.15
                  : 1;

              const ratio =
                ((idx + tick) % displayChars.length) /
                Math.max(1, displayChars.length);
              const charColor = gradientShaderOn
                ? ratio > 0.5
                  ? gradientColor
                  : textColor
                : textColor;

              return (
                <span
                  key={idx}
                  style={{
                    display: 'inline-block',
                    color: charColor,
                    transform: `translate(${shakeX}px, ${waveY}px) scale(${scaleVal})`,
                    textShadow:
                      glowRadiusPx > 0
                        ? `0 0 ${glowRadiusPx}px ${glowColor}`
                        : undefined,
                    WebkitTextStroke:
                      strokeWidthPx > 0
                        ? `${strokeWidthPx}px ${strokeColor}`
                        : undefined,
                    transition: 'transform 0.08s linear, color 0.15s linear',
                  }}
                >
                  {ch === ' ' ? '\u00A0' : ch}
                </span>
              );
            })}
            {effect === 'Typing' && (
              <span className="ml-0.5 text-[#a855f7] animate-pulse">█</span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          <button
            type="button"
            onClick={() => setReplayCount((c) => c + 1)}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d2228] text-xs font-bold text-white ${microClass}`}
          >
            REPLAY
          </button>
          <button
            type="button"
            onClick={() => setPaused((p) => !p)}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d2228] text-[11px] font-bold text-white leading-tight ${microClass}`}
          >
            {paused ? 'RESUME' : 'PAUSE / RESUME'}
          </button>
          <button
            type="button"
            onClick={() =>
              setFontStyle((s) =>
                s === 'BOLD' ? 'ITALIC' : s === 'ITALIC' ? 'NORMAL' : 'BOLD'
              )
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d2228] text-xs font-bold text-white ${microClass}`}
          >
            STYLE: {fontStyle}
          </button>
        </div>
      </div>

      {/* Custom Text Input */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-2">
          Custom Text Input
        </div>
        <input
          type="text"
          value={customText}
          onChange={(e) => setCustomText(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/60 bg-[#060f12] px-3.5 py-2.5 text-xs font-bold text-white focus:outline-none focus:border-[#00f5d4]"
          placeholder="NS MODS XML CREATOR"
        />
      </div>

      {/* Select Text Animation Effect */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-2.5">
          Select Text Animation Effect
        </div>
        <div className="grid grid-cols-4 gap-2">
          {TEXT_ANIM_EFFECTS.map((eff) => {
            const active = effect === eff;
            return (
              <button
                key={eff}
                type="button"
                onClick={() => setEffect(eff)}
                className={`py-2.5 px-1.5 rounded-xl border text-xs font-bold transition-all ${microClass} ${
                  active
                    ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4] shadow-[0_0_12px_rgba(0,245,212,0.3)]'
                    : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
                }`}
              >
                {eff}
              </button>
            );
          })}
        </div>
      </div>

      {/* Size, Speed, Stroke & Glow Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}>
        <div className="text-xs font-bold text-white">
          Size, Speed, Stroke &amp; Glow
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Text Size</span>
            <span className="font-mono font-bold text-[#00f5d4]">{textSizeSp} sp</span>
          </div>
          <input
            type="range"
            min={12}
            max={42}
            value={textSizeSp}
            onChange={(e) => setTextSizeSp(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">
              Animation Speed / Cycle Duration (গতি কমানো বা বাড়ানো)
            </span>
            <span className="font-mono font-bold text-[#00f5d4]">{cycleDurationMs} ms</span>
          </div>
          <div className="grid grid-cols-4 gap-1.5 mb-2">
            {[
              { label: '🐢 Ultra Slow', ms: 3400 },
              { label: '🌊 Smooth Slow', ms: 2200 },
              { label: '✨ Normal', ms: 1500 },
              { label: '⚡ Fast', ms: 800 },
            ].map((sp) => (
              <button
                key={sp.ms}
                type="button"
                onClick={() => setCycleDurationMs(sp.ms)}
                className={`py-1.5 px-1 rounded-lg border text-[10px] font-bold ${
                  cycleDurationMs === sp.ms
                    ? 'border-[#00ff88] bg-[#0b2e25] text-[#00ff88]'
                    : 'border-[#00f5d4]/30 bg-[#0d1c21] text-slate-300'
                }`}
              >
                {sp.label}
              </button>
            ))}
          </div>
          <input
            type="range"
            min={400}
            max={6000}
            step={100}
            value={cycleDurationMs}
            onChange={(e) => setCycleDurationMs(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Stroke Outline Width</span>
            <span className="font-mono font-bold text-[#00f5d4]">{strokeWidthPx} px</span>
          </div>
          <input
            type="range"
            min={0}
            max={6}
            value={strokeWidthPx}
            onChange={(e) => setStrokeWidthPx(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Shadow / Neon Glow Radius</span>
            <span className="font-mono font-bold text-[#00f5d4]">{glowRadiusPx} px</span>
          </div>
          <input
            type="range"
            min={0}
            max={28}
            value={glowRadiusPx}
            onChange={(e) => setGlowRadiusPx(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            type="button"
            onClick={() => setColorModalKey('text')}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
          >
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: textColor }} />
            <span>TEXT COLOR</span>
          </button>

          <button
            type="button"
            onClick={() => setColorModalKey('gradient')}
            className={`py-2.5 rounded-xl border border-[#ff2a85]/70 bg-[#1a0d16] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
          >
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: gradientColor }} />
            <span>GRADIENT COLOR</span>
          </button>

          <button
            type="button"
            onClick={() => setColorModalKey('stroke')}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
          >
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: strokeColor }} />
            <span>STROKE COLOR</span>
          </button>

          <button
            type="button"
            onClick={() => setColorModalKey('glow')}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
          >
            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: glowColor }} />
            <span>GLOW COLOR</span>
          </button>
        </div>

        <button
          type="button"
          onClick={() => setGradientShaderOn((v) => !v)}
          className={`w-full py-2.5 rounded-xl border text-xs font-bold ${microClass} ${
            gradientShaderOn
              ? 'border-[#00ff88] bg-[#0b2e25] text-[#00ff88]'
              : 'border-[#00f5d4]/50 bg-[#0d1f25] text-slate-300'
          }`}
        >
          GRADIENT SHADER: {gradientShaderOn ? 'ON' : 'OFF'}
        </button>
      </div>

      {/* Build & Export Package */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-1">
          Build &amp; Export Package (100% Crash-Free classes.dex + GUIDE.txt)
        </div>
        <p className="text-[11px] text-slate-400 mb-3">
          Compiles standalone{' '}
          <span className="text-[#00f5d4] font-mono">classes.dex</span> (
          <span className="text-white font-mono">
            Lcom/nsmods/xmlcreator/NsModsAnimatedTextView;
          </span>
          ) + step-by-step Bangla &amp; English{' '}
          <span className="text-[#00ff88] font-mono">GUIDE.txt</span> without
          any <span className="text-[#ff2a85] font-mono">res/</span> folder!
        </p>

        <button
          type="button"
          onClick={handleCompilePackage}
          className={`w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d262e] text-xs font-extrabold text-white mb-3 flex items-center justify-center gap-2 ${microClass}`}
        >
          <span className="text-[#ffd166]">⚡</span>
          <span>Generate Package (classes.dex + GUIDE.txt)</span>
        </button>

        {(compiling || packageReady) && (
          <div className="space-y-3">
            <ConversionShaderView
              shaderId={2}
              sourceLabel="TEXT ANIM AST"
              targetLabel="CLASSES.DEX"
              progress={compileProgress}
              compact
            />

            {packageReady && compiledTextPkg && (
              <div className="rounded-xl border border-[#00ff88]/60 bg-[#071915] p-3.5 space-y-2.5">
                <div className="text-center text-xs font-bold text-[#00ff88]">
                  ✓ 100% Crash-Free Text Animation Package Ready!
                </div>
                <div className="text-center text-[11px] font-mono text-slate-300">
                  • classes.dex (Full Compiled Dalvik Bytecode — No res/ folder!) • GUIDE.txt
                </div>

                <button
                  type="button"
                  onClick={handleDownloadDex}
                  className={`w-full py-3 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span className="text-[#ffd166]">⚡</span>
                  <span>Download classes.dex (Full Smali Inside)</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadZip}
                  className={`w-full py-3 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-xs font-bold text-[#00ff88] flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>📦</span>
                  <span>Download Complete ZIP (classes.dex + GUIDE.txt)</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadGuide}
                  className={`w-full py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>📄</span>
                  <span>Download GUIDE.txt (Bangla &amp; English Guide)</span>
                </button>

                {/* 1-Line Smali Hook Box */}
                <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-2.5 space-y-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00f5d4]">
                        1) SHOW ANIMATED DIALOG IN MAINACTIVITY (Register p0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(compiledTextPkg.primaryHook);
                          onShowToast('Hook Copied!', 'Paste inside MainActivity->onCreate');
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00f5d4]/60 text-[10px] font-bold text-[#00f5d4]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {compiledTextPkg.primaryHook}
                    </code>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-mono font-bold text-[#00ff88]">
                        2) APPLY TO ANY TEXTVIEW (Register v0):
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(compiledTextPkg.secondaryHook);
                          onShowToast('Hook Copied!', 'Paste on any TextView in Smali.');
                        }}
                        className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00ff88]/60 text-[10px] font-bold text-[#00ff88]"
                      >
                        ❐ Copy
                      </button>
                    </div>
                    <code className="block text-[10px] font-mono text-white break-all select-all">
                      {compiledTextPkg.secondaryHook}
                    </code>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSmaliPreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00f5d4]/40 bg-[#0a181d] text-[11px] font-bold text-[#00f5d4]"
                  >
                    {showSmaliPreview ? '▲ Hide Smali' : '▼ View Smali in DEX'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGuidePreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00ff88]/40 bg-[#0a181d] text-[11px] font-bold text-[#00ff88]"
                  >
                    {showGuidePreview ? '▲ Hide Guide' : '📖 View GUIDE.txt'}
                  </button>
                </div>

                {showSmaliPreview && (
                  <pre className="max-h-52 overflow-y-auto rounded-xl border border-[#00f5d4]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-[#00ff88] leading-relaxed select-all">
                    {compiledTextPkg.smaliPreview}
                  </pre>
                )}

                {showGuidePreview && (
                  <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00ff88]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-slate-200 leading-relaxed select-all whitespace-pre-wrap">
                    {compiledTextPkg.guideText}
                  </pre>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <ColorPickerModal
        isOpen={colorModalKey !== null}
        initialColor={
          colorModalKey === 'text'
            ? textColor
            : colorModalKey === 'gradient'
            ? gradientColor
            : colorModalKey === 'stroke'
            ? strokeColor
            : glowColor
        }
        onClose={() => setColorModalKey(null)}
        onSelectColor={(hex) => {
          if (colorModalKey === 'text') setTextColor(hex);
          else if (colorModalKey === 'gradient') setGradientColor(hex);
          else if (colorModalKey === 'stroke') setStrokeColor(hex);
          else if (colorModalKey === 'glow') setGlowColor(hex);
        }}
      />
    </div>
  );
};

/* ============================================================================
   3. ADVANCED DIALOG MAKER
      Supports:
      - Cyber VIP Dialog
      - iOS Glass Alert Dialog
      - Photo / Image Dialog (Custom Image URL + Gallery Upload + Built-in Presets)
      - Video / Anim Dialog (Custom MP4/WebM/GIF URL + Animated Matrix/Cyber Banner)
      - Robot Mecha AI HUD Dialog (Animated Robot Eyes & Radar Telemetry)
      - RGB Coloring Dialog (360° Rainbow RGB Spectrum Animated Border & Shimmer)
      - Update JSON Dialog (Pastebin / GitHub Raw Remote JSON Control + Generator!)
      - Mod Menu Switches Dialog
      - Key Login Dialog
============================================================================ */

type DialogModeType =
  | 'Cyber VIP'
  | 'iOS Glass'
  | 'Photo / Image'
  | 'Video / Anim'
  | 'Robot Mecha'
  | 'RGB Coloring'
  | 'Update JSON'
  | 'Mod Menu'
  | 'Key Login';

const DIALOG_MODE_CARDS: Array<{
  id: DialogModeType;
  icon: string;
  label: string;
  badge: string;
}> = [
  { id: 'Cyber VIP', icon: '👑', label: 'Cyber VIP', badge: 'NEON' },
  { id: 'iOS Glass', icon: '🍎', label: 'iOS Alert', badge: 'BLUR' },
  { id: 'Photo / Image', icon: '🖼️', label: 'Photo / Image', badge: 'BANNER' },
  { id: 'Video / Anim', icon: '🎬', label: 'Video / Anim', badge: 'MP4/GIF' },
  { id: 'Robot Mecha', icon: '🤖', label: 'Robot Mecha', badge: 'AI HUD' },
  { id: 'RGB Coloring', icon: '🌈', label: 'RGB Coloring', badge: 'SPECTRUM' },
  { id: 'Update JSON', icon: '☁️', label: 'Update JSON', badge: 'PASTEBIN' },
  { id: 'Mod Menu', icon: '🎛️', label: 'Mod Menu', badge: 'SWITCH' },
  { id: 'Key Login', icon: '🔐', label: 'Key Login', badge: 'AUTH' },
];

const BUILTIN_PHOTO_PRESETS = [
  {
    name: 'Cyber Ninja VIP',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=700&q=80',
  },
  {
    name: 'Neon Matrix Core',
    url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=700&q=80',
  },
  {
    name: 'Mecha Robot HUD',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=700&q=80',
  },
  {
    name: 'Esports Arena Gold',
    url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=700&q=80',
  },
  {
    name: 'Anime Cyber City',
    url: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=700&q=80',
  },
  {
    name: 'Royal VIP Crown',
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=700&q=80',
  },
];

const BUILTIN_VIDEO_PRESETS = [
  {
    name: 'Cyber Blaze HD (MP4)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  },
  {
    name: 'Neon Escape HD (MP4)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
  },
  {
    name: 'Action Joy Stream (MP4)',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoy.mp4',
  },
  {
    name: 'NCS Cartoon On & On (YT)',
    url: 'https://www.youtube.com/watch?v=K4DyBUG242c',
  },
];

type UpdateDialogStyleId =
  | 'cyber_neon'
  | 'royal_gold'
  | 'ios_store'
  | 'esports_hud'
  | 'hologram_3d';

const UPDATE_DIALOG_STYLE_PRESETS: Array<{
  id: UpdateDialogStyleId;
  name: string;
  badge: string;
  icon: string;
  desc: string;
  bg: string;
  accent: string;
  accent2: string;
  text: string;
  radius: number;
}> = [
  {
    id: 'cyber_neon',
    name: 'Cyber Neon OTA',
    badge: 'STYLE 1',
    icon: '⚡',
    desc: 'Glowing neon border + live pulse OTA bar',
    bg: '#08141A',
    accent: '#00F5D4',
    accent2: '#00BBF9',
    text: '#E6FFFA',
    radius: 20,
  },
  {
    id: 'royal_gold',
    name: 'Royal Gold VIP',
    badge: 'STYLE 2',
    icon: '👑',
    desc: 'Luxury 24K gold metallic frame + obsidian card',
    bg: '#161004',
    accent: '#F59E0B',
    accent2: '#FDE047',
    text: '#FEF3C7',
    radius: 22,
  },
  {
    id: 'ios_store',
    name: 'iOS App Store',
    badge: 'STYLE 3',
    icon: '🍎',
    desc: 'Frosted iOS 18 glassmorphism + clean store pill',
    bg: '#151C28',
    accent: '#38BDF8',
    accent2: '#818CF8',
    text: '#F8FAFC',
    radius: 26,
  },
  {
    id: 'esports_hud',
    name: 'Esports Gamer HUD',
    badge: 'STYLE 4',
    icon: '🎮',
    desc: 'Tactical angled polygon corners + gamer armor',
    bg: '#140812',
    accent: '#FF2A85',
    accent2: '#00F5D4',
    text: '#FFF1F2',
    radius: 8,
  },
  {
    id: 'hologram_3d',
    name: '3D Hologram Matrix',
    badge: 'STYLE 5',
    icon: '🔮',
    desc: 'Animated RGB chroma wave + holographic matrix',
    bg: '#0B0F1F',
    accent: '#A855F7',
    accent2: '#00FF88',
    text: '#F3E8FF',
    radius: 20,
  },
];

export const AdvancedDialogMakerScreen: React.FC<CommonToolProps> = ({
  activeShaderId,
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [dialogStyle, setDialogStyle] = useState<DialogModeType>('Cyber VIP');
  const [updateDialogStyle, setUpdateDialogStyle] =
    useState<UpdateDialogStyleId>('cyber_neon');
  const [mediaBannerMode, setMediaBannerMode] = useState<
    'photo' | 'video' | 'none'
  >('photo');
  const [mediaStatusNotice, setMediaStatusNotice] = useState<string>('');
  const [previewImgError, setPreviewImgError] = useState(false);
  const [previewVidError, setPreviewVidError] = useState(false);

  const [title, setTitle] = useState('Ns mods Official VIP');
  const [message, setMessage] = useState(
    'Modded by Ns mods! Join our official Telegram channel for daily updates and premium tools.'
  );
  const [posBtn, setPosBtn] = useState('JOIN TELEGRAM');
  const [negBtn, setNegBtn] = useState('CONTINUE');
  const [telegramUrl, setTelegramUrl] = useState('https://t.me/Sharechat_ns_098');

  // Rich Media, Robot, RGB & Remote Update JSON States
  const [imageUrl, setImageUrl] = useState(BUILTIN_PHOTO_PRESETS[0].url);
  const [videoUrl, setVideoUrl] = useState(BUILTIN_VIDEO_PRESETS[0].url);
  const [remoteJsonUrl, setRemoteJsonUrl] = useState(
    'https://pastebin.com/raw/NsModsUpdateConfig'
  );
  const [appVersion, setAppVersion] = useState('v4.5 VIP');
  const [forceUpdate, setForceUpdate] = useState(false);

  // New Pro Update & Dialog Features
  const [updateFileSize, setUpdateFileSize] = useState('48.5 MB');
  const [updateReleaseDate, setUpdateReleaseDate] = useState('TODAY');
  const [serverStatusBadge, setServerStatusBadge] = useState<
    'online' | 'maintenance' | 'vip_only' | 'none'
  >('online');
  const [showUpdateProgress, setShowUpdateProgress] = useState(true);
  const [changelogItems, setChangelogItems] = useState<string[]>([
    'Upgraded 100% Crash-Free Anti-Ban Bypass Engine',
    'Added Ultra-Smooth 120 FPS Zero-Lag Optimizer',
    'Added Live Photo, Video & YouTube Banner Support',
  ]);
  const [newChangelogInput, setNewChangelogInput] = useState('');
  const [socialTelegramUrl, setSocialTelegramUrl] = useState(
    'https://t.me/Sharechat_ns_098'
  );
  const [socialYoutubeUrl, setSocialYoutubeUrl] = useState('');
  const [socialDiscordUrl, setSocialDiscordUrl] = useState('');

  const [bgColor, setBgColor] = useState('#091519');
  const [accentColor, setAccentColor] = useState('#00F5D4');
  const [secondaryAccentColor, setSecondaryAccentColor] = useState('#FF2A85');
  const [textColor, setTextColor] = useState('#E6FFFA');
  const [cornerRadiusDp, setCornerRadiusDp] = useState(20);
  const [strokeWidthDp, setStrokeWidthDp] = useState(2);
  const [dialogAnimSpeedMs, setDialogAnimSpeedMs] = useState(2600);

  const [colorTarget, setColorTarget] = useState<
    null | 'bg' | 'accent' | 'accent2' | 'text'
  >(null);

  const [compiling, setCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [packageReady, setPackageReady] = useState(false);
  const [showSmaliPreview, setShowSmaliPreview] = useState(false);
  const [showGuidePreview, setShowGuidePreview] = useState(false);
  const [showJsonPreview, setShowJsonPreview] = useState(false);

  const smaliHookLine = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsDialog;->show(Landroid/content/Context;)V`;

  const normalizedImg = useMemo(() => normalizeMediaUrl(imageUrl), [imageUrl]);
  const normalizedVid = useMemo(() => normalizeMediaUrl(videoUrl), [videoUrl]);

  // Smart setter when user enters any media URL (Photo, Video, YouTube, Google Drive, Dropbox)
  const handleApplyUniversalMediaInput = (
    rawInput: string,
    preferredType: 'photo' | 'video'
  ) => {
    setPreviewImgError(false);
    setPreviewVidError(false);
    const trimmed = (rawInput || '').trim();
    if (!trimmed) {
      if (preferredType === 'photo') setImageUrl('');
      else setVideoUrl('');
      setMediaStatusNotice('');
      return;
    }
    const parsed = normalizeMediaUrl(trimmed);
    const safeUrl = parsed.url || trimmed;
    if (parsed.kind === 'youtube') {
      setVideoUrl(trimmed);
      setMediaBannerMode('video');
      setMediaStatusNotice(
        `✅ YouTube Video (${parsed.ytId}) connected! Ready for 60FPS live playback.`
      );
    } else if (parsed.kind === 'video') {
      setVideoUrl(safeUrl);
      setMediaBannerMode('video');
      setMediaStatusNotice('✅ Direct HD Video stream connected!');
    } else if (preferredType === 'video') {
      setVideoUrl(safeUrl);
      setMediaBannerMode('video');
      setMediaStatusNotice('✅ Video / Motion URL applied!');
    } else {
      setImageUrl(safeUrl);
      setMediaBannerMode('photo');
      setMediaStatusNotice('✅ HD Photo / Image URL connected!');
    }
  };

  // Apply one of the 5 Update Dialog Styles
  const handleSelectUpdateStyle = (stylePreset: (typeof UPDATE_DIALOG_STYLE_PRESETS)[number]) => {
    setUpdateDialogStyle(stylePreset.id);
    setBgColor(stylePreset.bg);
    setAccentColor(stylePreset.accent);
    setSecondaryAccentColor(stylePreset.accent2);
    setTextColor(stylePreset.text);
    setCornerRadiusDp(stylePreset.radius);
    onShowToast(
      `${stylePreset.icon} ${stylePreset.name}`,
      stylePreset.desc
    );
  };

  // Handle switching dialog mode presets smoothly
  const handleSelectDialogMode = (mode: DialogModeType) => {
    setDialogStyle(mode);
    setPreviewImgError(false);
    if (mode === 'Update JSON') {
      setTitle('🚀 New VIP Update Available!');
      setMessage(
        'Version v4.5 VIP is now live with 100% crash-free anti-ban engine, 5 custom update styles, and HD media banner support.'
      );
      setPosBtn('UPDATE NOW');
      setNegBtn('LATER');
    } else if (mode === 'iOS Glass') {
      setTitle('Ns mods Official VIP');
      setMessage(
        'Welcome to Ns mods iOS Glass Edition! Tap Join Telegram to get daily mod updates.'
      );
      setPosBtn('Join Telegram');
      setNegBtn('Cancel');
    } else if (mode === 'Robot Mecha') {
      setTitle('🤖 NS-MECHA AI CORE v9.4');
      setMessage(
        'Neural Cyber Robot HUD initialized. All VIP bypass & graphics modules are online!'
      );
      setPosBtn('ACTIVATE CORE');
      setNegBtn('STANDBY');
    } else if (mode === 'RGB Coloring') {
      setTitle('🌈 NS MODS CHROMA RGB VIP');
      setMessage(
        '360° Full Spectrum RGB Coloring Engine active! Enjoy ultra-smooth neon chroma lighting.'
      );
      setPosBtn('JOIN TELEGRAM');
      setNegBtn('CONTINUE');
    } else if (mode === 'Photo / Image') {
      setMediaBannerMode('photo');
      setTitle('🖼️ Ns mods Photo Banner VIP');
      setMessage(
        'Custom HD Photo Banner Dialog compiled directly inside classes.dex with zero res/ conflicts!'
      );
      setPosBtn('JOIN TELEGRAM');
      setNegBtn('CLOSE');
    } else if (mode === 'Video / Anim') {
      setMediaBannerMode('video');
      setTitle('🎬 Ns mods Video Motion VIP');
      setMessage(
        'Live Auto-Looping Video & YouTube Motion Header Dialog compiled directly into classes.dex!'
      );
      setPosBtn('JOIN TELEGRAM');
      setNegBtn('SKIP');
    }
  };

  // Upload Photo from user's phone gallery and convert to compact Data URL so it works 100% offline inside classes.dex!
  const handleGalleryPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxW = 420;
        const scale = Math.min(1, maxW / img.width);
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.78);
          setImageUrl(dataUrl);
          setMediaBannerMode('photo');
          setPreviewImgError(false);
          setMediaStatusNotice('✅ Gallery Photo compressed & embedded into DEX!');
          onShowToast(
            'Photo Embedded!',
            'Image compressed & ready to compile directly inside classes.dex!'
          );
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Upload Video / GIF from user's phone gallery for live preview & embed
  const handleGalleryVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      const objUrl = URL.createObjectURL(file);
      setVideoUrl(objUrl);
      setMediaBannerMode('video');
      setMediaStatusNotice(
        '✅ Local Video loaded in Live Preview! (For APK distribution, paste a direct MP4 or YouTube URL so all users can stream it)'
      );
      onShowToast(
        'Video Loaded in Preview!',
        'For small APK size, you can also use any YouTube or direct MP4 link.'
      );
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setVideoUrl(reader.result);
        setMediaBannerMode('video');
        setMediaStatusNotice('✅ Video/GIF embedded directly!');
        onShowToast('Video Embedded!', 'Ready inside your Update Dialog!');
      }
    };
    reader.readAsDataURL(file);
  };

  // Live Test Remote JSON URL (Pastebin / GitHub Raw) with smart Image/Video URL auto-detection!
  const handleTestFetchRemoteJson = async () => {
    const rawTrimmed = remoteJsonUrl.trim();
    if (!rawTrimmed) return;

    // Check if the user pasted an Image, Video, or YouTube URL into the Remote JSON box by mistake!
    const mediaCheck = normalizeMediaUrl(rawTrimmed);
    const looksLikeDirectImage = /\.(png|jpe?g|gif|webp|bmp|svg|avif)(\?.*)?$/i.test(
      mediaCheck.url
    ) || rawTrimmed.includes('images.unsplash.com') || rawTrimmed.includes('i.imgur.com') || rawTrimmed.includes('ibb.co') || rawTrimmed.includes('postimg.cc') || rawTrimmed.includes('drive.google.com');

    if (mediaCheck.kind === 'youtube' || mediaCheck.kind === 'video') {
      setVideoUrl(rawTrimmed);
      setMediaBannerMode('video');
      setMediaStatusNotice(
        '✨ Auto-detected Video/YouTube URL! Applied directly to your Update Dialog Video Banner.'
      );
      onShowToast(
        'Video URL Applied to Banner! 🎬',
        'Set as your Update Dialog Video Banner without any error!'
      );
      return;
    }
    if (looksLikeDirectImage) {
      setImageUrl(mediaCheck.url);
      setMediaBannerMode('photo');
      setPreviewImgError(false);
      setMediaStatusNotice(
        '✨ Auto-detected Photo/Image URL! Applied directly to your Update Dialog Photo Banner.'
      );
      onShowToast(
        'Photo URL Applied to Banner! 🖼️',
        'Set as your Update Dialog Photo Banner without any error!'
      );
      return;
    }

    const cleanUrl = normalizeRemoteJsonUrl(rawTrimmed);
    setRemoteJsonUrl(cleanUrl);
    onShowToast('Fetching Remote JSON...', `Syncing from ${cleanUrl}`);
    const sep = cleanUrl.includes('?') ? '&' : '?';
    const bustUrl = `${cleanUrl}${sep}_t=${Date.now()}`;
    const candidates = [
      `/api/json-proxy?url=${encodeURIComponent(cleanUrl)}`,
      bustUrl,
      `https://api.allorigins.win/raw?url=${encodeURIComponent(bustUrl)}`,
      `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(cleanUrl)}`,
    ];
    for (const candidate of candidates) {
      try {
        const res = await fetch(candidate, { cache: 'no-store' });
        if (!res.ok) continue;
        const ctype = (res.headers.get('content-type') || '').toLowerCase();
        if (ctype.startsWith('image/')) {
          setImageUrl(cleanUrl);
          setMediaBannerMode('photo');
          setPreviewImgError(false);
          setMediaStatusNotice('✅ Image URL detected & applied to Update Dialog Banner!');
          onShowToast('Photo URL Applied! 🖼️', 'Connected to Update Dialog Banner.');
          return;
        }
        if (ctype.startsWith('video/')) {
          setVideoUrl(cleanUrl);
          setMediaBannerMode('video');
          setMediaStatusNotice('✅ Video URL detected & applied to Update Dialog Banner!');
          onShowToast('Video URL Applied! 🎬', 'Connected to Update Dialog Banner.');
          return;
        }
        const txt = await res.text();
        let data = JSON.parse(txt.trim());
        if (data && typeof data.contents === 'string') {
          data = JSON.parse(data.contents);
        }
        if (data && data.ok === false) continue;
        if (data.title || data.header) setTitle(String(data.title || data.header));
        if (data.message || data.msg || data.description)
          setMessage(String(data.message || data.msg || data.description));
        if (data.version || data.ver) setAppVersion(String(data.version || data.ver));
        if (data.positiveBtnText || data.buttonText || data.btnText)
          setPosBtn(String(data.positiveBtnText || data.buttonText || data.btnText));
        if (data.negativeBtnText || data.closeText || data.cancelText)
          setNegBtn(String(data.negativeBtnText || data.closeText || data.cancelText));
        if (data.updateUrl || data.telegramUrl || data.url || data.link)
          setTelegramUrl(
            String(data.updateUrl || data.telegramUrl || data.url || data.link)
          );
        if (data.imageUrl || data.image || data.bannerUrl) {
          setImageUrl(String(data.imageUrl || data.image || data.bannerUrl));
          setMediaBannerMode('photo');
          setPreviewImgError(false);
        }
        if (data.videoUrl || data.video || data.mp4Url) {
          setVideoUrl(String(data.videoUrl || data.video || data.mp4Url));
          setMediaBannerMode('video');
        }
        if (typeof data.forceUpdate === 'boolean') setForceUpdate(data.forceUpdate);
        onShowToast(
          'Remote JSON Synced Live! ✓',
          'Pastebin Raw JSON connected & updated your dialog!'
        );
        return;
      } catch {
        // try next candidate
      }
    }
    onShowToast(
      'JSON Template Ready Below',
      'Copy the generated JSON below to Pastebin, or use the Media Banner box for Photo/Video URLs!'
    );
  };

  const remoteJsonString = useMemo(
    () =>
      generateRemoteUpdateJsonConfig({
        title,
        message,
        version: appVersion,
        forceUpdate,
        positiveBtnText: posBtn,
        negativeBtnText: negBtn,
        updateUrl: telegramUrl,
        imageUrl: mediaBannerMode === 'photo' ? normalizedImg.url : '',
        videoUrl: mediaBannerMode === 'video' ? videoUrl : '',
        dialogStyle: `${dialogStyle} (${updateDialogStyle})`,
      }),
    [
      title,
      message,
      appVersion,
      forceUpdate,
      posBtn,
      negBtn,
      telegramUrl,
      mediaBannerMode,
      normalizedImg.url,
      videoUrl,
      dialogStyle,
      updateDialogStyle,
    ]
  );

  const dialogPkg = useMemo(() => {
    const className = 'NsModsDialog';
    const effectiveBannerMode: 'photo' | 'video' | 'none' =
      dialogStyle === 'Photo / Image'
        ? 'photo'
        : dialogStyle === 'Video / Anim'
          ? 'video'
          : mediaBannerMode;

    const dexCfg: DexDialogConfig = {
      className,
      entryMethodName: 'show',
      title,
      message,
      positiveBtnText: posBtn,
      negativeBtnText: forceUpdate ? 'REQUIRED' : negBtn,
      telegramUrl,
      bgColorHex: bgColor,
      accentColorHex: accentColor,
      secondaryAccentHex: secondaryAccentColor,
      textColorHex: textColor,
      cornerRadiusDp,
      strokeWidthDp,
      extraConfigTag: `DIALOG_${dialogStyle}_${updateDialogStyle}`,
      dialogVisualMode: dialogStyle,
      updateDialogStyle,
      mediaBannerMode: effectiveBannerMode,
      imageUrl:
        effectiveBannerMode === 'photo' ? normalizedImg.url : undefined,
      videoUrl:
        effectiveBannerMode === 'video' ? (videoUrl || '').trim() : undefined,
      remoteJsonUrl:
        dialogStyle === 'Update JSON'
          ? normalizeRemoteJsonUrl(remoteJsonUrl)
          : undefined,
      appVersion,
      forceUpdate,
      changelogItems: dialogStyle === 'Update JSON' ? changelogItems : undefined,
      updateFileSize,
      updateReleaseDate,
      serverStatusBadge,
      showUpdateProgress,
      socialTelegramUrl,
      socialYoutubeUrl,
      socialDiscordUrl,
      rainbowSpeedMs: dialogAnimSpeedMs,
      enableRainbowText:
        dialogStyle === 'RGB Coloring' ||
        (dialogStyle === 'Update JSON' && updateDialogStyle === 'hologram_3d'),
    };

    const dexBytes = compileRealDalvikDex(dexCfg);
    const smaliPreview = generateDisassembledSmaliText(dexCfg);

    const guide = buildUniversalModdingGuide({
      toolTitle: `Advanced Dialog Maker (${dialogStyle})`,
      className,
      primaryHook: smaliHookLine,
      secondaryHook: `invoke-static {v13}, Lcom/nsmods/xmlcreator/NsModsDialog;->show(Landroid/content/Context;)V`,
      tertiaryHook: `invoke-static {p0}, Lcom/nsmods/xmlcreator/NsModsDialog;->show(Landroid/content/Context;)V`,
      descriptionEn: `Launch 100% Crash-Free ${dialogStyle} Dialog in MainActivity->onCreate`,
      descriptionBn: `MainActivity-তে ১০০% ক্র্যাশ-মুক্ত ${dialogStyle} ডায়ালগ পপআপ দেখানো`,
      compiledSmaliPreview: smaliPreview,
      remoteJsonUrl:
        dialogStyle === 'Update JSON' ? remoteJsonUrl.trim() : undefined,
      remoteJsonContent: remoteJsonString,
    });

    return { dexBytes, smaliPreview, guide };
  }, [
    dialogStyle,
    updateDialogStyle,
    mediaBannerMode,
    title,
    message,
    posBtn,
    negBtn,
    forceUpdate,
    telegramUrl,
    bgColor,
    accentColor,
    secondaryAccentColor,
    textColor,
    cornerRadiusDp,
    strokeWidthDp,
    normalizedImg.url,
    videoUrl,
    remoteJsonUrl,
    appVersion,
    changelogItems,
    updateFileSize,
    updateReleaseDate,
    serverStatusBadge,
    showUpdateProgress,
    socialTelegramUrl,
    socialYoutubeUrl,
    socialDiscordUrl,
    dialogAnimSpeedMs,
    smaliHookLine,
    remoteJsonString,
  ]);

  const handleCompileDialog = () => {
    setCompiling(true);
    setPackageReady(false);
    setCompileProgress(10);
    let p = 10;
    const id = window.setInterval(() => {
      p += 22;
      if (p >= 100) {
        p = 100;
        setCompileProgress(100);
        clearInterval(id);
        setCompiling(false);
        setPackageReady(true);
        onShowToast(
          '100% Crash-Free classes.dex Ready!',
          `Compiled ${dialogStyle} Dialog inside classes.dex + update_config.json + GUIDE.txt!`
        );
      } else {
        setCompileProgress(p);
      }
    }, 80);
  };

  const handleDownloadDex2Only = () => {
    triggerBlobDownload(
      new Blob([dialogPkg.dexBytes.buffer as ArrayBuffer], {
        type: 'application/octet-stream',
      }),
      'classes2.dex'
    );
    onShowToast(
      'Downloaded classes2.dex',
      'Add classes2.dex directly to your APK in MT Manager (No duplicate conflict!)'
    );
  };

  const handleDownloadDexOnly = () => {
    triggerBlobDownload(
      new Blob([dialogPkg.dexBytes.buffer as ArrayBuffer], {
        type: 'application/octet-stream',
      }),
      'classes.dex'
    );
    onShowToast(
      'Downloaded classes.dex',
      '100% Crash-Free DEX! Select both DEX files in MT Manager -> Merge.'
    );
  };

  const handleDownloadDialogZip = async () => {
    const zip = new JSZip();
    zip.file('classes2.dex', dialogPkg.dexBytes);
    zip.file('classes.dex', dialogPkg.dexBytes);
    zip.file('GUIDE.txt', dialogPkg.guide);
    zip.file('update_config.json', remoteJsonString);

    const blob = await zip.generateAsync({ type: 'blob' });
    triggerBlobDownload(blob, 'NsMods_Dialog_Package.zip');
    onSaveHistory(`Advanced Dialog (${dialogStyle}: ${title})`, smaliHookLine);
    onShowToast(
      'Dialog ZIP Downloaded',
      'Contains classes2.dex + classes.dex + GUIDE.txt + update_config.json!'
    );
  };

  const showPhotoInPreview =
    dialogStyle === 'Photo / Image' ||
    (mediaBannerMode === 'photo' && Boolean(normalizedImg.url));
  const showVideoInPreview =
    dialogStyle === 'Video / Anim' ||
    (mediaBannerMode === 'video' && Boolean(normalizedVid.url));
  const isEsportsPreview =
    dialogStyle === 'Update JSON' && updateDialogStyle === 'esports_hud';
  const isGoldPreview =
    dialogStyle === 'Update JSON' && updateDialogStyle === 'royal_gold';
  const isHoloPreview =
    dialogStyle === 'RGB Coloring' ||
    (dialogStyle === 'Update JSON' && updateDialogStyle === 'hologram_3d');
  const isIosPreview =
    dialogStyle === 'iOS Glass' ||
    (dialogStyle === 'Update JSON' && updateDialogStyle === 'ios_store');

  return (
    <div className="flex flex-col pb-6">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          <AnimatedText text="Advanced Dialog Maker" config={typingConfig} />
        </h1>
        <button
          type="button"
          onClick={() => {
            setDialogStyle('Cyber VIP');
            setUpdateDialogStyle('cyber_neon');
            setMediaBannerMode('photo');
            setTitle('Ns mods Official VIP');
            setMessage(
              'Modded by Ns mods! Join our official Telegram channel for daily updates and premium tools.'
            );
            setTelegramUrl('https://t.me/Sharechat_ns_098');
            setPackageReady(false);
            onShowToast('Reset Complete', 'Dialog restored to default.');
          }}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ↻ Reset
        </button>
      </div>

      {/* Sticky Live Interactive Dialog Preview (Zero-Lag GPU Accelerated) */}
      <div
        className={`sticky top-2 z-20 rounded-2xl border-2 bg-[#060e12]/95 backdrop-blur-md p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-2 px-1">
          <span className="text-[#00ff88] font-bold">
            ● 60FPS ZERO-LAG LIVE PREVIEW (OUTSIDE TOUCH LOCKED)
          </span>
          <span className="px-2 py-0.5 rounded bg-[#0d262e] text-[#00f5d4] font-bold">
            {dialogStyle === 'Update JSON'
              ? `Update • ${
                  UPDATE_DIALOG_STYLE_PRESETS.find(
                    (s) => s.id === updateDialogStyle
                  )?.name || 'Cyber Neon'
                }`
              : dialogStyle}
          </span>
        </div>

        {/* Dynamic Dialog Card based on selected Visual Mode & Update Style */}
        <div
          className={`mx-auto max-w-xs overflow-hidden transition-all duration-300 relative ${
            isHoloPreview ? 'p-[2.5px] rounded-2xl' : ''
          }`}
          style={
            isHoloPreview
              ? {
                  background:
                    'linear-gradient(135deg, #00f5d4, #ff2a85, #ffd166, #00ff88)',
                  borderRadius: `${isEsportsPreview ? 8 : cornerRadiusDp}px`,
                  boxShadow: '0 0 24px rgba(0,245,212,0.4)',
                }
              : {
                  boxShadow: `0 12px 32px rgba(0,0,0,0.85), 0 0 20px ${
                    isGoldPreview ? '#f59e0b66' : `${accentColor}55`
                  }`,
                  borderRadius: `${isEsportsPreview ? 8 : cornerRadiusDp}px`,
                  clipPath: isEsportsPreview
                    ? 'polygon(0 0, calc(100% - 16px) 0, 100% 16px, 100% 100%, 16px 100%, 0 calc(100% - 16px))'
                    : undefined,
                }
          }
        >
          <div
            className="p-3.5 transition-all relative overflow-hidden"
            style={{
              backgroundColor: isIosPreview
                ? 'rgba(22, 28, 40, 0.94)'
                : isGoldPreview
                  ? '#140f04'
                  : bgColor,
              borderRadius: isHoloPreview
                ? `${Math.max(4, cornerRadiusDp - 2)}px`
                : `${isEsportsPreview ? 8 : cornerRadiusDp}px`,
              border: isHoloPreview
                ? 'none'
                : isIosPreview
                  ? '1px solid rgba(255,255,255,0.22)'
                  : `${strokeWidthDp}px solid ${
                      isGoldPreview ? '#F59E0B' : accentColor
                    }`,
            }}
          >
            {/* UPDATE JSON HEADER + METADATA STRIP */}
            {dialogStyle === 'Update JSON' && (
              <div className="mb-2.5 space-y-1.5">
                <div
                  className="flex items-center justify-between px-2.5 py-1.5 rounded-lg border"
                  style={{
                    backgroundColor: `${accentColor}1f`,
                    borderColor: `${accentColor}66`,
                  }}
                >
                  <span
                    className="text-[10px] font-mono font-extrabold flex items-center gap-1"
                    style={{ color: accentColor }}
                  >
                    <span>
                      {
                        UPDATE_DIALOG_STYLE_PRESETS.find(
                          (s) => s.id === updateDialogStyle
                        )?.icon
                      }
                    </span>
                    <span>
                      {UPDATE_DIALOG_STYLE_PRESETS.find(
                        (s) => s.id === updateDialogStyle
                      )?.name.toUpperCase()}
                    </span>
                  </span>
                  <div className="flex items-center gap-1">
                    {serverStatusBadge !== 'none' && (
                      <span
                        className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-extrabold ${
                          serverStatusBadge === 'online'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : serverStatusBadge === 'maintenance'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                        }`}
                      >
                        {serverStatusBadge === 'online'
                          ? 'ONLINE'
                          : serverStatusBadge === 'maintenance'
                            ? 'MAINT'
                            : 'VIP'}
                      </span>
                    )}
                    <span
                      className="px-2 py-0.5 rounded-full text-black font-mono font-extrabold text-[9px]"
                      style={{ backgroundColor: accentColor }}
                    >
                      {appVersion}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between px-2 py-1 rounded bg-black/40 border border-white/10 text-[9px] font-mono text-slate-300">
                  <span>📦 {updateFileSize}</span>
                  <span>⚡ {updateReleaseDate}</span>
                  <span className="text-[#00ff88]">🛡️ ANTI-BAN</span>
                </div>
              </div>
            )}

            {/* 1. ROBOT MECHA MODE HEADER */}
            {dialogStyle === 'Robot Mecha' && (
              <div className="mb-3 rounded-xl border border-[#00f5d4]/50 bg-[#040c10] p-3 text-center relative overflow-hidden">
                <div className="text-[9px] font-mono text-[#00f5d4] tracking-widest mb-1">
                  ┏━━━ AI MECHA CORE ONLINE ━━━┓
                </div>
                <div className="flex items-center justify-center gap-5 my-2">
                  <div className="w-7 h-3 rounded-full bg-[#00f5d4] shadow-[0_0_14px_#00f5d4] animate-pulse" />
                  <div className="w-2.5 h-2.5 rotate-45 border border-[#ff2a85] bg-[#ff2a85]/40" />
                  <div className="w-7 h-3 rounded-full bg-[#00f5d4] shadow-[0_0_14px_#00f5d4] animate-pulse" />
                </div>
                <div className="text-[9px] font-mono text-[#00ff88]">
                  SYS.STATUS: 100% CRASH-FREE • BYPASS READY
                </div>
              </div>
            )}

            {/* 2. UNIVERSAL PHOTO / VIDEO / YOUTUBE BANNER IN PREVIEW */}
            {showVideoInPreview ? (
              <div
                className="mb-2.5 rounded-xl overflow-hidden border bg-[#050c10] relative h-32 flex items-center justify-center"
                style={{ borderColor: `${accentColor}77` }}
              >
                {normalizedVid.kind === 'youtube' && normalizedVid.ytId ? (
                  <iframe
                    key={`dialog_yt_player_${normalizedVid.ytId}`}
                    src={`/api/yt-player?v=${encodeURIComponent(
                      normalizedVid.ytId
                    )}&title=${encodeURIComponent(title || 'YouTube Full HD Video')}`}
                    title="YouTube 1080p HD Video Player"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                    allowFullScreen
                    className="w-full h-full border-0 bg-black"
                  />
                ) : normalizedVid.url ? (
                  <video
                    key={
                      previewVidError
                        ? 'fallback_hd_video'
                        : normalizedVid.url
                    }
                    src={
                      previewVidError
                        ? 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
                        : normalizedVid.url
                    }
                    autoPlay
                    loop
                    muted
                    playsInline
                    controls
                    onError={() => {
                      if (!previewVidError) setPreviewVidError(true);
                    }}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center">
                    <div className="text-2xl">🎬</div>
                    <div className="text-[10px] font-mono text-[#00f5d4] mt-1">
                      PASTE MP4 OR YOUTUBE URL
                    </div>
                  </div>
                )}
                {normalizedVid.kind !== 'youtube' && (
                  <div className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded bg-[#ff2a85]/90 text-[8px] font-mono font-bold text-white pointer-events-none">
                    ● LIVE HD VIDEO
                  </div>
                )}
              </div>
            ) : showPhotoInPreview ? (
              <div
                className="mb-2.5 rounded-xl overflow-hidden border bg-black relative h-32"
                style={{ borderColor: `${accentColor}77` }}
              >
                {!previewImgError ? (
                  <img
                    src={normalizedImg.url}
                    alt="Dialog Banner"
                    onError={() => setPreviewImgError(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#0c2229] to-[#1a0d18] p-2 text-center">
                    <span className="text-lg">🖼️</span>
                    <span className="text-[10px] font-bold text-[#00f5d4]">
                      Custom Banner URL Set
                    </span>
                    <span className="text-[8px] text-slate-400 truncate max-w-[210px]">
                      {imageUrl}
                    </span>
                  </div>
                )}
                <div className="absolute bottom-1.5 right-1.5 px-2 py-0.5 rounded bg-black/75 border border-[#00f5d4]/60 text-[8px] font-mono text-[#00f5d4]">
                  HD PHOTO BANNER
                </div>
              </div>
            ) : null}

            {/* Title & Avatar Row */}
            <div
              className={`flex items-center gap-2.5 mb-2 ${
                isIosPreview ? 'flex-col text-center' : 'justify-start'
              }`}
            >
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center font-extrabold text-xs text-black shrink-0 shadow-md"
                style={{
                  background: isHoloPreview
                    ? 'linear-gradient(135deg, #00f5d4, #ff2a85)'
                    : accentColor,
                }}
              >
                {dialogStyle === 'Robot Mecha'
                  ? '🤖'
                  : isIosPreview
                  ? '🍎'
                  : dialogStyle === 'Update JSON'
                  ? UPDATE_DIALOG_STYLE_PRESETS.find(
                      (s) => s.id === updateDialogStyle
                    )?.icon || '🚀'
                  : 'NS'}
              </div>
              <div className="min-w-0">
                <div
                  className="text-sm font-extrabold truncate"
                  style={{
                    color: isIosPreview ? '#FFFFFF' : accentColor,
                  }}
                >
                  {title}
                </div>
                <div className="text-[10px] font-mono text-slate-400">
                  {dialogStyle} • Ns mods Verified
                </div>
              </div>
            </div>

            {/* Message Body */}
            <p
              className={`text-xs leading-relaxed mb-2.5 ${
                isIosPreview ? 'text-center' : ''
              }`}
              style={{ color: textColor }}
            >
              {message}
            </p>

            {/* Interactive What's New Changelog Preview (in Update JSON mode) */}
            {dialogStyle === 'Update JSON' && changelogItems.length > 0 && (
              <div
                className="mb-2.5 rounded-xl p-2 text-left border bg-black/40 max-h-24 overflow-y-auto space-y-1"
                style={{ borderColor: `${accentColor}44` }}
              >
                <div
                  className="text-[9px] font-mono font-extrabold tracking-wider"
                  style={{ color: accentColor }}
                >
                  ✦ WHAT&apos;S NEW IN {appVersion}
                </div>
                {changelogItems.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-1.5 text-[10px] text-slate-200 leading-snug"
                  >
                    <span style={{ color: accentColor }}>▸</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            )}

            {/* OTA Progress Bar Preview */}
            {dialogStyle === 'Update JSON' && showUpdateProgress && (
              <div className="mb-2.5 rounded-lg bg-black/35 border border-white/10 p-1.5">
                <div className="flex justify-between text-[8px] font-mono font-bold text-slate-300 mb-1">
                  <span>OTA PACKAGE VERIFIED</span>
                  <span style={{ color: accentColor }}>100% READY</span>
                </div>
                <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: '100%',
                      background: `linear-gradient(90deg, ${accentColor}, ${secondaryAccentColor})`,
                    }}
                  />
                </div>
              </div>
            )}

            {/* Mod Menu Toggles Preview */}
            {dialogStyle === 'Mod Menu' && (
              <div className="space-y-1.5 mb-3 bg-black/35 p-2.5 rounded-xl border border-[#00f5d4]/30">
                {[
                  '⚡ Anti-Crash Dalvik Protection',
                  '👑 Unlock VIP Pro Graphics',
                  '🛡️ Smooth 120 FPS Optimizer',
                ].map((feat, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between text-[11px] text-white font-semibold"
                  >
                    <span>{feat}</span>
                    <span className="px-2 py-0.5 rounded-full bg-[#00f5d4] text-black text-[9px] font-extrabold">
                      ON
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* Key Login Input Preview */}
            {dialogStyle === 'Key Login' && (
              <input
                type="text"
                readOnly
                value="VIP-NSMODS-2026-PRO"
                className="w-full mb-3 rounded-lg border border-[#00f5d4]/50 bg-[#050d10] px-2.5 py-1.5 text-xs font-mono text-[#00f5d4] text-center"
              />
            )}

            {/* Social Quick-Bar Chips */}
            {(socialTelegramUrl || socialYoutubeUrl || socialDiscordUrl) && (
              <div className="flex items-center justify-center gap-1.5 mb-2.5 flex-wrap">
                {socialTelegramUrl && (
                  <span className="px-2 py-0.5 rounded-full bg-white/10 border border-white/15 text-[9px] font-bold text-white">
                    ✈️ Telegram
                  </span>
                )}
                {socialYoutubeUrl && (
                  <span className="px-2 py-0.5 rounded-full bg-white/10 border border-white/15 text-[9px] font-bold text-white">
                    ▶️ YouTube
                  </span>
                )}
                {socialDiscordUrl && (
                  <span className="px-2 py-0.5 rounded-full bg-white/10 border border-white/15 text-[9px] font-bold text-white">
                    💬 Discord
                  </span>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-2">
              {!forceUpdate && (
                <button
                  type="button"
                  className="py-2 rounded-lg border border-slate-600 bg-black/40 text-[11px] font-bold text-slate-300"
                >
                  {negBtn}
                </button>
              )}
              <button
                type="button"
                onClick={() =>
                  window.open(telegramUrl, '_blank', 'noopener,noreferrer')
                }
                className={`py-2 rounded-lg text-[11px] font-extrabold text-black shadow-md ${
                  forceUpdate ? 'col-span-2' : ''
                }`}
                style={{
                  background: isHoloPreview
                    ? 'linear-gradient(90deg, #00f5d4, #ff2a85)'
                    : `linear-gradient(135deg, ${accentColor}, ${secondaryAccentColor})`,
                  color: '#041014',
                }}
              >
                {posBtn}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 9-Mode Rich Dialog Selector Grid */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}>
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-white">
            Select Dialog Type (9 Premium Modes)
          </span>
          <span className="text-[10px] font-mono text-[#00f5d4]">
            100% Crash-Free DEX
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {DIALOG_MODE_CARDS.map((card) => {
            const active = dialogStyle === card.id;
            return (
              <button
                key={card.id}
                type="button"
                onClick={() => handleSelectDialogMode(card.id)}
                className={`p-2 rounded-xl border text-left transition-all flex flex-col justify-between ${microClass} ${
                  active
                    ? 'border-[#00f5d4] bg-[#0d2e36] shadow-[0_0_12px_rgba(0,245,212,0.28)]'
                    : 'border-[#00f5d4]/35 bg-[#0c1a1f] hover:bg-[#102329]'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className="text-base">{card.icon}</span>
                  <span
                    className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      active
                        ? 'bg-[#00f5d4] text-black'
                        : 'bg-black/40 text-slate-400'
                    }`}
                  >
                    {card.badge}
                  </span>
                </div>
                <div
                  className={`text-[11px] font-extrabold leading-tight ${
                    active ? 'text-[#00f5d4]' : 'text-white'
                  }`}
                >
                  {card.label}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* UNIVERSAL MEDIA BANNER STUDIO (Available in Photo, Video, AND Update JSON Dialog!) */}
      {(dialogStyle === 'Photo / Image' ||
        dialogStyle === 'Video / Anim' ||
        dialogStyle === 'Update JSON') && (
        <div
          className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-[#00f5d4]">
              🖼️🎬 Dialog Media Banner (Photo / Video / YouTube URL)
            </span>
            <span className="px-2 py-0.5 rounded bg-[#00f5d4]/15 text-[#00f5d4] font-mono text-[9px] font-bold">
              NO URL ERRORS
            </span>
          </div>

          <p className="text-[11px] text-slate-300 leading-relaxed">
            যেকোনো **Image/Photo URL**, **Google Drive Image**, **Direct MP4 Video**, অথবা **YouTube Video Link** নিচে পেস্ট করুন বা গ্যালারি থেকে আপলোড করুন — কোনো এরর ছাড়াই সরাসরি ডায়ালগে সেট হয়ে যাবে!
          </p>

          {/* Media Type Switcher (Photo vs Video/YouTube vs None) */}
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { id: 'photo', label: '🖼️ Photo / Image' },
                { id: 'video', label: '🎬 Video / YouTube' },
                { id: 'none', label: '🚫 No Banner' },
              ] as const
            ).map((tab) => {
              const isTabActive =
                (dialogStyle === 'Photo / Image' && tab.id === 'photo') ||
                (dialogStyle === 'Video / Anim' && tab.id === 'video') ||
                (dialogStyle === 'Update JSON' && mediaBannerMode === tab.id);
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setMediaBannerMode(tab.id);
                    if (
                      dialogStyle === 'Photo / Image' &&
                      tab.id === 'video'
                    ) {
                      setDialogStyle('Video / Anim');
                    } else if (
                      dialogStyle === 'Video / Anim' &&
                      tab.id === 'photo'
                    ) {
                      setDialogStyle('Photo / Image');
                    }
                  }}
                  className={`py-2 px-2 rounded-xl border text-[11px] font-extrabold transition-all ${
                    isTabActive
                      ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                      : 'border-white/15 bg-[#060f12] text-slate-300'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {mediaStatusNotice && (
            <div className="rounded-xl border border-[#00ff88]/50 bg-[#072119] px-3 py-2 text-[11px] font-bold text-[#00ff88]">
              {mediaStatusNotice}
            </div>
          )}

          {/* PHOTO / IMAGE URL & PRESETS */}
          {(dialogStyle === 'Photo / Image' ||
            (dialogStyle !== 'Video / Anim' && mediaBannerMode === 'photo')) && (
            <div className="space-y-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Photo / Image URL (Direct Link, Google Drive, Imgur, Postimg, etc.)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) =>
                      handleApplyUniversalMediaInput(e.target.value, 'photo')
                    }
                    placeholder="https://example.com/photo.jpg or Google Drive link"
                    className="flex-1 rounded-xl border border-[#00f5d4]/60 bg-[#060f12] px-3 py-2 text-xs font-mono text-[#00f5d4]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      handleApplyUniversalMediaInput(imageUrl, 'photo');
                      onShowToast(
                        'Photo Banner Applied! 🖼️',
                        'Image URL verified & connected to Dialog!'
                      );
                    }}
                    className="px-3 py-2 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-[11px] font-extrabold text-[#00ff88] shrink-0"
                  >
                    ✓ Set
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5">
                {BUILTIN_PHOTO_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setImageUrl(p.url);
                      setMediaBannerMode('photo');
                      setPreviewImgError(false);
                      setMediaStatusNotice(`✅ Loaded preset: ${p.name}`);
                      onShowToast('Photo Preset Applied', p.name);
                    }}
                    className="py-2 px-2 rounded-xl border border-[#00f5d4]/40 bg-[#0d1f25] text-[10px] font-bold text-white truncate hover:border-[#00f5d4]"
                  >
                    🖼️ {p.name}
                  </button>
                ))}
              </div>

              <label className="block w-full py-2.5 rounded-xl border border-dashed border-[#00ff88] bg-[#071f1a] text-center text-xs font-extrabold text-[#00ff88] cursor-pointer">
                📤 Upload Photo From Phone Gallery (100% Offline DEX Embed)
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleGalleryPhotoUpload}
                  className="hidden"
                />
              </label>
            </div>
          )}

          {/* VIDEO / YOUTUBE URL & PRESETS */}
          {(dialogStyle === 'Video / Anim' ||
            (dialogStyle !== 'Photo / Image' && mediaBannerMode === 'video')) && (
            <div className="space-y-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Video or YouTube URL (.mp4, .webm, YouTube Watch / Shorts link)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={videoUrl}
                    onChange={(e) =>
                      handleApplyUniversalMediaInput(e.target.value, 'video')
                    }
                    placeholder="https://example.com/video.mp4 or https://youtu.be/..."
                    className="flex-1 rounded-xl border border-[#ff2a85]/60 bg-[#060f12] px-3 py-2 text-xs font-mono text-[#00f5d4]"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      handleApplyUniversalMediaInput(videoUrl, 'video');
                      onShowToast(
                        'Video Banner Applied! 🎬',
                        'Video / YouTube stream connected to Dialog!'
                      );
                    }}
                    className="px-3 py-2 rounded-xl border border-[#ff2a85] bg-[#2b0c1d] text-[11px] font-extrabold text-[#ff2a85] shrink-0"
                  >
                    ✓ Set
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                {BUILTIN_VIDEO_PRESETS.map((v, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPreviewVidError(false);
                      setVideoUrl(v.url);
                      setMediaBannerMode('video');
                      setMediaStatusNotice(`✅ Loaded video preset: ${v.name}`);
                      onShowToast('Video Preset Loaded', v.name);
                    }}
                    className="py-2 px-2 rounded-xl border border-[#ff2a85]/50 bg-[#1a0d16] text-[10px] font-bold text-white truncate hover:border-[#ff2a85]"
                  >
                    🎬 {v.name}
                  </button>
                ))}
              </div>

              <label className="block w-full py-2.5 rounded-xl border border-dashed border-[#ff2a85] bg-[#1f0915] text-center text-xs font-extrabold text-[#ff2a85] cursor-pointer">
                📤 Upload Video / GIF From Phone Gallery
                <input
                  type="file"
                  accept="video/*,image/gif"
                  onChange={handleGalleryVideoUpload}
                  className="hidden"
                />
              </label>
            </div>
          )}
        </div>
      )}

      {/* Mode-Specific Controls: 5-Style Update Dialog + Remote JSON Studio */}
      {dialogStyle === 'Update JSON' && (
        <div className="rounded-2xl border-2 border-[#00ff88] bg-[#071915] p-3.5 mb-3.5 space-y-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-extrabold text-[#00ff88]">
              🚀 Update Dialog Studio (5 New Styles + Remote JSON)
            </span>
            <span className="px-2 py-0.5 rounded bg-[#00ff88]/20 text-[#00ff88] font-mono text-[10px] font-bold">
              5 VIP STYLES
            </span>
          </div>

          {/* 5 NEW UPDATE DIALOG STYLES SELECTOR */}
          <div>
            <label className="text-[11px] font-extrabold text-white block mb-2">
              🎨 Choose Update Dialog Visual Style (5 New Premium Designs)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {UPDATE_DIALOG_STYLE_PRESETS.map((st) => {
                const active = updateDialogStyle === st.id;
                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => handleSelectUpdateStyle(st)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      active
                        ? 'border-[#00ff88] bg-[#0d3328] shadow-[0_0_14px_rgba(0,255,136,0.28)]'
                        : 'border-white/15 bg-[#040e0c] hover:border-[#00f5d4]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-base">{st.icon}</span>
                      <span
                        className={`text-[8px] font-mono font-extrabold px-1.5 py-0.5 rounded ${
                          active
                            ? 'bg-[#00ff88] text-black'
                            : 'bg-white/10 text-slate-300'
                        }`}
                      >
                        {st.badge}
                      </span>
                    </div>
                    <div className="text-[11px] font-extrabold text-white leading-tight">
                      {st.name}
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5 line-clamp-1">
                      {st.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Update Metadata: Version, Force Lock, File Size, Release Date, Server Status */}
          <div className="grid grid-cols-2 gap-2.5 pt-1">
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Update Version Tag
              </label>
              <input
                type="text"
                value={appVersion}
                onChange={(e) => setAppVersion(e.target.value)}
                className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#040c0e] px-3 py-2 text-xs font-mono font-bold text-white"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Force Update Mode
              </label>
              <button
                type="button"
                onClick={() => setForceUpdate((f) => !f)}
                className={`w-full py-2 rounded-xl border text-xs font-extrabold ${
                  forceUpdate
                    ? 'border-[#ff2a85] bg-[#290b19] text-[#ff2a85]'
                    : 'border-[#00f5d4]/50 bg-[#0a1a1f] text-slate-300'
                }`}
              >
                {forceUpdate ? '🔒 FORCE LOCK: ON' : '🔓 OPTIONAL UPDATE'}
              </button>
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Package Size Badge
              </label>
              <input
                type="text"
                value={updateFileSize}
                onChange={(e) => setUpdateFileSize(e.target.value)}
                placeholder="48.5 MB"
                className="w-full rounded-xl border border-[#00f5d4]/40 bg-[#040c0e] px-3 py-1.5 text-xs font-mono text-white"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-300 block mb-1">
                Release Date Badge
              </label>
              <input
                type="text"
                value={updateReleaseDate}
                onChange={(e) => setUpdateReleaseDate(e.target.value)}
                placeholder="TODAY"
                className="w-full rounded-xl border border-[#00f5d4]/40 bg-[#040c0e] px-3 py-1.5 text-xs font-mono text-white"
              />
            </div>
          </div>

          {/* Server Status Badge & Progress Bar Toggle */}
          <div className="grid grid-cols-4 gap-1.5">
            {(
              [
                { id: 'online', label: '🟢 Online' },
                { id: 'maintenance', label: '🟠 Maint.' },
                { id: 'vip_only', label: '🟣 VIP Only' },
                { id: 'none', label: '🚫 Hide' },
              ] as const
            ).map((st) => (
              <button
                key={st.id}
                type="button"
                onClick={() => setServerStatusBadge(st.id)}
                className={`py-1.5 px-2 rounded-lg border text-[10px] font-bold ${
                  serverStatusBadge === st.id
                    ? 'border-[#00ff88] bg-[#0b2e25] text-[#00ff88]'
                    : 'border-white/15 bg-[#040c0e] text-slate-300'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>

          {/* Interactive What's New Changelog Builder */}
          <div className="rounded-xl border border-[#00f5d4]/40 bg-[#040c0e] p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-extrabold text-[#00f5d4]">
                📋 Interactive &quot;What&apos;s New&quot; Changelog List
              </span>
              <button
                type="button"
                onClick={() => setShowUpdateProgress((p) => !p)}
                className="text-[10px] font-mono text-[#00ff88] underline"
              >
                OTA Bar: {showUpdateProgress ? 'ON' : 'OFF'}
              </button>
            </div>

            <div className="flex gap-1.5">
              <input
                type="text"
                value={newChangelogInput}
                onChange={(e) => setNewChangelogInput(e.target.value)}
                placeholder="Add new update feature bullet..."
                className="flex-1 rounded-lg border border-[#00f5d4]/40 bg-[#081519] px-2.5 py-1.5 text-xs text-white"
              />
              <button
                type="button"
                onClick={() => {
                  if (!newChangelogInput.trim()) return;
                  setChangelogItems((prev) => [
                    ...prev,
                    newChangelogInput.trim(),
                  ]);
                  setNewChangelogInput('');
                }}
                className="px-3 py-1.5 rounded-lg bg-[#00f5d4] text-black text-xs font-extrabold"
              >
                + Add
              </button>
            </div>

            <div className="space-y-1 max-h-28 overflow-y-auto">
              {changelogItems.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between gap-2 rounded-lg bg-[#09181d] px-2.5 py-1 text-[11px] text-slate-200"
                >
                  <span className="truncate">▸ {item}</span>
                  <button
                    type="button"
                    onClick={() =>
                      setChangelogItems((prev) =>
                        prev.filter((_, i) => i !== idx)
                      )
                    }
                    className="text-rose-400 font-bold text-xs px-1"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Remote JSON Raw Link Input */}
          <div>
            <label className="text-[11px] font-bold text-[#00f5d4] block mb-1">
              ☁️ Remote JSON Raw Link (Pastebin Raw / GitHub Raw URL)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={remoteJsonUrl}
                onChange={(e) => setRemoteJsonUrl(e.target.value)}
                placeholder="https://pastebin.com/raw/xxxxxxxx"
                className="flex-1 rounded-xl border border-[#00f5d4]/70 bg-[#040c0e] px-3 py-2 text-xs font-mono text-[#00f5d4]"
              />
              <button
                type="button"
                onClick={handleTestFetchRemoteJson}
                className="px-3 py-2 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-[11px] font-extrabold text-[#00ff88] shrink-0"
              >
                🔄 Sync
              </button>
            </div>
          </div>

          {/* Instant JSON Export & Pastebin Actions */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(remoteJsonString);
                onShowToast(
                  'JSON Copied!',
                  'Now paste this on Pastebin.com and copy the Raw link!'
                );
              }}
              className="py-2.5 px-2 rounded-xl border border-[#00f5d4] bg-[#0d262e] text-[11px] font-extrabold text-[#00f5d4]"
            >
              ❐ Copy Config JSON
            </button>
            <button
              type="button"
              onClick={() => {
                triggerBlobDownload(
                  new Blob([remoteJsonString], {
                    type: 'application/json;charset=utf-8',
                  }),
                  'update_config.json'
                );
                onShowToast(
                  'update_config.json Saved!',
                  'Upload to Pastebin or GitHub to control your dialog remotely.'
                );
              }}
              className="py-2.5 px-2 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-[11px] font-extrabold text-[#00ff88]"
            >
              ⬇ Download .JSON File
            </button>
          </div>

          <button
            type="button"
            onClick={() => setShowJsonPreview((v) => !v)}
            className="w-full py-2 rounded-xl border border-[#00f5d4]/40 bg-[#040c0e] text-[11px] font-bold text-white"
          >
            {showJsonPreview
              ? '▲ Hide Generated update_config.json'
              : '▼ View Generated update_config.json (For Pastebin)'}
          </button>

          {showJsonPreview && (
            <pre className="max-h-48 overflow-y-auto rounded-xl border border-[#00ff88]/50 bg-[#03080a] p-2.5 text-[10px] font-mono text-[#00ff88] select-all">
              {remoteJsonString}
            </pre>
          )}
        </div>
      )}

      {/* Pro Dialog Extra Features: Social Quick-Bar & One-Tap Templates */}
      <div
        className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-white">
            ⚡ Pro Dialog Quick Templates &amp; Social Chips Bar
          </span>
          <span className="text-[10px] font-mono text-[#00ff88]">NEW PRO</span>
        </div>

        {/* 1-Tap Complete Dialog Templates */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {[
            {
              label: '🔥 Anti-Ban v4.5',
              apply: () => {
                setDialogStyle('Update JSON');
                handleSelectUpdateStyle(UPDATE_DIALOG_STYLE_PRESETS[0]);
                setTitle('🛡️ Anti-Ban Bypass v4.5 Live!');
                setMessage(
                  '100% Safe Main Account Protection + Zero-Lag 120 FPS Engine updated!'
                );
              },
            },
            {
              label: '👑 Royal Gold VIP',
              apply: () => {
                setDialogStyle('Update JSON');
                handleSelectUpdateStyle(UPDATE_DIALOG_STYLE_PRESETS[1]);
                setTitle('👑 Royal Gold VIP Edition');
                setMessage(
                  'Welcome to Ns mods Royal Gold VIP! All premium skins & features unlocked.'
                );
              },
            },
            {
              label: '🎮 Esports Patch',
              apply: () => {
                setDialogStyle('Update JSON');
                handleSelectUpdateStyle(UPDATE_DIALOG_STYLE_PRESETS[3]);
                setTitle('🎮 Esports Tournament HUD');
                setMessage(
                  'Ultra-responsive touch engine & custom crosshair overlay enabled.'
                );
              },
            },
            {
              label: '🔮 Holo Matrix',
              apply: () => {
                setDialogStyle('Update JSON');
                handleSelectUpdateStyle(UPDATE_DIALOG_STYLE_PRESETS[4]);
                setTitle('🔮 3D Hologram Matrix OTA');
                setMessage(
                  'Cloud config synced! Tap below to join our official channel.'
                );
              },
            },
          ].map((tpl, i) => (
            <button
              key={i}
              type="button"
              onClick={tpl.apply}
              className="py-2 px-2 rounded-xl border border-[#00f5d4]/40 bg-[#0d1f25] text-[10px] font-extrabold text-white hover:border-[#00f5d4]"
            >
              {tpl.label}
            </button>
          ))}
        </div>

        {/* Social Quick-Bar Links */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <div>
            <label className="text-[10px] font-bold text-slate-300 block mb-1">
              ✈️ Telegram Chip URL
            </label>
            <input
              type="text"
              value={socialTelegramUrl}
              onChange={(e) => setSocialTelegramUrl(e.target.value)}
              placeholder="https://t.me/..."
              className="w-full rounded-xl border border-[#00f5d4]/40 bg-[#060f12] px-2.5 py-1.5 text-[11px] font-mono text-white"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-300 block mb-1">
              ▶️ YouTube Chip URL
            </label>
            <input
              type="text"
              value={socialYoutubeUrl}
              onChange={(e) => setSocialYoutubeUrl(e.target.value)}
              placeholder="https://youtube.com/..."
              className="w-full rounded-xl border border-[#00f5d4]/40 bg-[#060f12] px-2.5 py-1.5 text-[11px] font-mono text-white"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-300 block mb-1">
              💬 Discord / Web Chip URL
            </label>
            <input
              type="text"
              value={socialDiscordUrl}
              onChange={(e) => setSocialDiscordUrl(e.target.value)}
              placeholder="https://discord.gg/..."
              className="w-full rounded-xl border border-[#00f5d4]/40 bg-[#060f12] px-2.5 py-1.5 text-[11px] font-mono text-white"
            />
          </div>
        </div>
      </div>

      {/* General Dialog Content & Styling Controls */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}>
        <div className="text-xs font-bold text-white">
          Dialog Text, Buttons &amp; Colors
        </div>

        <div>
          <label className="text-xs text-slate-300 font-semibold block mb-1">
            Dialog Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-bold text-white"
          />
        </div>

        <div>
          <label className="text-xs text-slate-300 font-semibold block mb-1">
            Dialog Message
          </label>
          <textarea
            rows={2}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs text-white"
          />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs text-slate-300 font-semibold block mb-1">
              Positive Button
            </label>
            <input
              type="text"
              value={posBtn}
              onChange={(e) => setPosBtn(e.target.value)}
              className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-bold text-white"
            />
          </div>
          <div>
            <label className="text-xs text-slate-300 font-semibold block mb-1">
              Negative Button
            </label>
            <input
              type="text"
              value={negBtn}
              onChange={(e) => setNegBtn(e.target.value)}
              className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-bold text-white"
            />
          </div>
        </div>

        <div>
          <label className="text-xs text-slate-300 font-semibold block mb-1">
            Official Telegram / Update Action Link
          </label>
          <input
            type="text"
            value={telegramUrl}
            onChange={(e) => setTelegramUrl(e.target.value)}
            className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-mono text-[#00f5d4]"
          />
        </div>

        {/* Colors & Geometry */}
        <div className="grid grid-cols-4 gap-2 pt-1">
          <button
            type="button"
            onClick={() => setColorTarget('bg')}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-[10px] font-bold text-white flex items-center justify-center gap-1 ${microClass}`}
          >
            <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: bgColor }} />
            <span>BG</span>
          </button>
          <button
            type="button"
            onClick={() => setColorTarget('accent')}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-[10px] font-bold text-white flex items-center justify-center gap-1 ${microClass}`}
          >
            <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: accentColor }} />
            <span>ACCENT</span>
          </button>
          <button
            type="button"
            onClick={() => setColorTarget('accent2')}
            className={`py-2.5 rounded-xl border border-[#ff2a85]/60 bg-[#1a0d16] text-[10px] font-bold text-white flex items-center justify-center gap-1 ${microClass}`}
          >
            <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: secondaryAccentColor }} />
            <span>GLOW 2</span>
          </button>
          <button
            type="button"
            onClick={() => setColorTarget('text')}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-[10px] font-bold text-white flex items-center justify-center gap-1 ${microClass}`}
          >
            <span className="w-2.5 h-2.5 rounded-full border border-white/40" style={{ backgroundColor: textColor }} />
            <span>TEXT</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-300">Corner Radius</span>
              <span className="font-mono font-bold text-[#00f5d4]">
                {cornerRadiusDp}dp
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={36}
              value={cornerRadiusDp}
              onChange={(e) => setCornerRadiusDp(Number(e.target.value))}
              className="w-full"
            />
          </div>
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-slate-300">Border Stroke</span>
              <span className="font-mono font-bold text-[#00f5d4]">
                {strokeWidthDp}dp
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={6}
              value={strokeWidthDp}
              onChange={(e) => setStrokeWidthDp(Number(e.target.value))}
              className="w-full"
            />
          </div>
        </div>

        <div className="pt-1">
          <div className="flex justify-between text-[11px] mb-1">
            <span className="text-[#00ff88] font-bold">
              ⏱️ Live Dialog Glow &amp; RGB Animation Speed (গতি কমানো/বাড়ানো)
            </span>
            <span className="font-mono font-bold text-[#00f5d4]">
              {dialogAnimSpeedMs} ms
            </span>
          </div>
          <input
            type="range"
            min={1000}
            max={6000}
            step={200}
            value={dialogAnimSpeedMs}
            onChange={(e) => setDialogAnimSpeedMs(Number(e.target.value))}
            className="w-full"
          />
        </div>
      </div>

      {/* Build & Export Dialog Package (100% Crash-Free classes.dex + update_config.json + GUIDE.txt) */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-1">
          Build &amp; Export Package (100% Crash-Free classes.dex + JSON + GUIDE.txt)
        </div>
        <p className="text-[11px] text-slate-400 mb-3">
          Compiles your complete{' '}
          <span className="text-[#00ff88] font-bold">{dialogStyle}</span> Dialog
          directly inside{' '}
          <span className="text-[#00f5d4] font-mono">classes.dex</span> (
          <span className="text-white font-mono">
            Lcom/nsmods/xmlcreator/NsModsDialog;
          </span>
          ) + <span className="text-[#ffd166] font-mono">update_config.json</span>{' '}
          + Bangla &amp; English{' '}
          <span className="text-[#00ff88] font-mono">GUIDE.txt</span>!
        </p>

        <button
          type="button"
          onClick={handleCompileDialog}
          className={`w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d262e] text-xs font-extrabold text-white uppercase tracking-wider mb-3 flex items-center justify-center gap-2 ${microClass}`}
        >
          <span className="text-[#ffd166]">⚡</span>
          <span>Generate {dialogStyle} Package (classes.dex + JSON + Guide)</span>
        </button>

        {(compiling || packageReady) && (
          <div className="space-y-3">
            <ConversionShaderView
              shaderId={activeShaderId}
              sourceLabel="SMALI AST"
              targetLabel="CLASSES.DEX"
              progress={compileProgress}
              compact
            />

            {packageReady && (
              <div className="rounded-xl border border-[#00ff88]/60 bg-[#071915] p-3.5 space-y-2.5">
                <div className="text-center text-xs font-bold text-[#00ff88]">
                  ✓ 100% Crash-Free {dialogStyle} classes.dex Ready!
                </div>
                <div className="text-center text-[11px] font-mono text-slate-300">
                  • classes.dex • update_config.json • GUIDE.txt (Zero res/ conflict!)
                </div>

                <button
                  type="button"
                  onClick={handleDownloadDex2Only}
                  className={`w-full py-3 rounded-xl border border-[#00f5d4] bg-[#0d2228] text-xs font-bold text-white flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span className="text-[#ffd166]">⚡</span>
                  <span>
                    Download classes2.dex (Direct APK Add — No Duplicate!)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadDexOnly}
                  className={`w-full py-2.5 rounded-xl border border-[#00f5d4]/60 bg-[#09181d] text-[11px] font-bold text-slate-200 flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>⚙️</span>
                  <span>Download classes.dex (For DEX Merge)</span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadDialogZip}
                  className={`w-full py-3 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-xs font-bold text-[#00ff88] flex items-center justify-center gap-2 ${microClass}`}
                >
                  <span>📦</span>
                  <span>
                    Download Complete ZIP (classes.dex + JSON + GUIDE.txt)
                  </span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      triggerBlobDownload(
                        new Blob([remoteJsonString], {
                          type: 'application/json;charset=utf-8',
                        }),
                        'update_config.json'
                      );
                      onShowToast(
                        'update_config.json Downloaded',
                        'Paste on Pastebin.com for remote live control!'
                      );
                    }}
                    className={`py-2.5 rounded-xl border border-[#ffd166]/80 bg-[#241d0a] text-[11px] font-bold text-[#ffd166] flex items-center justify-center gap-1.5 ${microClass}`}
                  >
                    <span>☁️</span>
                    <span>Download JSON</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      triggerBlobDownload(
                        new Blob([dialogPkg.guide], {
                          type: 'text/plain;charset=utf-8',
                        }),
                        'GUIDE.txt'
                      );
                      onShowToast(
                        'GUIDE.txt Downloaded',
                        'Bangla & English step-by-step guide saved!'
                      );
                    }}
                    className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white flex items-center justify-center gap-1.5 ${microClass}`}
                  >
                    <span>📄</span>
                    <span>Download GUIDE.txt</span>
                  </button>
                </div>

                {/* 1-Line MainActivity Smali Hook Copy Box */}
                <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-2.5 mt-2">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono font-bold text-[#00f5d4]">
                      MAINACTIVITY ONCREATE 1-LINE SMALI HOOK:
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(smaliHookLine);
                        onShowToast(
                          'Hook Copied!',
                          'Paste right below invoke-super in MainActivity->onCreate'
                        );
                      }}
                      className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00f5d4]/60 text-[10px] font-bold text-[#00f5d4]"
                    >
                      ❐ Copy Hook
                    </button>
                  </div>
                  <code className="block text-[10px] font-mono text-white break-all select-all">
                    {smaliHookLine}
                  </code>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSmaliPreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00f5d4]/40 bg-[#0a181d] text-[11px] font-bold text-[#00f5d4]"
                  >
                    {showSmaliPreview ? '▲ Hide Smali' : '▼ View Smali in DEX'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGuidePreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00ff88]/40 bg-[#0a181d] text-[11px] font-bold text-[#00ff88]"
                  >
                    {showGuidePreview ? '▲ Hide Guide' : '📖 View Full Guide'}
                  </button>
                </div>

                {showSmaliPreview && (
                  <pre className="max-h-52 overflow-y-auto rounded-xl border border-[#00f5d4]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-[#00ff88] leading-relaxed select-all">
                    {dialogPkg.smaliPreview}
                  </pre>
                )}

                {showGuidePreview && (
                  <pre className="max-h-64 overflow-y-auto rounded-xl border border-[#00ff88]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-slate-200 leading-relaxed select-all whitespace-pre-wrap">
                    {dialogPkg.guide}
                  </pre>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <ColorPickerModal
        isOpen={colorTarget !== null}
        initialColor={
          colorTarget === 'bg'
            ? bgColor
            : colorTarget === 'accent'
            ? accentColor
            : colorTarget === 'accent2'
            ? secondaryAccentColor
            : textColor
        }
        onClose={() => setColorTarget(null)}
        onSelectColor={(hex) => {
          if (colorTarget === 'bg') setBgColor(hex);
          else if (colorTarget === 'accent') setAccentColor(hex);
          else if (colorTarget === 'accent2') setSecondaryAccentColor(hex);
          else if (colorTarget === 'text') setTextColor(hex);
        }}
      />
    </div>
  );
};

/* ============================================================================
   4. NOTIFICATION DESIGNER
============================================================================ */

export const NotificationDesignerScreen: React.FC<CommonToolProps> = ({
  activeShaderId,
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [notifStyle, setNotifStyle] = useState<
    'Basic' | 'Big Text' | 'Big Picture' | 'Progress' | 'Action Buttons'
  >('Basic');
  const [title, setTitle] = useState('Build Completed Successfully');
  const [description, setDescription] = useState(
    'Your Android package is ready for export and installation.'
  );
  const [iconColor, setIconColor] = useState('#00F5D4');
  const [largeIconOn, setLargeIconOn] = useState(true);
  const [progressVal, setProgressVal] = useState(68);
  const [actionsCount, setActionsCount] = useState(3);
  const [priority, setPriority] = useState<'HIGH' | 'MAX' | 'DEFAULT'>('HIGH');

  const [act1, setAct1] = useState('OPEN');
  const [act2, setAct2] = useState('SHARE');
  const [act3, setAct3] = useState('DISMISS');

  const [bodyUrl, setBodyUrl] = useState('https://t.me/Sharechat_ns_098');
  const [act1Url, setAct1Url] = useState('https://t.me/Sharechat_ns_098');
  const [act2Url, setAct2Url] = useState('https://t.me/Sharechat_ns_098');
  const [act3Url, setAct3Url] = useState('https://t.me/Sharechat_ns_098');

  const [showColorModal, setShowColorModal] = useState(false);
  const [liveStatusBarPopup, setLiveStatusBarPopup] = useState(false);

  const [compiling, setCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [packageReady, setPackageReady] = useState(false);
  const [showSmaliPreview, setShowSmaliPreview] = useState(false);
  const [showGuidePreview, setShowGuidePreview] = useState(false);

  const handleSendRealTestNotification = () => {
    setLiveStatusBarPopup(true);
    onShowToast(
      'Notification Sent',
      'Live Android notification posted to status bar!'
    );

    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification(title, { body: description, icon: '/icon.svg' });
      } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then((perm) => {
          if (perm === 'granted') {
            new Notification(title, { body: description, icon: '/icon.svg' });
          }
        });
      }
    }

    setTimeout(() => {
      setLiveStatusBarPopup(false);
    }, 5500);
  };

  const buildNotifPkgData = () => {
    const className = 'NsModsNotification';
    const primaryHook = `invoke-static/range {p0 .. p0}, Lcom/nsmods/xmlcreator/NsModsNotification;->show(Landroid/content/Context;)V`;
    const dexCfg: DexDialogConfig = {
      className,
      entryMethodName: 'show',
      title,
      message: description,
      positiveBtnText: '',
      negativeBtnText: '',
      telegramUrl: bodyUrl,
      bgColorHex: '#0B191E',
      accentColorHex: iconColor,
      textColorHex: '#E6FFFA',
      cornerRadiusDp: 16,
      strokeWidthDp: 2,
      extraConfigTag: `NOTIF_${notifStyle}`,
      executionMode: 'toast_custom',
      autoDismissMs: 5500,
    };
    const dexBytes = compileRealDalvikDex(dexCfg);
    const smaliPreview = generateDisassembledSmaliText(dexCfg);
    const guideText = buildUniversalModdingGuide({
      toolTitle: `Notification Designer (${notifStyle})`,
      className,
      primaryHook,
      secondaryHook: `invoke-static {p0}, Lcom/nsmods/xmlcreator/NsModsNotification;->openTelegram(Landroid/content/Context;)V`,
      descriptionEn: 'Trigger Heads-Up Notification Banner & Toast in MainActivity->onCreate',
      descriptionBn: 'MainActivity-তে কাস্টম নোটিফিকেশন ব্যানার যুক্ত করা (পপআপ ডায়ালগ ছাড়া!)',
      compiledSmaliPreview: smaliPreview,
      isPureLayout: true,
    });
    return { dexBytes, smaliPreview, guideText, primaryHook };
  };

  const handleCompileNotif = () => {
    setCompiling(true);
    setPackageReady(false);
    setCompileProgress(12);
    let p = 12;
    const id = window.setInterval(() => {
      p += 18;
      if (p >= 100) {
        p = 100;
        setCompileProgress(100);
        clearInterval(id);
        setCompiling(false);
        setPackageReady(true);
        onShowToast(
          '100% Crash-Free Notification DEX Ready!',
          'Full Smali compiled inside classes.dex + GUIDE.txt!'
        );
      } else {
        setCompileProgress(p);
      }
    }, 90);
  };

  const handleDownloadNotifPackage = async () => {
    const { dexBytes, guideText, primaryHook } = buildNotifPkgData();
    const zip = new JSZip();
    zip.file('classes2.dex', dexBytes);
    zip.file('classes.dex', dexBytes);
    zip.file('GUIDE.txt', guideText);
    const blob = await zip.generateAsync({ type: 'blob' });
    triggerBlobDownload(blob, 'NsMods_Notification_Package.zip');
    onSaveHistory(`Notification (${title})`, primaryHook);
    onShowToast(
      'ZIP Downloaded',
      'Saved NsMods_Notification_Package.zip (classes2.dex + classes.dex + GUIDE.txt)'
    );
  };

  const notifPkg = useMemo(
    () => buildNotifPkgData(),
    [notifStyle, title, description, bodyUrl, iconColor]
  );

  return (
    <div className="flex flex-col pb-6">
      {/* Simulated Android Heads-Up Status Bar Notification Banner */}
      {liveStatusBarPopup && (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-[94%] max-w-md rounded-2xl border border-[#00f5d4] bg-[#1e293b]/95 backdrop-blur-md p-3.5 shadow-[0_12px_32px_rgba(0,0,0,0.75)] animate-bounce">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-black font-bold text-xs shrink-0"
                style={{ backgroundColor: iconColor }}
              >
                NS
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white truncate">
                    {title}
                  </span>
                  <span className="text-[10px] text-slate-400 shrink-0">
                    now
                  </span>
                </div>
                <p className="text-xs text-slate-200 line-clamp-2 mt-0.5">
                  {description}
                </p>
              </div>
            </div>
            {largeIconOn && (
              <div className="w-10 h-10 rounded-lg border border-[#00f5d4] bg-[#08161b] flex items-center justify-center text-sm shrink-0">
                🥷
              </div>
            )}
          </div>
        </div>
      )}

      {/* Top Bar */}
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-[#00f5d4]/30">
        <button
          type="button"
          onClick={onBack}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ← Back
        </button>
        <h1 className="text-base font-extrabold text-white">
          <AnimatedText text="Notification Designer" config={typingConfig} />
        </h1>
        <button
          type="button"
          onClick={() => {
            setTitle('Build Completed Successfully');
            setDescription(
              'Your Android package is ready for export and installation.'
            );
            setProgressVal(68);
            setPackageReady(false);
            onShowToast('Reset Complete', 'Notification restored to default.');
          }}
          className={`px-3.5 py-2 rounded-xl border border-[#00f5d4]/70 bg-[#0a181c] text-xs font-bold text-white ${microClass}`}
        >
          ↻ Reset
        </button>
      </div>

      {/* Live Notification Preview Card */}
      <div
        className={`sticky top-2 z-20 rounded-2xl border-2 bg-[#081317]/95 backdrop-blur-md p-3.5 mb-3.5 ${glowClass}`}
      >
        <div className="rounded-xl border border-[#00f5d4]/50 bg-[#0b191e] p-3 mb-2.5">
          <div className="flex items-center justify-between text-[11px] mb-1.5">
            <div className="flex items-center gap-1.5 text-slate-300">
              <span style={{ color: iconColor }}>🔔</span>
              <span className="font-semibold">Ns mods • now</span>
            </div>
            <span className="font-mono font-bold text-[#00f5d4] uppercase">
              {notifStyle}
            </span>
          </div>

          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="text-sm font-extrabold text-white">{title}</div>
              <div className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                {description}
              </div>
            </div>
            {largeIconOn && (
              <div className="w-12 h-12 rounded-xl border border-[#00f5d4]/60 bg-gradient-to-br from-[#0d2b33] to-[#061014] flex items-center justify-center text-xl shrink-0 shadow-[0_0_12px_rgba(0,245,212,0.3)]">
                🥷
              </div>
            )}
          </div>

          {(notifStyle === 'Progress' || progressVal > 0) && (
            <div className="mt-2.5 h-1.5 w-full rounded-full bg-[#050c0e] overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#00f5d4] to-[#00bbf9]"
                style={{ width: `${progressVal}%` }}
              />
            </div>
          )}

          {actionsCount > 0 && (
            <div className="mt-3 grid grid-cols-3 gap-2">
              {actionsCount >= 1 && (
                <button
                  type="button"
                  onClick={() => handleSendRealTestNotification()}
                  className="py-1.5 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-bold text-[#00f5d4]"
                >
                  {act1}
                </button>
              )}
              {actionsCount >= 2 && (
                <button
                  type="button"
                  onClick={() => handleSendRealTestNotification()}
                  className="py-1.5 rounded-lg border border-[#00f5d4]/60 bg-[#0d2228] text-[11px] font-bold text-[#00f5d4]"
                >
                  {act2}
                </button>
              )}
              {actionsCount >= 3 && (
                <button
                  type="button"
                  onClick={() => setLiveStatusBarPopup(false)}
                  className="py-1.5 rounded-lg border border-[#ff2a85]/60 bg-[#1a0d14] text-[11px] font-bold text-[#ff2a85]"
                >
                  {act3}
                </button>
              )}
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={handleSendRealTestNotification}
          className={`w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d242b] text-xs font-extrabold text-white tracking-wider uppercase ${microClass}`}
        >
          SEND REAL TEST NOTIFICATION
        </button>
      </div>

      {/* Select Notification Style */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white mb-2.5">
          Select Notification Style
        </div>
        <div className="grid grid-cols-3 gap-2 mb-2">
          {(['Basic', 'Big Text', 'Big Picture'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setNotifStyle(st)}
              className={`py-2.5 rounded-xl border text-xs font-bold ${microClass} ${
                notifStyle === st
                  ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                  : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2">
          {(['Progress', 'Action Buttons'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setNotifStyle(st)}
              className={`py-2.5 rounded-xl border text-xs font-bold ${microClass} ${
                notifStyle === st
                  ? 'border-[#00f5d4] bg-[#0d2e36] text-[#00f5d4]'
                  : 'border-[#00f5d4]/40 bg-[#0d1c21] text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Title, Description & Icons Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-2.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white">
          Title, Description &amp; Icons
        </div>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2.5 text-xs font-semibold text-white"
        />
        <textarea
          rows={2}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2.5 text-xs text-white"
        />
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setShowColorModal(true)}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white leading-tight ${microClass}`}
          >
            ICON
            <br />
            COLOR
          </button>
          <button
            type="button"
            onClick={() => setLargeIconOn((v) => !v)}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white leading-tight ${microClass}`}
          >
            LARGE
            <br />
            ICON: {largeIconOn ? 'ON' : 'OFF'}
          </button>
          <button
            type="button"
            onClick={() =>
              onShowToast('Cyber Avatar Active', 'Using Ns mods icon.')
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-[11px] font-bold text-white leading-tight ${microClass}`}
          >
            PICK
            <br />
            IMAGE
          </button>
        </div>
      </div>

      {/* Progress & Action Buttons Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 mb-3.5 space-y-3 ${glowClass}`}>
        <div className="text-xs font-bold text-white">
          Progress &amp; Action Buttons
        </div>
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-slate-200 font-semibold">Progress Value</span>
            <span className="font-mono font-bold text-[#00f5d4]">
              {progressVal}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={progressVal}
            onChange={(e) => setProgressVal(Number(e.target.value))}
            className="w-full"
          />
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => setActionsCount((c) => (c + 1) % 4)}
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            ACTIONS: {actionsCount}
          </button>
          <button
            type="button"
            onClick={() =>
              setPriority((p) =>
                p === 'HIGH' ? 'MAX' : p === 'MAX' ? 'DEFAULT' : 'HIGH'
              )
            }
            className={`py-2.5 rounded-xl border border-[#00f5d4]/70 bg-[#0d1f25] text-xs font-bold text-white ${microClass}`}
          >
            PRIORITY: {priority}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <input
            type="text"
            value={act1}
            onChange={(e) => setAct1(e.target.value)}
            className="rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-2 py-2 text-center text-xs font-bold text-white"
          />
          <input
            type="text"
            value={act2}
            onChange={(e) => setAct2(e.target.value)}
            className="rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-2 py-2 text-center text-xs font-bold text-white"
          />
          <input
            type="text"
            value={act3}
            onChange={(e) => setAct3(e.target.value)}
            className="rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-2 py-2 text-center text-xs font-bold text-white"
          />
        </div>
      </div>

      {/* Notification & Action Button Links Card */}
      <div className={`rounded-2xl border-2 bg-[#091519] p-3.5 space-y-2.5 ${glowClass}`}>
        <div className="text-xs font-bold text-white">
          🔗 Notification &amp; Action Button Links (Tap Opens URL)
        </div>
        <p className="text-[11px] text-slate-400">
          Set a link for Notification Body Tap or Action Buttons (Telegram,
          YouTube, Website, Update Download).
        </p>

        <div className="text-[11px] font-semibold text-slate-200">
          Notification Body Tap Link (Opens when user taps notification)
        </div>
        <input
          type="text"
          value={bodyUrl}
          onChange={(e) => setBodyUrl(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-mono text-white"
        />

        <div className="grid grid-cols-4 gap-2">
          {[
            { label: 'TELEGRAM', url: 'https://t.me/Sharechat_ns_098' },
            { label: 'YOUTUBE', url: 'https://t.me/Sharechat_ns_098' },
            { label: 'GITHUB', url: 'https://t.me/Sharechat_ns_098' },
            { label: 'CHANNEL', url: 'https://t.me/Sharechat_ns_098' },
          ].map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => setBodyUrl(preset.url)}
              className="py-2 rounded-xl border border-[#00f5d4]/50 bg-[#0d1f25] text-[10px] font-bold text-white"
            >
              {preset.label}
            </button>
          ))}
        </div>

        <div className="text-[11px] font-semibold text-slate-200 pt-1">
          Action Button 1 Link (OPEN)
        </div>
        <input
          type="text"
          value={act1Url}
          onChange={(e) => setAct1Url(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-mono text-white"
        />

        <div className="text-[11px] font-semibold text-slate-200 pt-1">
          Action Button 2 Link (SHARE / CHANNEL)
        </div>
        <input
          type="text"
          value={act2Url}
          onChange={(e) => setAct2Url(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-mono text-white"
        />

        <div className="text-[11px] font-semibold text-slate-200 pt-1">
          Action Button 3 Link (DISMISS / CUSTOM)
        </div>
        <input
          type="text"
          value={act3Url}
          onChange={(e) => setAct3Url(e.target.value)}
          className="w-full rounded-xl border border-[#00f5d4]/50 bg-[#060f12] px-3 py-2 text-xs font-mono text-white"
        />

        <button
          type="button"
          onClick={handleCompileNotif}
          className={`mt-2 w-full py-3 rounded-xl border-2 border-[#00f5d4] bg-[#0d262e] text-xs font-extrabold text-white uppercase tracking-wider ${microClass}`}
        >
          ⚡ Generate Package (100% Crash-Free classes.dex + GUIDE.txt)
        </button>

        {(compiling || packageReady) && (
          <div className="space-y-3 pt-2">
            <ConversionShaderView
              shaderId={activeShaderId}
              sourceLabel="NOTIF AST"
              targetLabel="CLASSES.DEX"
              progress={compileProgress}
              compact
            />

            {packageReady && (
              <div className="rounded-xl border border-[#00ff88]/60 bg-[#071915] p-3.5 space-y-2.5">
                <div className="text-center text-xs font-bold text-[#00ff88]">
                  ✓ 100% Crash-Free Notification classes.dex Ready!
                </div>
                <div className="text-center text-[11px] font-mono text-slate-300">
                  • classes.dex (Lcom/nsmods/xmlcreator/NsModsNotification; — No res/ folder!) • GUIDE.txt
                </div>

                <button
                  type="button"
                  onClick={() => {
                    triggerBlobDownload(
                      new Blob([notifPkg.dexBytes.buffer as ArrayBuffer], {
                        type: 'application/octet-stream',
                      }),
                      'classes.dex'
                    );
                    onShowToast(
                      'Downloaded classes.dex',
                      'Open in MT Manager Dex Editor Plus to inspect Smali!'
                    );
                  }}
                  className="w-full py-2.5 rounded-xl border border-[#00f5d4] bg-[#0d242b] text-xs font-bold text-white"
                >
                  ⚡ Download classes.dex (Full Smali Inside)
                </button>

                <button
                  type="button"
                  onClick={handleDownloadNotifPackage}
                  className="w-full py-2.5 rounded-xl border border-[#00ff88] bg-[#0b2e25] text-xs font-bold text-[#00ff88]"
                >
                  📦 Download Complete ZIP (classes.dex + GUIDE.txt)
                </button>

                <button
                  type="button"
                  onClick={() => {
                    triggerBlobDownload(
                      new Blob([notifPkg.guideText], {
                        type: 'text/plain;charset=utf-8',
                      }),
                      'GUIDE.txt'
                    );
                    onShowToast('GUIDE.txt Downloaded', 'Bangla & English guide saved!');
                  }}
                  className="w-full py-2 rounded-xl border border-[#00f5d4]/60 bg-[#0d1f25] text-xs font-bold text-white"
                >
                  📄 Download GUIDE.txt
                </button>

                {/* 1-Line Hook */}
                <div className="rounded-xl border border-[#00f5d4]/40 bg-[#050d10] p-2.5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono font-bold text-[#00f5d4]">
                      MAINACTIVITY ONCREATE SMALI HOOK:
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(notifPkg.primaryHook);
                        onShowToast('Hook Copied!', 'Paste inside MainActivity->onCreate');
                      }}
                      className="px-2 py-0.5 rounded bg-[#0d282e] border border-[#00f5d4]/60 text-[10px] font-bold text-[#00f5d4]"
                    >
                      ❐ Copy
                    </button>
                  </div>
                  <code className="block text-[10px] font-mono text-white break-all select-all">
                    {notifPkg.primaryHook}
                  </code>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowSmaliPreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00f5d4]/40 bg-[#0a181d] text-[11px] font-bold text-[#00f5d4]"
                  >
                    {showSmaliPreview ? '▲ Hide Smali' : '▼ View Smali in DEX'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGuidePreview((v) => !v)}
                    className="py-2 rounded-xl border border-[#00ff88]/40 bg-[#0a181d] text-[11px] font-bold text-[#00ff88]"
                  >
                    {showGuidePreview ? '▲ Hide Guide' : '📖 View GUIDE.txt'}
                  </button>
                </div>

                {showSmaliPreview && (
                  <pre className="max-h-52 overflow-y-auto rounded-xl border border-[#00f5d4]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-[#00ff88] leading-relaxed select-all">
                    {notifPkg.smaliPreview}
                  </pre>
                )}

                {showGuidePreview && (
                  <pre className="max-h-56 overflow-y-auto rounded-xl border border-[#00ff88]/40 bg-[#040a0d] p-2.5 text-[10px] font-mono text-slate-200 leading-relaxed select-all whitespace-pre-wrap">
                    {notifPkg.guideText}
                  </pre>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <ColorPickerModal
        isOpen={showColorModal}
        initialColor={iconColor}
        onClose={() => setShowColorModal(false)}
        onSelectColor={setIconColor}
      />
    </div>
  );
};
