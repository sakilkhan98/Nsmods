import React, { useMemo, useState } from 'react';
import { TypingConfig } from '../types/appTypes';
import { AnimatedText } from './AnimatedText';

interface CommonModToolProps {
  typingConfig: TypingConfig;
  microClass: string;
  glowClass: string;
  onBack: () => void;
  onSaveHistory: (title: string, code: string) => void;
  onShowToast: (title: string, subtitle: string) => void;
}

/* ============================================================================
   TOOL 1: SMALI BRANCH INVERTER & OPCODE NOP STUDIO (MT Manager Patcher)
============================================================================ */

interface SmaliPreset {
  id: string;
  title: string;
  desc: string;
  originalCode: string;
  methodName: string;
}

const SMALI_PRESETS: SmaliPreset[] = [
  {
    id: 'vip_check',
    title: 'VIP / License Check Bypass',
    desc: 'Inverts if-eqz to bypass trial expired or premium license check.',
    methodName: 'isVipActive()Z',
    originalCode: `.method public isVipActive()Z
    .registers 3

    invoke-direct {p0}, Lcom/app/VIPManager;->checkLicense()Z
    move-result v0

    if-eqz v0, :cond_expired

    const/4 v1, 0x1
    return v1

    :cond_expired
    const/4 v1, 0x0
    return v1
.end method`,
  },
  {
    id: 'anti_debug',
    title: 'Anti-Debug & Integrity Kill Bypass',
    desc: 'NOPs out System.exit(0) and Runtime crash calls upon detection.',
    methodName: 'verifyEnvironment()V',
    originalCode: `.method public verifyEnvironment()V
    .registers 2

    invoke-static {}, Landroid/os/Debug;->isDebuggerConnected()Z
    move-result v0

    if-nez v0, :cond_safe

    # Kill process when debugger or mod detected
    const/4 v1, 0x0
    invoke-static {v1}, Ljava/lang/System;->exit(I)V

    :cond_safe
    return-void
.end method`,
  },
  {
    id: 'ad_timer',
    title: 'Interstitial Ad & Delay Timer Zeroer',
    desc: 'Replaces long delay constants with 0 to eliminate wait times.',
    methodName: 'getAdWaitInterval()I',
    originalCode: `.method public getAdWaitInterval()I
    .registers 2

    # 30,000 ms (30 seconds) wait time
    const/16 v0, 0x7530
    return v0
.end method`,
  },
  {
    id: 'sig_check',
    title: 'APK Signature Matcher Forcer',
    desc: 'Forces String.equals to return true for signature hashes.',
    methodName: 'validateSignatureHash()Z',
    originalCode: `.method public validateSignatureHash(Ljava/lang/String;)Z
    .registers 4

    const-string v0, "ORIGINAL_RELEASE_SIG_HASH_99"
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v1

    if-nez v1, :cond_valid

    const/4 v2, 0x0
    return v2

    :cond_valid
    const/4 v2, 0x1
    return v2
.end method`,
  },
];

export const SmaliBranchPatcherScreen: React.FC<CommonModToolProps> = ({
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<string>('vip_check');
  const [inputSmali, setInputSmali] = useState<string>(SMALI_PRESETS[0].originalCode);
  const [patchMode, setPatchMode] = useState<
    'invert_branches' | 'force_true' | 'force_false' | 'nop_kills' | 'strip_throws'
  >('invert_branches');
  const [replaceTargetLabel, setReplaceTargetLabel] = useState<string>(':cond_expired');

  // Load preset
  const handleSelectPreset = (p: SmaliPreset) => {
    setSelectedPreset(p.id);
    setInputSmali(p.originalCode);
    onShowToast('Preset Loaded', p.title);
  };

  // Process transformation
  const patchedResult = useMemo(() => {
    let lines = inputSmali.split('\n');

    if (patchMode === 'invert_branches') {
      lines = lines.map((line) => {
        // if-eqz <-> if-nez
        if (line.includes('if-eqz')) {
          return line.replace('if-eqz', 'if-nez') + '  # [NSMODS: Branch Inverted]';
        }
        if (line.includes('if-nez')) {
          return line.replace('if-nez', 'if-eqz') + '  # [NSMODS: Branch Inverted]';
        }
        // if-gez <-> if-lez
        if (line.includes('if-gez')) {
          return line.replace('if-gez', 'if-lez') + '  # [NSMODS: Inverted]';
        }
        if (line.includes('if-lez')) {
          return line.replace('if-lez', 'if-gez') + '  # [NSMODS: Inverted]';
        }
        // if-eq <-> if-ne
        if (line.includes('if-eq ')) {
          return line.replace('if-eq ', 'if-ne ') + '  # [NSMODS: Inverted]';
        }
        if (line.includes('if-ne ')) {
          return line.replace('if-ne ', 'if-eq ') + '  # [NSMODS: Inverted]';
        }
        return line;
      });
    } else if (patchMode === 'force_true') {
      // Inject return 0x1 right after .registers
      let injected = false;
      lines = lines.map((line) => {
        if (!injected && line.includes('.registers')) {
          injected = true;
          return `${line}\n\n    # --- @NSMODS: Force Return 1 (TRUE / UNLOCKED) ---\n    const/4 v0, 0x1\n    return v0\n    # ------------------------------------------------`;
        }
        return line;
      });
    } else if (patchMode === 'force_false') {
      let injected = false;
      lines = lines.map((line) => {
        if (!injected && line.includes('.registers')) {
          injected = true;
          return `${line}\n\n    # --- @NSMODS: Force Return 0 (FALSE / ZERO WAIT) ---\n    const/4 v0, 0x0\n    return v0\n    # --------------------------------------------------`;
        }
        return line;
      });
    } else if (patchMode === 'nop_kills') {
      // Replace System.exit / finish with nop
      lines = lines.map((line) => {
        if (
          line.includes('invoke-static') &&
          (line.includes('System;->exit') || line.includes('Process;->killProcess'))
        ) {
          return '    nop  # [NSMODS: Neutralized Process Kill]';
        }
        if (line.includes('invoke-virtual') && line.includes('Activity;->finish')) {
          return '    nop  # [NSMODS: Neutralized Activity Finish]';
        }
        return line;
      });
    } else if (patchMode === 'strip_throws') {
      // Replace throw instruction with return-void
      lines = lines.map((line) => {
        if (line.trim().startsWith('throw ')) {
          return '    return-void  # [NSMODS: Neutralized Throw Exception]';
        }
        return line;
      });
    }

    return lines.join('\n');
  }, [inputSmali, patchMode]);

  // Generate MT Manager Search & Replace pattern
  const mtManagerPattern = useMemo(() => {
    let search = 'if-eqz v0, :cond_';
    let replace = 'if-nez v0, :cond_';

    if (patchMode === 'force_true') {
      search = 'Original Method Entry';
      replace = 'const/4 v0, 0x1\nreturn v0';
    } else if (patchMode === 'nop_kills') {
      search = 'invoke-static {v1}, Ljava/lang/System;->exit(I)V';
      replace = 'nop';
    }

    return `// ==============================================
// MT MANAGER DEX EDITOR PLUS — SEARCH & REPLACE
// ==============================================
Search:
${search}

Replace with:
${replace}
// ==============================================`;
  }, [patchMode]);

  return (
    <div className="flex flex-col h-full text-slate-100 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#00f5d4]/20 mb-3">
        <button
          type="button"
          onClick={onBack}
          className={`px-3 py-1.5 rounded-xl border border-[#00f5d4]/40 bg-[#09171b] text-xs font-bold text-[#00f5d4] flex items-center gap-1.5 ${microClass}`}
        >
          <span>←</span>
          <span>Back</span>
        </button>

        <div className="text-center">
          <h2 className="text-sm sm:text-base font-extrabold text-[#00f5d4] tracking-wide">
            <AnimatedText text="Smali Branch Inverter & NOP Studio" config={typingConfig} />
          </h2>
          <span className="text-[10px] text-slate-400 font-mono">
            MT Manager Dex Editor Patch Generator
          </span>
        </div>

        <div className="w-16 flex justify-end">
          <span className="px-2 py-0.5 rounded-md bg-[#00f5d4]/10 border border-[#00f5d4]/40 text-[#00f5d4] text-[9px] font-mono font-bold">
            MODDER VIP
          </span>
        </div>
      </div>

      {/* Preset Attacks */}
      <div className="mb-3">
        <label className="text-[11px] font-bold text-slate-300 block mb-1.5">
          Select Common Modding Target / Preset:
        </label>
        <div className="grid grid-cols-2 gap-1.5">
          {SMALI_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => handleSelectPreset(p)}
              className={`p-2 rounded-xl text-left border transition-all text-xs ${
                selectedPreset === p.id
                  ? 'border-[#00f5d4] bg-[#0c262c] text-[#00f5d4] shadow-[0_0_12px_rgba(0,245,212,0.2)]'
                  : 'border-slate-800 bg-[#071318] text-slate-300 hover:border-slate-700'
              }`}
            >
              <div className="font-bold truncate">{p.title}</div>
              <div className="text-[9px] text-slate-400 truncate mt-0.5">{p.methodName}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Mod Action Modes */}
      <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 mb-3">
        {[
          { id: 'invert_branches', label: '🔀 Invert Branches' },
          { id: 'force_true', label: '✅ Force Return True' },
          { id: 'force_false', label: '❌ Force Return 0' },
          { id: 'nop_kills', label: '🛡️ NOP Process Kills' },
          { id: 'strip_throws', label: '⚡ Strip Exceptions' },
        ].map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setPatchMode(m.id as any)}
            className={`py-1.5 px-1 rounded-lg text-[10.5px] font-bold border transition-all text-center ${
              patchMode === m.id
                ? 'border-[#00ff88] bg-[#0a261c] text-[#00ff88]'
                : 'border-slate-800 bg-[#061014] text-slate-400 hover:text-white'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* Input Smali Code */}
      <div className="mb-2">
        <label className="text-[10px] text-slate-400 font-mono block mb-1">
          Paste Original Smali Code (from MT Manager):
        </label>
        <textarea
          rows={5}
          value={inputSmali}
          onChange={(e) => setInputSmali(e.target.value)}
          className="w-full bg-[#03090b] border border-slate-800 rounded-xl p-2.5 text-xs text-white font-mono focus:border-[#00f5d4] outline-none"
        />
      </div>

      {/* Patched Code Output */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center justify-between mb-1.5 text-xs">
          <span className="font-bold text-[#00ff88]">
            Patched Smali Result (Ready for MT Manager):
          </span>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(patchedResult);
                onShowToast('Copied Patched Smali!', 'Paste directly into MT Manager.');
              }}
              className="px-2.5 py-1 rounded-lg bg-[#00f5d4] text-[#041014] text-xs font-bold hover:brightness-110"
            >
              Copy Smali
            </button>
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(mtManagerPattern);
                onShowToast('Copied MT Pattern', 'Dex Editor search & replace copied.');
              }}
              className="px-2.5 py-1 rounded-lg border border-slate-700 bg-[#09171b] text-xs text-slate-200"
            >
              Copy MT Pattern
            </button>
          </div>
        </div>

        <div className="flex-1 rounded-xl border border-slate-800 bg-[#020608] p-3 overflow-y-auto font-mono text-[11px] text-[#00ff88] whitespace-pre leading-relaxed select-text">
          {patchedResult}
        </div>
      </div>

      {/* Footer */}
      <div className="mt-3 flex justify-between items-center text-[11px] text-slate-400">
        <span>Action: <strong className="text-[#00f5d4]">{patchMode}</strong></span>
        <button
          type="button"
          onClick={() => {
            onSaveHistory(`Smali Patch: ${patchMode}`, patchedResult);
            onShowToast('Saved', 'Saved in Workspace History.');
          }}
          className="text-[#00f5d4] hover:underline"
        >
          Save to History
        </button>
      </div>
    </div>
  );
};

/* ============================================================================
   TOOL 2: NATIVE .SO ARM64 HEX PATCHER STUDIO (Game Memory & Offset Modder)
============================================================================ */

type Architecture = 'ARM64' | 'ARM32_Thumb' | 'ARM32_Arm';

interface NativeModPreset {
  id: string;
  name: string;
  category: string;
  arm64Asm: string;
  arm64Hex: string;
  arm32ThumbHex: string;
  desc: string;
}

const NATIVE_PRESETS: NativeModPreset[] = [
  {
    id: 'return_1',
    name: 'Force Return 1 / True (VIP Unlock)',
    category: 'VIP / License',
    arm64Asm: 'MOV W0, #1\nRET',
    arm64Hex: '20 00 80 52 C0 03 5F D6',
    arm32ThumbHex: '01 20 70 47',
    desc: 'Forces any boolean/int security function to return 1 immediately.',
  },
  {
    id: 'return_0',
    name: 'Force Return 0 / False (Disable Detection)',
    category: 'Security',
    arm64Asm: 'MOV W0, #0\nRET',
    arm64Hex: '00 00 80 52 C0 03 5F D6',
    arm32ThumbHex: '00 20 70 47',
    desc: 'Forces detection checks (isRooted, isModded) to return 0.',
  },
  {
    id: 'nop_func',
    name: 'NOP Function (Strip Execution)',
    category: 'Integrity',
    arm64Asm: 'NOP\nRET',
    arm64Hex: '1F 20 03 D5 C0 03 5F D6',
    arm32ThumbHex: '00 BF 70 47',
    desc: 'Neutralizes function body and returns safely without crashing.',
  },
  {
    id: 'return_high_float',
    name: 'God Mode / 999999.0f Float Return',
    category: 'Game Mod',
    arm64Asm: 'MOV W0, #0x4974\nMOVK W0, #0x42c8, LSL #16\nFMOV S0, W0\nRET',
    arm64Hex: '80 E8 89 52 00 59 A8 72 00 00 27 1E C0 03 5F D6',
    arm32ThumbHex: '4F F0 74 40 70 47',
    desc: 'Returns IEEE-754 high float for Infinite Health or Speed.',
  },
  {
    id: 'infinite_ammo',
    name: 'Infinite Ammo / Subtraction Bypass',
    category: 'Game Mod',
    arm64Asm: 'NOP (Bypass SUBS W0, W0, W1)',
    arm64Hex: '1F 20 03 D5',
    arm32ThumbHex: '00 BF',
    desc: 'Replaces sub opcode so ammo/currency never decreases on fire.',
  },
];

export const NativeSoHexPatcherScreen: React.FC<CommonModToolProps> = ({
  typingConfig,
  microClass,
  glowClass,
  onBack,
  onSaveHistory,
  onShowToast,
}) => {
  const [arch, setArch] = useState<Architecture>('ARM64');
  const [targetLib, setTargetLib] = useState('libil2cpp.so');
  const [targetOffset, setTargetOffset] = useState('0x1A4B20');
  const [selectedPresetId, setSelectedPresetId] = useState('return_1');

  // Custom Assembly / Hex override
  const [customHexInput, setCustomHexInput] = useState('');
  const [activeTab, setActiveTab] = useState<'mt_hex' | 'cpp_hook' | 'dobby'>('mt_hex');

  const activePreset = NATIVE_PRESETS.find((p) => p.id === selectedPresetId) || NATIVE_PRESETS[0];

  const currentHex = customHexInput || (arch === 'ARM64' ? activePreset.arm64Hex : activePreset.arm32ThumbHex);

  // Generate MT Manager Hex Editor Guide
  const mtHexGuide = useMemo(() => {
    return `# ==============================================
# MT MANAGER HEX EDITOR INSTRUCTIONS
# Target File: ${targetLib}
# Target Architecture: ${arch}
# ==============================================

1. Open MT Manager and navigate to:
   /lib/${arch === 'ARM64' ? 'arm64-v8a' : 'armeabi-v7a'}/${targetLib}

2. Tap on '${targetLib}' -> Select 'Hex Editor'.

3. In Hex Editor, tap the Search (🔍) icon:
   • Search Mode: Offset / Address
   • Jump to Offset: ${targetOffset}

4. Replace bytes at offset ${targetOffset} with:
   ${currentHex}

5. Tap Save (💾) and Re-Sign your APK!
# ==============================================`;
  }, [targetLib, arch, targetOffset, currentHex]);

  // Generate C++ KittyMemory / memWrite code for Mod Menu
  const cppCode = useMemo(() => {
    const cleanHex = currentHex.replace(/\s+/g, '');
    return `// ==============================================
// C++ MEMORY PATCH SNIPPET (For Floating Mod Menu)
// Target: ${targetLib} Offset: ${targetOffset}
// ==============================================

#include <cstdint>
#include <cstring>
#include <sys/mman.h>
#include <unistd.h>

void apply${activePreset.name.replace(/[^a-zA-Z0-9]/g, '')}() {
    uintptr_t libBase = KittyMemory::getAbsoluteAddress("${targetLib}", ${targetOffset});
    if (libBase == 0) {
        LOGE("Could not locate ${targetLib} in process memory!");
        return;
    }

    // Patch Hex Bytes: ${currentHex}
    const char* hexPatch = "${cleanHex}";
    MemoryPatch::createWithHex("${targetLib}", ${targetOffset}, hexPatch).Modify();

    LOGI("Successfully patched offset ${targetOffset} in ${targetLib}!");
}`;
  }, [targetLib, targetOffset, currentHex, activePreset]);

  // Generate Dobby Hook Code
  const dobbyCode = useMemo(() => {
    return `// ==============================================
// DOBBY / SUBSTRATE FUNCTION HOOK
// ==============================================

#include "dobby.h"

// Original Function Pointer
static int (*orig_func)(void *instance);

// Hook Replacement
static int hook_replacement(void *instance) {
    // Force VIP / Unlimited return value
    return 1;
}

void installDobbyHook() {
    uintptr_t targetAddr = KittyMemory::getAbsoluteAddress("${targetLib}", ${targetOffset});
    if (targetAddr != 0) {
        DobbyHook((void *)targetAddr, (void *)hook_replacement, (void **)&orig_func);
        LOGI("Dobby Hook installed at ${targetOffset}!");
    }
}`;
  }, [targetLib, targetOffset]);

  const outputCode = activeTab === 'mt_hex' ? mtHexGuide : activeTab === 'cpp_hook' ? cppCode : dobbyCode;

  const handleDownload = () => {
    const filename = `Patch_${targetOffset}_${arch}.txt`;
    const blob = new Blob([outputCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    onShowToast('Patch File Downloaded', filename);
  };

  return (
    <div className="flex flex-col h-full text-slate-100 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#00f5d4]/20 mb-3">
        <button
          type="button"
          onClick={onBack}
          className={`px-3 py-1.5 rounded-xl border border-[#00f5d4]/40 bg-[#09171b] text-xs font-bold text-[#00f5d4] flex items-center gap-1.5 ${microClass}`}
        >
          <span>←</span>
          <span>Back</span>
        </button>

        <div className="text-center">
          <h2 className="text-sm sm:text-base font-extrabold text-[#00f5d4] tracking-wide">
            <AnimatedText text="Native .so ARM64 Hex Patcher Studio" config={typingConfig} />
          </h2>
          <span className="text-[10px] text-slate-400 font-mono">
            Game Memory & Offset Modder v10
          </span>
        </div>

        <div className="w-16 flex justify-end">
          <span className="px-2 py-0.5 rounded-md bg-[#00ff88]/10 border border-[#00ff88]/40 text-[#00ff88] text-[9px] font-mono font-bold">
            HEX PRO
          </span>
        </div>
      </div>

      {/* Target Library & Arch */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <div>
          <label className="text-[10px] text-slate-400 block mb-0.5 font-mono">
            Target Library (.so):
          </label>
          <input
            type="text"
            value={targetLib}
            onChange={(e) => setTargetLib(e.target.value)}
            className="w-full bg-[#09171b] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono focus:border-[#00f5d4] outline-none"
          />
        </div>
        <div>
          <label className="text-[10px] text-slate-400 block mb-0.5 font-mono">
            Architecture:
          </label>
          <div className="flex rounded-lg bg-[#071318] p-1 border border-slate-700">
            {(['ARM64', 'ARM32_Thumb'] as Architecture[]).map((a) => (
              <button
                key={a}
                type="button"
                onClick={() => setArch(a)}
                className={`flex-1 py-1 text-[11px] font-bold rounded ${
                  arch === a ? 'bg-[#00f5d4] text-[#041014]' : 'text-slate-400'
                }`}
              >
                {a === 'ARM64' ? 'ARM64 (64-bit)' : 'ARM32 (32-bit)'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Offset Address Input */}
      <div className="mb-3">
        <label className="text-[10px] text-slate-400 block mb-0.5 font-mono">
          Target Function Offset (from IDA Pro / Ghidra / Il2CppDumper):
        </label>
        <input
          type="text"
          value={targetOffset}
          onChange={(e) => setTargetOffset(e.target.value)}
          placeholder="0x1A4B20"
          className="w-full bg-[#09171b] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-[#00ff88] font-mono focus:border-[#00ff88] outline-none"
        />
      </div>

      {/* Preset Mod Intents */}
      <div className="mb-3">
        <label className="text-[11px] font-bold text-slate-300 block mb-1.5">
          Select Modding Intent / Opcode Patch:
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          {NATIVE_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                setSelectedPresetId(p.id);
                setCustomHexInput('');
              }}
              className={`p-2 rounded-xl text-left border text-xs transition-all ${
                selectedPresetId === p.id
                  ? 'border-[#00f5d4] bg-[#0c262c] text-[#00f5d4] shadow-[0_0_10px_rgba(0,245,212,0.2)]'
                  : 'border-slate-800 bg-[#071318] text-slate-400 hover:text-white'
              }`}
            >
              <div className="font-bold truncate">{p.name}</div>
              <div className="text-[9px] text-[#00ff88] font-mono mt-0.5">
                {arch === 'ARM64' ? p.arm64Hex : p.arm32ThumbHex}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Output Switch Tabs: MT Hex | C++ Patch | Dobby Hook */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex gap-1.5 text-xs">
          {[
            { id: 'mt_hex', label: '📱 MT Hex Editor' },
            { id: 'cpp_hook', label: '⚙️ C++ MemoryPatch' },
            { id: 'dobby', label: '🪝 Dobby Hook' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id as any)}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] ${
                activeTab === t.id
                  ? 'bg-[#00f5d4]/20 text-[#00f5d4] border border-[#00f5d4]/50'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex gap-1.5">
          <button
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(outputCode);
              onShowToast('Copied to Clipboard!', 'Hex instructions ready.');
            }}
            className="px-2.5 py-1 rounded-lg border border-slate-700 bg-[#09171b] text-xs text-slate-200"
          >
            Copy
          </button>
          <button
            type="button"
            onClick={handleDownload}
            className="px-2.5 py-1 rounded-lg bg-[#00ff88] text-[#041014] text-xs font-bold hover:brightness-110"
          >
            Download
          </button>
        </div>
      </div>

      {/* Code Display */}
      <div className="flex-1 rounded-xl border border-slate-800 bg-[#020608] p-3 overflow-y-auto font-mono text-[11px] text-[#00ff88] whitespace-pre leading-relaxed select-text min-h-0">
        {outputCode}
      </div>

      {/* Footer */}
      <div className="mt-3 flex justify-between items-center text-[11px] text-slate-400">
        <span>Target: <strong className="text-[#00f5d4]">{targetLib} @ {targetOffset}</strong></span>
        <button
          type="button"
          onClick={() => {
            onSaveHistory(`Hex Patch: ${targetLib} ${targetOffset}`, outputCode);
            onShowToast('Saved', 'Saved in History.');
          }}
          className="text-[#00f5d4] hover:underline"
        >
          Save to History
        </button>
      </div>
    </div>
  );
};
