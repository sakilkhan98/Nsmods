import React, { useEffect, useRef } from 'react';
import { AmbientBgStyle, TouchParticleStyle } from '../types/appTypes';

interface Props {
  ambientBg: AmbientBgStyle;
  touchParticle: TouchParticleStyle;
}

interface BurstParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  color: string;
  shape: 'circle' | 'star' | 'heart' | 'ring' | 'shard' | 'char' | 'laser';
  char?: string;
  rotation: number;
  vRot: number;
}

const PALETTES: Record<TouchParticleStyle, string[]> = {
  None: [],
  Neon: ['#00f5d4', '#ff2a85', '#00bbf9', '#9b5de5', '#ffd166', '#00ff88'],
  Golden: ['#ffd166', '#ffb703', '#fff3b0', '#fb8500', '#ffffff'],
  Fairy: ['#ff99c8', '#fcf6bd', '#d0f4de', '#a9def9', '#e4c1f9'],
  Fire: ['#ff4800', '#ff7900', '#ffb600', '#ff0055', '#ffe566'],
  Hearts: ['#ff2a85', '#ff5c8a', '#ff85a1', '#fbb1bd', '#ff0a54'],
  Bubbles: ['#00f5d4', '#00bbf9', '#ff71ce', '#fee440', '#9b5de5'],
  Water: ['#00bbf9', '#48cae4', '#90e0ef', '#caf0f8', '#00f5d4'],
  Crystals: ['#e0fbfc', '#00f5d4', '#72efdd', '#80ffdb', '#ffffff'],
  MatrixRain: ['#00ff88', '#00f5d4', '#38b000', '#70e000', '#ccff33'],
  Sakura: ['#ffb3c6', '#ff8fab', '#ffc2d1', '#ffe5ec', '#fb6f92'],
  Ice: ['#caf0f8', '#90e0ef', '#00b4d8', '#ffffff', '#48cae4'],
  Starlight: ['#ffffff', '#ffd166', '#00f5d4', '#ff2a85', '#a855f7'],
  Laser: ['#00f5d4', '#ff0055', '#00bbf9', '#ffffff', '#39ff14'],
};

export const AmbientAndParticleCanvas: React.FC<Props> = React.memo(
  ({ ambientBg, touchParticle }) => {
    const bgCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const fgCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const burstsRef = useRef<BurstParticle[]>([]);
    const touchStyleRef = useRef<TouchParticleStyle>(touchParticle);

    useEffect(() => {
      touchStyleRef.current = touchParticle;
    }, [touchParticle]);

    // Background Ambient FX loop (Ultra-lightweight 24fps soft ambient nodes)
    useEffect(() => {
      const canvas = bgCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let width = (canvas.width = window.innerWidth);
      let height = (canvas.height = window.innerHeight);

      if (ambientBg === 'None') {
        ctx.clearRect(0, 0, width, height);
        return;
      }

      let animId = 0;
      let lastFrameTime = 0;

      const handleResize = () => {
        if (!canvas) return;
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      };
      window.addEventListener('resize', handleResize, { passive: true });

      const count = ambientBg === 'Matrix' ? 16 : 18;
      const nodes = Array.from({ length: count }, (_, idx) => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 2 + 0.8,
        vx: (Math.random() - 0.5) * 0.35,
        vy:
          ambientBg === 'Embers'
            ? -(Math.random() * 0.7 + 0.25)
            : ambientBg === 'Matrix'
            ? Math.random() * 1.8 + 0.9
            : Math.random() * 0.45 + 0.15,
        alpha: Math.random() * 0.45 + 0.15,
        char: String.fromCharCode(0x30a0 + Math.floor(Math.random() * 96)),
        hue: idx % 2 === 0 ? '#00f5d4' : '#38bdf8',
      }));

      const renderBg = (now: number) => {
        if (document.hidden) {
          animId = requestAnimationFrame(renderBg);
          return;
        }
        // Throttle ambient background to ~24 FPS to leave 100% GPU headroom for UI scrolling
        if (now - lastFrameTime < 42) {
          animId = requestAnimationFrame(renderBg);
          return;
        }
        lastFrameTime = now;

        ctx.clearRect(0, 0, width, height);

        for (let i = 0; i < nodes.length; i++) {
          const p = nodes[i];
          p.x += p.vx;
          p.y += p.vy;

          if (p.y > height + 16) {
            p.y = -8;
            p.x = Math.random() * width;
          } else if (p.y < -16) {
            p.y = height + 8;
            p.x = Math.random() * width;
          }
          if (p.x > width + 10) p.x = -10;
          if (p.x < -10) p.x = width + 10;

          ctx.globalAlpha = p.alpha;

          if (ambientBg === 'Matrix') {
            ctx.fillStyle = '#00ff88';
            ctx.font = '10px "JetBrains Mono", monospace';
            ctx.fillText(p.char, p.x, p.y);
          } else if (ambientBg === 'Quantum') {
            ctx.fillStyle = p.hue;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r * 1.8, 0, Math.PI * 2);
            ctx.fill();
          } else if (ambientBg === 'Embers') {
            ctx.fillStyle = i % 2 === 0 ? '#ff7900' : '#ff2a85';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
          } else if (ambientBg === 'Starfield') {
            ctx.fillStyle = '#e0fbfc';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r * 0.9, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.fillStyle = '#98f5e1';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
          }
        }

        ctx.globalAlpha = 1;
        animId = requestAnimationFrame(renderBg);
      };

      animId = requestAnimationFrame(renderBg);
      return () => {
        cancelAnimationFrame(animId);
        window.removeEventListener('resize', handleResize);
      };
    }, [ambientBg]);

    // Foreground Touch Tap Particle Bursts (Demand-driven: 0% CPU when not tapping, no shadowBlur lag!)
    useEffect(() => {
      const canvas = fgCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      let animId = 0;
      let isLoopRunning = false;
      let width = (canvas.width = window.innerWidth);
      let height = (canvas.height = window.innerHeight);

      const handleResize = () => {
        if (!canvas) return;
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
      };
      window.addEventListener('resize', handleResize, { passive: true });

      const renderFg = () => {
        ctx.clearRect(0, 0, width, height);
        const list = burstsRef.current;

        for (let i = list.length - 1; i >= 0; i--) {
          const p = list[i];
          p.x += p.vx;
          p.y += p.vy;
          p.vy += 0.07;
          p.vx *= 0.96;
          p.alpha -= 0.038;
          p.rotation += p.vRot;

          if (p.alpha <= 0) {
            list.splice(i, 1);
            continue;
          }

          ctx.save();
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.fillStyle = p.color;
          ctx.strokeStyle = p.color;

          if (p.shape === 'circle') {
            ctx.beginPath();
            ctx.arc(0, 0, p.size, 0, Math.PI * 2);
            ctx.fill();
          } else if (p.shape === 'ring') {
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(0, 0, p.size * 1.15, 0, Math.PI * 2);
            ctx.stroke();
          } else if (p.shape === 'star') {
            ctx.beginPath();
            for (let s = 0; s < 4; s++) {
              ctx.lineTo(
                Math.cos((s * Math.PI) / 2) * p.size * 1.5,
                Math.sin((s * Math.PI) / 2) * p.size * 1.5
              );
              ctx.lineTo(
                Math.cos(((s + 0.5) * Math.PI) / 2) * p.size * 0.45,
                Math.sin(((s + 0.5) * Math.PI) / 2) * p.size * 0.45
              );
            }
            ctx.closePath();
            ctx.fill();
          } else if (p.shape === 'shard') {
            ctx.beginPath();
            ctx.moveTo(0, -p.size * 1.3);
            ctx.lineTo(p.size * 0.9, 0);
            ctx.lineTo(0, p.size * 1.3);
            ctx.lineTo(-p.size * 0.9, 0);
            ctx.closePath();
            ctx.fill();
          } else if (p.shape === 'heart') {
            const s = p.size * 0.42;
            ctx.beginPath();
            ctx.moveTo(0, s);
            ctx.bezierCurveTo(-s * 2, -s, -s * 4, s, 0, s * 4);
            ctx.bezierCurveTo(s * 4, s, s * 2, -s, 0, s);
            ctx.fill();
          } else if (p.shape === 'laser') {
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.moveTo(-p.size * 1.8, 0);
            ctx.lineTo(p.size * 1.8, 0);
            ctx.stroke();
          } else if (p.shape === 'char') {
            ctx.font = 'bold 10px "JetBrains Mono", monospace';
            ctx.fillText(p.char || '1', -3, 3);
          }

          ctx.restore();
        }

        if (list.length > 0) {
          animId = requestAnimationFrame(renderFg);
        } else {
          isLoopRunning = false;
        }
      };

      const spawnBurst = (clientX: number, clientY: number) => {
        const style = touchStyleRef.current;
        if (style === 'None') return;
        const colors = PALETTES[style] || PALETTES.Neon;
        const count = 10;

        // Cap total particles to prevent buildup on rapid taps
        if (burstsRef.current.length > 30) {
          burstsRef.current.splice(0, burstsRef.current.length - 20);
        }

        for (let i = 0; i < count; i++) {
          const angle =
            (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.35;
          const speed = Math.random() * 3.2 + 1.1;
          let shape: BurstParticle['shape'] = 'circle';
          if (
            style === 'Golden' ||
            style === 'Starlight' ||
            style === 'Fairy'
          ) {
            shape = 'star';
          } else if (style === 'Hearts') shape = 'heart';
          else if (style === 'Bubbles' || style === 'Water') shape = 'ring';
          else if (
            style === 'Crystals' ||
            style === 'Ice' ||
            style === 'Sakura'
          ) {
            shape = 'shard';
          } else if (style === 'MatrixRain') shape = 'char';
          else if (style === 'Laser') shape = 'laser';

          burstsRef.current.push({
            x: clientX,
            y: clientY,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed - (style === 'Fire' ? 1.1 : 0),
            size: Math.random() * 3.6 + 2.2,
            alpha: 0.95,
            color: colors[i % colors.length],
            shape,
            char: i % 2 === 0 ? '1' : '0',
            rotation: Math.random() * Math.PI * 2,
            vRot: (Math.random() - 0.5) * 0.16,
          });
        }

        if (!isLoopRunning) {
          isLoopRunning = true;
          animId = requestAnimationFrame(renderFg);
        }
      };

      const handlePointerDown = (e: PointerEvent) => {
        spawnBurst(e.clientX, e.clientY);
      };

      window.addEventListener('pointerdown', handlePointerDown, {
        passive: true,
      });

      return () => {
        cancelAnimationFrame(animId);
        window.removeEventListener('resize', handleResize);
        window.removeEventListener('pointerdown', handlePointerDown);
      };
    }, []);

    return (
      <>
        <canvas
          ref={bgCanvasRef}
          className="fixed inset-0 pointer-events-none z-0"
        />
        <canvas
          ref={fgCanvasRef}
          className="fixed inset-0 pointer-events-none z-[100]"
        />
      </>
    );
  }
);
