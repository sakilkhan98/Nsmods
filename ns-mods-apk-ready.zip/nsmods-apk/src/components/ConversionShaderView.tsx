import React, { useEffect, useState } from 'react';
import { CONVERSION_SHADERS } from '../data/fxCatalog';

interface Props {
  shaderId: number;
  sourceLabel?: string;
  targetLabel?: string;
  progress: number; // 0 to 100
  compact?: boolean;
}

const STAGES = ['PARSE', 'TREE', 'TRANSFORM', 'OPTIMIZE', 'VERIFY', 'DONE'];

const STAGE_MESSAGES = [
  'Initializing AST Lexer & Token Stream...',
  'Parsing Code Structure & Syntax Tree...',
  'Transforming Bytecode & Resource Nodes...',
  'Optimizing Registers & Nullability...',
  'Verifying Integrity & Dalvik Signatures...',
  'Conversion Complete ✓',
];

export const ConversionShaderView: React.FC<Props> = ({
  shaderId,
  sourceLabel = 'JAVA',
  targetLabel = 'KOTLIN',
  progress,
  compact = false,
}) => {
  const shader =
    CONVERSION_SHADERS.find((s) => s.id === shaderId) || CONVERSION_SHADERS[0];
  const isHacking = shader.category === 'HACKING' || shaderId === 2;
  const clamped = Math.max(0, Math.min(100, Math.round(progress)));
  const stageIndex = Math.min(5, Math.floor((clamped / 100) * 5.99));

  const [matrixCols, setMatrixCols] = useState<string[]>([]);

  useEffect(() => {
    if (!isHacking) return;
    const gen = () =>
      Array.from({ length: 16 }, () =>
        Array.from({ length: 7 }, () =>
          Math.random() > 0.4
            ? Math.floor(Math.random() * 16)
                .toString(16)
                .toUpperCase()
            : String.fromCharCode(0x30a0 + Math.floor(Math.random() * 64))
        ).join(' ')
      );
    setMatrixCols(gen());
    const id = window.setInterval(() => setMatrixCols(gen()), 160);
    return () => clearInterval(id);
  }, [isHacking]);

  const primaryColor = isHacking
    ? '#00ff88'
    : shaderId % 3 === 0
    ? '#a855f7'
    : '#00f5d4';
  const secondaryColor = isHacking ? '#00f5d4' : '#ff2a85';

  // Circle SVG math
  const radius = compact ? 42 : 52;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (clamped / 100) * circumference;

  return (
    <div className="relative overflow-hidden rounded-2xl border-2 border-[#00f5d4]/60 bg-[#050d10] p-3.5 shadow-[0_0_24px_rgba(0,245,212,0.18)]">
      {/* Matrix Hacker Rain Overlay when Hacking Shader is active */}
      {isHacking && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-25 font-mono text-[10px] leading-3 text-[#00ff88] flex justify-around select-none">
          {matrixCols.map((col, idx) => (
            <div key={idx} className="flex flex-col">
              {col.split(' ').map((c, j) => (
                <span key={j}>{c}</span>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Top Engine Header */}
      <div className="relative z-10 text-center mb-2.5">
        <div
          className="text-[10px] font-mono font-bold tracking-widest uppercase"
          style={{ color: primaryColor }}
        >
          ✦ {shader.name.toUpperCase()} ENGINE ✦
        </div>
        <div className="mt-1 flex items-center justify-center gap-3 text-xs font-mono font-bold tracking-wider">
          <span className="text-[#00f5d4]">{sourceLabel}</span>
          <span className="text-slate-400">──────▶</span>
          <span style={{ color: secondaryColor }}>{targetLabel}</span>
        </div>
      </div>

      {/* Main 3-Column HUD: Left Code Card | Center Reactor Gauge | Right Target Card */}
      <div className="relative z-10 grid grid-cols-3 items-center gap-2 my-2">
        {/* Left Scanning Card */}
        <div className="rounded-xl border border-[#00f5d4]/50 bg-[#08161b]/90 p-2">
          <div className="flex items-center gap-1 text-[10px] font-mono text-[#00f5d4] mb-1.5">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ff2a85]" />
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ffd166]" />
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00ff88]" />
            <span className="ml-1 truncate font-bold">{sourceLabel}</span>
          </div>
          <div className="space-y-1.5">
            <div className="h-1.5 w-4/5 rounded bg-[#00f5d4]/70 animate-pulse" />
            <div className="h-1.5 w-3/5 rounded bg-[#00bbf9]/50" />
            <div className="h-1.5 w-full rounded bg-[#00f5d4]/40" />
            <div className="h-1.5 w-2/3 rounded bg-[#00ff88]/60" />
          </div>
          <div className="mt-2 text-center text-[9px] font-mono uppercase tracking-wider text-slate-400">
            SCANNING
          </div>
        </div>

        {/* Center Circular Core Engine */}
        <div className="flex flex-col items-center justify-center">
          <div className="relative flex items-center justify-center">
            <svg
              className="transform -rotate-90"
              width={compact ? 104 : 124}
              height={compact ? 104 : 124}
            >
              <circle
                cx={compact ? 52 : 62}
                cy={compact ? 52 : 62}
                r={radius}
                stroke="rgba(0, 245, 212, 0.15)"
                strokeWidth="6"
                fill="rgba(5, 16, 20, 0.85)"
              />
              <circle
                cx={compact ? 52 : 62}
                cy={compact ? 52 : 62}
                r={radius}
                stroke={primaryColor}
                strokeWidth="6"
                strokeDasharray={circumference}
                strokeDashoffset={dashOffset}
                strokeLinecap="round"
                fill="transparent"
                style={{
                  filter: `drop-shadow(0 0 8px ${primaryColor})`,
                  transition: 'stroke-dashoffset 0.12s linear',
                }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-lg font-mono font-extrabold text-white">
                {clamped}%
              </span>
              <span
                className="text-[8px] font-mono uppercase tracking-widest"
                style={{ color: primaryColor }}
              >
                {clamped >= 100 ? 'VERIFIED ✓' : 'CORE ENGINE'}
              </span>
            </div>
          </div>
        </div>

        {/* Right Output Card */}
        <div
          className="rounded-xl border bg-[#08161b]/90 p-2"
          style={{ borderColor: `${secondaryColor}88` }}
        >
          <div
            className="flex items-center gap-1 text-[10px] font-mono mb-1.5"
            style={{ color: secondaryColor }}
          >
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ff2a85]" />
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ffd166]" />
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#00ff88]" />
            <span className="ml-1 truncate font-bold">{targetLabel}</span>
          </div>
          <div className="space-y-1.5">
            <div
              className="h-1.5 w-3/4 rounded animate-pulse"
              style={{ backgroundColor: secondaryColor }}
            />
            <div className="h-1.5 w-full rounded bg-[#00f5d4]/60" />
            <div
              className="h-1.5 w-2/3 rounded"
              style={{ backgroundColor: `${primaryColor}99` }}
            />
            <div className="h-1.5 w-5/6 rounded bg-[#00ff88]/75" />
          </div>
          <div
            className="mt-2 text-center text-[9px] font-mono uppercase tracking-wider"
            style={{ color: clamped >= 100 ? '#00ff88' : secondaryColor }}
          >
            {clamped >= 100 ? 'READY ✓' : 'SYNTHESIZING'}
          </div>
        </div>
      </div>

      {/* Bottom 6-Stage Pipeline Tracker */}
      <div className="relative z-10 mt-2 rounded-xl border border-[#00f5d4]/40 bg-[#081519]/90 p-2.5">
        <div
          className="text-center text-xs font-semibold mb-2"
          style={{ color: clamped >= 100 ? '#00ff88' : '#e2f8f5' }}
        >
          {clamped >= 100
            ? '✓ Complete: classes.dex + Resources Ready!'
            : STAGE_MESSAGES[stageIndex]}
        </div>

        {/* Progress Bar */}
        <div className="relative h-2 w-full rounded-full bg-[#040b0e] overflow-hidden mb-2 border border-[#00f5d4]/30">
          <div
            className="h-full rounded-full transition-all duration-100"
            style={{
              width: `${clamped}%`,
              background: `linear-gradient(90deg, ${primaryColor}, ${secondaryColor})`,
            }}
          />
        </div>

        {/* Stage Labels */}
        <div className="grid grid-cols-6 text-center text-[9px] font-mono">
          {STAGES.map((st, idx) => {
            const active = idx <= stageIndex;
            return (
              <span
                key={st}
                className={
                  active ? 'font-bold text-[#00f5d4]' : 'text-slate-500'
                }
              >
                {st}
              </span>
            );
          })}
        </div>
      </div>

      <div className="mt-1.5 text-center text-[9px] font-mono uppercase tracking-wider text-slate-400">
        STYLE {shader.id}: {shader.name.toUpperCase()} • STEP {stageIndex + 1}/6
      </div>
    </div>
  );
};
