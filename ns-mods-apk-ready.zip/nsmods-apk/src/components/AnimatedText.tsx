import React, { useEffect, useState } from 'react';
import { TypingConfig } from '../types/appTypes';

interface Props {
  text: string;
  config: TypingConfig;
  forceEnable?: boolean;
  replayTrigger?: number;
  className?: string;
}

const SCRAMBLE_CHARS = '01#$%&*@<>[]{}?/\\=~^';
const RAINBOW_COLORS = [
  '#ff2a85',
  '#ff7900',
  '#ffd166',
  '#00ff88',
  '#00f5d4',
  '#00bbf9',
  '#9b5de5',
];
const AURORA_COLORS = [
  '#00f5d4',
  '#10b981',
  '#38bdf8',
  '#818cf8',
  '#c084fc',
  '#2dd4bf',
];
const VAPORWAVE_COLORS = [
  '#ff71ce',
  '#01cdfe',
  '#05ffa1',
  '#b967ff',
  '#fffb96',
];
const FIRE_COLORS = ['#ff4800', '#ff7900', '#ffb703', '#ff0055', '#ffd166'];

export const AnimatedText: React.FC<Props> = React.memo(
  ({
    text,
    config,
    forceEnable = false,
    replayTrigger = 0,
    className = '',
  }) => {
    // Fast-path for normal UI buttons & headers: ZERO JS timers, ZERO per-character DOM nodes!
    // Uses pure GPU CSS gradient text when enabled so scrolling & tapping stay at a locked 120 FPS.
    const runLiveJsLoop = forceEnable;
    const [charCount, setCharCount] = useState(text.length);
    const [phaseTick, setPhaseTick] = useState(0);

    useEffect(() => {
      if (!runLiveJsLoop) {
        return;
      }

      const codePoints = Array.from(text);
      let current = 0;
      setCharCount(0);
      let timeoutId: number | undefined;

      const stepMs = Math.max(40, Math.min(300, config.speedMs));

      const intervalId = window.setInterval(() => {
        setPhaseTick((t) => (t + 1) % 60);
      }, 180);

      const runTyping = () => {
        if (current < codePoints.length) {
          current += 1;
          setCharCount(current);
          timeoutId = window.setTimeout(runTyping, stepMs);
        } else if (config.loopContinuous) {
          timeoutId = window.setTimeout(() => {
            current = 0;
            setCharCount(0);
            timeoutId = window.setTimeout(runTyping, 220);
          }, Math.max(2, config.pauseSec) * 1000);
        }
      };

      timeoutId = window.setTimeout(runTyping, 80);

      return () => {
        if (timeoutId) clearTimeout(timeoutId);
        clearInterval(intervalId);
      };
    }, [
      runLiveJsLoop,
      text,
      config.speedMs,
      config.loopContinuous,
      config.pauseSec,
      config.styleId,
      replayTrigger,
    ]);

    if (!config.enabled && !forceEnable) {
      return <span className={className}>{text}</span>;
    }

    // Ultra-smooth GPU CSS path for all normal UI screens (0 JS timers, 1 DOM node)
    if (!runLiveJsLoop) {
      let shaderClass = '';
      if (config.styleId === 4) shaderClass = 'text-shader-rainbow';
      else if (config.styleId === 15) shaderClass = 'text-shader-aurora';
      else if (config.styleId === 18) shaderClass = 'text-shader-vaporwave';
      else if (config.styleId === 14) shaderClass = 'text-shader-fire';

      return (
        <span className={`${shaderClass} ${className}`.trim()}>{text}</span>
      );
    }

    // Interactive preview box path (only when forceEnable === true in Settings preview)
    const cursorChar =
      config.styleId === 16
        ? '█'
        : config.cursorStyle === 'Bar (|)'
        ? '|'
        : config.cursorStyle === 'Block (█)'
        ? '█'
        : config.cursorStyle === 'Underscore (_)'
        ? '_'
        : '';

    const allChars = Array.from(text);
    const visibleChars = allChars.slice(0, charCount);
    const isTypingInProgress = charCount < allChars.length;

    const getPalette = (): string[] | null => {
      switch (config.styleId) {
        case 4:
          return RAINBOW_COLORS;
        case 14:
          return FIRE_COLORS;
        case 15:
          return AURORA_COLORS;
        case 18:
          return VAPORWAVE_COLORS;
        case 3:
        case 12:
        case 17:
          return ['#00f5d4', '#ffffff', '#00bbf9', '#38bdf8', '#00f5d4'];
        case 7:
          return ['#00ff88', '#38b000', '#ccff33', '#00f5d4'];
        case 9:
          return ['#ffd166', '#ffffff', '#ffb703', '#fde047'];
        case 10:
          return ['#ff2a85', '#00f5d4', '#9b5de5', '#00bbf9'];
        default:
          return null;
      }
    };

    const palette = getPalette();

    return (
      <span className={`inline-flex items-center flex-wrap ${className}`}>
        <span>
          {visibleChars.map((ch, idx) => {
            let displayChar = ch;
            if (
              (config.styleId === 2 ||
                config.styleId === 7 ||
                config.styleId === 8) &&
              isTypingInProgress &&
              idx >= charCount - 2 &&
              ch !== ' '
            ) {
              displayChar =
                SCRAMBLE_CHARS[(idx + phaseTick) % SCRAMBLE_CHARS.length];
            }

            let charColor: string | undefined;
            if (palette && ch !== ' ') {
              const colorIdx = (idx + phaseTick) % palette.length;
              charColor = palette[colorIdx];
            }

            return (
              <span
                key={idx}
                style={{
                  color: charColor,
                }}
              >
                {displayChar}
              </span>
            );
          })}
        </span>
        {cursorChar && (isTypingInProgress || config.loopContinuous) && (
          <span className="ml-0.5 text-[#00f5d4] opacity-80 font-mono">
            {cursorChar}
          </span>
        )}
      </span>
    );
  }
);
